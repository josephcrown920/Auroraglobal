# Aurora MCP — Integration Guide

How to connect the Aurora MCP connector into your existing Aurora app and add avatar creation.

---

## 1. Architecture Overview

```
Your Aurora App (Node.js)
├─ Existing REST API (:3000)
│  ├─ /api/generate/video
│  ├─ /api/generate/bulk
│  ├─ /api/generate/image-to-video
│  └─ /api/jobs/*
│
├─ Aurora MCP Server (:4200) ← NEW
│  ├─ Wraps your Aurora REST API
│  ├─ Adds smart model selection
│  └─ Exposes 5 tools to Claude
│
└─ Supabase (PostgreSQL)
   ├─ avatars table (read by MCP)
   ├─ generation_jobs table (read/write by MCP)
   └─ avatar_variants table (for LoRA training status)
```

---

## 2. Option A: Run MCP as a Sidecar (Easiest)

Launch the MCP server alongside your existing Aurora app.

### 2a. Install in your monorepo

```bash
# If your Aurora backend is at ./apps/aurora-backend
cp -r aurora-mcp ./packages/aurora-mcp

cd packages/aurora-mcp
npm install
cp .env.example .env
# Edit .env with your values:
#   AURORA_API_URL=http://localhost:3000
#   AURORA_API_KEY=your_existing_api_key
#   SUPABASE_URL=...
#   SUPABASE_SERVICE_KEY=...
#   PORT=4200
```

### 2b. Boot script (package.json)

```json
{
  "scripts": {
    "dev": "concurrently \"npm run dev --workspace=aurora-backend\" \"npm run dev --workspace=aurora-mcp\"",
    "start": "concurrently \"npm start --workspace=aurora-backend\" \"npm start --workspace=aurora-mcp\""
  }
}
```

Now `npm run dev` boots both on :3000 and :4200.

---

## 3. Option B: Embed MCP as a Route (Advanced)

If you want a single port, add the MCP server as a route in your existing Aurora backend:

```typescript
// apps/aurora-backend/src/routes/mcp.ts
import { createAuroraMcpServer } from 'aurora-mcp/src/server';
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse';

export function setupMcpRoute(app: Express) {
  const mcpInstances = new Map<string, any>();

  // SSE endpoint
  app.get('/mcp/sse', async (req, res) => {
    const server = createAuroraMcpServer();
    const transport = new SSEServerTransport('/mcp/messages', res);
    mcpInstances.set(transport.sessionId, transport);

    res.on('close', () => mcpInstances.delete(transport.sessionId));
    await server.connect(transport);
  });

  // Message endpoint
  app.post('/mcp/messages', async (req, res) => {
    const sessionId = req.query.sessionId;
    const transport = mcpInstances.get(sessionId);
    if (!transport) return res.status(404).json({ error: 'Session not found' });
    await transport.handlePostMessage(req, res, req.body);
  });
}
```

Then in your main server:

```typescript
// apps/aurora-backend/src/index.ts
import { setupMcpRoute } from './routes/mcp';

const app = express();
// ... your existing routes ...
setupMcpRoute(app);

app.listen(3000, () => console.log('Aurora + MCP on :3000'));
```

Now your MCP server is at `http://localhost:3000/mcp/sse` (same origin as Aurora).

---

## 4. Connect to Claude Desktop

### 4a. Claude Desktop config

Edit `~/.claude/config.json` (macOS/Linux) or `%APPDATA%\Claude\config.json` (Windows):

```json
{
  "mcpServers": {
    "aurora": {
      "command": "tsx",
      "args": ["dist/index.js"],
      "cwd": "/absolute/path/to/aurora-mcp",
      "env": {
        "AURORA_API_URL": "http://localhost:3000",
        "AURORA_API_KEY": "your_key",
        "SUPABASE_URL": "...",
        "SUPABASE_SERVICE_KEY": "...",
        "PORT": "4200"
      }
    }
  }
}
```

Or for URL-based (HTTP):

```json
{
  "mcpServers": {
    "aurora": {
      "type": "url",
      "url": "http://localhost:4200/sse"
    }
  }
}
```

Restart Claude Desktop. In any chat, you'll see "Aurora" in the tools list.

### 4b. Use it

```
You: "Make a 5s cinematic video of Sophia on a rooftop"

Claude: [calls aurora_generate_video with auto-selected kling-2.5]
Running kling-2.5 · 5s · 9:16 for Sophia
Job ID: job_abc123
```

Then ask: "What's the status?" and Claude polls `aurora_get_job_status`.

---

## 5. Connect via the API

Use `aurora-mcp-client.ts` to call Claude with MCP server attached:

```typescript
import { callAuroraConnector } from './aurora-mcp-client';

// In your app's endpoint
app.post('/api/generate-with-claude', async (req, res) => {
  const { prompt } = req.body;

  const result = await callAuroraConnector([
    { role: 'user', content: prompt },
  ]);

  res.json(result);
});
```

Now your frontend can do:

```typescript
// Frontend
const response = await fetch('/api/generate-with-claude', {
  method: 'POST',
  body: JSON.stringify({ prompt: 'Make 12 IG posts for Aria this week' }),
});

const result = await response.json();
// Claude auto-routed to aurora_bulk_generate with model selection
```

---

## 6. Avatar Creation

### 6a. What's Needed

**Current**: `list_avatars`, `get_avatar` (read-only)  
**Missing**: `create_avatar` tool to train new avatars

Avatar creation is a multi-step workflow:

1. **Image/video upload** — user provides reference photos or video
2. **LoRA training** (HeyGen) — fine-tunes a model on the user's face → outputs `lora_id`
3. **Lipsync LoRA** (Sync.so) — optional, trains for lip-sync → outputs `sync_lora_id`
4. **Store in Supabase** — `avatars` table gets a row with the LoRA IDs

### 6b. Add `create_avatar` Tool

Update `src/tools/index.ts`:

```typescript
export const createAvatarSchema = z.object({
  name:         z.string().describe('Avatar name (e.g. "Sophia")'),
  image_urls:   z.array(z.string().url()).describe('3–5 reference images of the person'),
  trigger_word: z.string().optional().describe('LoRA trigger word (e.g. "sphastyle")'),
  style:        z.string().optional().describe('Style descriptor (e.g. "professional", "casual")'),
  lipsync:      z.boolean().optional().describe('Train lipsync LoRA (Sync.so)? Default: false'),
});

export async function createAvatarTool(
  args: z.infer<typeof createAvatarSchema>,
): Promise<ToolResult> {
  try {
    // 1. Submit to HeyGen LoRA training
    const heygenRes = await fetch('https://api.heygen.com/v1/custom_avatar/training', {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.HEYGEN_API_KEY}` },
      body: JSON.stringify({
        name: args.name,
        video_urls: args.image_urls,
        // HeyGen expects video; if you have images, you'd need to stitch them
      }),
    });
    const heygenData = await heygenRes.json();
    const loraId = heygenData.avatar_id; // or training_id, check HeyGen docs

    // 2. Optional: Sync.so lipsync training
    let syncLoraId = null;
    if (args.lipsync) {
      const syncRes = await fetch('https://api.sync.so/v1/train', {
        method: 'POST',
        headers: { Authorization: `Bearer ${process.env.SYNC_API_KEY}` },
        body: JSON.stringify({
          name: args.name,
          video_urls: args.image_urls,
        }),
      });
      const syncData = await syncRes.json();
      syncLoraId = syncData.model_id;
    }

    // 3. Store in Supabase
    const { data } = await supabase.from('avatars').insert({
      name: args.name,
      handle: `@${args.name.toLowerCase()}.ai`,
      lora_id: loraId,
      sync_lora_id: syncLoraId,
      trigger_word: args.trigger_word || 'style',
      style: args.style || 'general',
      preview_url: args.image_urls[0],
      training_status: 'processing',
    }).select().single();

    return ok({
      avatar_id: data.id,
      name: args.name,
      status: 'training',
      message: `Avatar "${args.name}" submitted for training. Check back in 2–4 hours.`,
    });
  } catch (e) {
    return err(String(e));
  }
}
```

Then register in `server.ts`:

```typescript
server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    // ... existing 5 tools ...
    {
      name: 'aurora_create_avatar',
      description: 'Train a new avatar with reference images. Returns avatar_id when training completes.',
      inputSchema: zodToJsonSchema(createAvatarSchema),
    },
  ],
}));

server.setRequestHandler(CallToolRequestSchema, async (req) => {
  switch (req.params.name) {
    // ... existing cases ...
    case 'aurora_create_avatar':
      return createAvatarTool(createAvatarSchema.parse(req.params.arguments));
  }
});
```

### 6c. UI Flow

In your app's avatar creation page:

```typescript
// Frontend: avatar creation form
async function createAvatar(formData) {
  // Claude will do the heavy lifting
  const response = await callAuroraConnector([
    {
      role: 'user',
      content: `
        Create an avatar named "${formData.name}" from these images:
        ${formData.images.map(img => img.url).join(', ')}
        Style: ${formData.style}
        Train lipsync: ${formData.trainLipsync}
      `,
    },
  ]);

  console.log('Avatar creation submitted:', response);
  // User will see: "Avatar training started. Check back in 2-4 hours."
}
```

### 6d. Polling for Training Status

Add a helper tool:

```typescript
export const getAvatarTrainingStatusSchema = z.object({
  avatar_id: z.string().describe('Avatar ID'),
});

export async function getAvatarTrainingStatusTool(
  args: z.infer<typeof getAvatarTrainingStatusSchema>,
): Promise<ToolResult> {
  const avatar = await supabase
    .from('avatars')
    .select('*')
    .eq('id', args.avatar_id)
    .single();

  if (avatar.data?.training_status === 'completed') {
    return ok({
      avatar_id: args.avatar_id,
      status: 'ready',
      message: `${avatar.data.name} is ready to use!`,
    });
  }

  return ok({
    avatar_id: args.avatar_id,
    status: avatar.data?.training_status || 'pending',
    message: `Still training. Check back in a few minutes.`,
  });
}
```

---

## 7. Full Integration Checklist

- [ ] Copy `aurora-mcp/` into your project
- [ ] Fill in `.env` with your Aurora API key, Supabase keys, HeyGen key
- [ ] Run `npm install` in the MCP package
- [ ] Boot MCP server (`npm run dev` or embed in existing Express app)
- [ ] Test: `curl http://localhost:4200/health` (should return `{ status: 'ok' }`)
- [ ] Connect to Claude Desktop or use `aurora-mcp-client.ts`
- [ ] Try a simple generation: "Make a 5s video of Sophia"
- [ ] Add `create_avatar` tool for avatar training
- [ ] Add avatar training UI in your app
- [ ] Deploy MCP server (same infra as Aurora backend)

---

## 8. Deployment

### Docker

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY aurora-mcp ./
RUN npm install
EXPOSE 4200
CMD ["npm", "start"]
```

### Environment (prod)

```bash
AURORA_API_URL=https://aurora.yourcompany.com
AURORA_API_KEY=sk_live_...
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGci...
HEYGEN_API_KEY=your_key
SYNC_API_KEY=your_key
PORT=4200
```

---

## 9. Next Steps

1. **Start simple**: boot the MCP server, test with Claude Desktop
2. **Add avatar creation**: implement `aurora_create_avatar` tool
3. **Scale**: move job polling to background workers (Bull/BullMQ) instead of blocking the chat
4. **Advanced**: add webhook support for HeyGen/Sync.so to notify when training completes
