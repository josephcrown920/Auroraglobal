-- ─────────────────────────────────────────────────────────────────────────────
-- Supabase Schema for Aurora MCP
-- ─────────────────────────────────────────────────────────────────────────────
-- Run these SQL commands in Supabase SQL Editor to set up the required tables

-- ─── Avatars Table (personas) ─────────────────────────────────────────────────

CREATE TABLE avatars (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Identity
  name text NOT NULL UNIQUE,
  handle text NOT NULL UNIQUE, -- @name.ai
  
  -- LoRA Models (from HeyGen and Sync.so)
  lora_id text NOT NULL, -- HeyGen custom avatar ID
  sync_lora_id text, -- Sync.so lipsync model ID (optional)
  
  -- Metadata
  trigger_word text DEFAULT 'style', -- LoRA trigger word
  style text DEFAULT 'general', -- e.g. 'professional', 'casual', 'athletic'
  preview_url text, -- thumbnail image URL
  
  -- Training Status
  training_status text DEFAULT 'pending' CHECK (training_status IN ('pending', 'in_progress', 'completed', 'failed')),
  training_submitted_at timestamp DEFAULT now(),
  training_completed_at timestamp,
  training_error text, -- error message if training fails
  
  -- Timestamps
  created_at timestamp DEFAULT now(),
  updated_at timestamp DEFAULT now(),
  
  -- Indexing
  CONSTRAINT avatar_name_length CHECK (char_length(name) > 0)
);

-- Index for lookups
CREATE INDEX idx_avatars_name ON avatars(name);
CREATE INDEX idx_avatars_training_status ON avatars(training_status) WHERE training_status != 'completed';

-- ─── Generation Jobs Table ───────────────────────────────────────────────────

CREATE TABLE generation_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Job metadata
  type text NOT NULL CHECK (type IN ('image', 'video', 'lipsync', 'bulk')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  
  -- Provider info
  provider text NOT NULL, -- 'kling', 'heygen', 'sync.so', 'huggingface', 'wan', 'hailuo'
  model text NOT NULL, -- specific model version
  external_job_id text, -- provider's job ID for polling
  
  -- Request data
  prompt text,
  image_url text,
  avatar_id uuid REFERENCES avatars(id) ON DELETE SET NULL,
  
  -- Response data
  output_url text, -- single video/image URL
  output_urls text[], -- array for bulk jobs
  
  -- Metadata
  duration_seconds integer, -- for videos
  aspect_ratio text DEFAULT '9:16',
  credits_used integer DEFAULT 0,
  
  -- Error handling
  error text, -- error message if failed
  retry_count integer DEFAULT 0,
  
  -- Timestamps
  created_at timestamp DEFAULT now(),
  updated_at timestamp DEFAULT now(),
  started_at timestamp,
  completed_at timestamp,
  
  -- Indexing
  CONSTRAINT job_model_length CHECK (char_length(model) > 0)
);

-- Indexes for common queries
CREATE INDEX idx_generation_jobs_status ON generation_jobs(status);
CREATE INDEX idx_generation_jobs_avatar_id ON generation_jobs(avatar_id);
CREATE INDEX idx_generation_jobs_created_at ON generation_jobs(created_at DESC);
CREATE INDEX idx_generation_jobs_external_id ON generation_jobs(external_job_id) WHERE external_job_id IS NOT NULL;

-- ─── Avatar Variants Table (optional - for multi-style versions) ──────────────

CREATE TABLE avatar_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  avatar_id uuid NOT NULL REFERENCES avatars(id) ON DELETE CASCADE,
  
  name text NOT NULL, -- e.g. "Sophia Business", "Sophia Casual"
  lora_id text NOT NULL, -- separate LoRA for this variant
  style text, -- specific style for this variant
  preview_url text,
  
  created_at timestamp DEFAULT now(),
  
  UNIQUE(avatar_id, name)
);

CREATE INDEX idx_avatar_variants_avatar_id ON avatar_variants(avatar_id);

-- ─── Credit Transactions (for tracking usage) ──────────────────────────────

CREATE TABLE credit_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  user_id text, -- your user ID (optional)
  amount integer NOT NULL, -- positive for purchases, negative for usage
  
  job_id uuid REFERENCES generation_jobs(id) ON DELETE SET NULL,
  reason text NOT NULL, -- 'generation', 'purchase', 'refund', etc.
  
  created_at timestamp DEFAULT now()
);

CREATE INDEX idx_credit_transactions_user_id ON credit_transactions(user_id);
CREATE INDEX idx_credit_transactions_created_at ON credit_transactions(created_at DESC);

-- ─── Row-Level Security (optional - for multi-tenant) ─────────────────────

-- If you want per-user access control:
ALTER TABLE avatars ENABLE ROW LEVEL SECURITY;
ALTER TABLE generation_jobs ENABLE ROW LEVEL SECURITY;

-- Example: users can only see their own avatars
-- CREATE POLICY "avatars_select" ON avatars
--   FOR SELECT USING (owner_id = auth.uid());

-- ─── Triggers for updated_at ──────────────────────────────────────────────

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_avatars_updated_at BEFORE UPDATE ON avatars
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_generation_jobs_updated_at BEFORE UPDATE ON generation_jobs
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ─── Views for Common Queries ─────────────────────────────────────────────

-- All completed videos
CREATE VIEW completed_videos AS
SELECT 
  j.id,
  j.created_at,
  a.name as avatar_name,
  j.prompt,
  j.output_url,
  j.model,
  j.credits_used
FROM generation_jobs j
LEFT JOIN avatars a ON j.avatar_id = a.id
WHERE j.type = 'video' AND j.status = 'completed'
ORDER BY j.created_at DESC;

-- Avatar training progress
CREATE VIEW avatar_training_status AS
SELECT 
  id,
  name,
  training_status,
  training_submitted_at,
  training_completed_at,
  CASE 
    WHEN training_status = 'completed' THEN '✓ Ready'
    WHEN training_status = 'failed' THEN '✗ Failed'
    WHEN training_status = 'in_progress' THEN '⏳ Training...'
    ELSE '⋯ Pending'
  END as status_display,
  CASE 
    WHEN training_completed_at IS NOT NULL 
    THEN EXTRACT(HOUR FROM training_completed_at - training_submitted_at) 
    ELSE NULL 
  END as training_hours
FROM avatars
ORDER BY training_submitted_at DESC;

-- ─── Sample Data (for testing) ───────────────────────────────────────────

-- Uncomment to insert test avatars
/*
INSERT INTO avatars (name, handle, lora_id, trigger_word, style, preview_url, training_status, training_completed_at)
VALUES
  ('Sophia', '@sophia.ai', 'lora_sophia_001', 'sphastyle', 'professional', 'https://example.com/sophia.jpg', 'completed', now()),
  ('Aria', '@aria.ai', 'lora_aria_001', 'ariastyle', 'casual', 'https://example.com/aria.jpg', 'completed', now()),
  ('Mia', '@mia.ai', 'lora_mia_001', 'miastyle', 'athletic', 'https://example.com/mia.jpg', 'completed', now()),
  ('Nova', '@nova.ai', 'lora_nova_001', 'novastyle', 'energetic', 'https://example.com/nova.jpg', 'in_progress', NULL),
  ('Jade', '@jade.ai', 'lora_jade_001', 'jadestyle', 'minimalist', 'https://example.com/jade.jpg', 'completed', now());
*/

-- ─── Grants (if using Service Role) ──────────────────────────────────────

-- The aurora-mcp service uses SUPABASE_SERVICE_KEY, which has full access
-- No additional grants needed for service role

-- If you create other roles/users, grant access:
-- GRANT SELECT, INSERT, UPDATE ON avatars TO "aurora_app";
-- GRANT SELECT, INSERT, UPDATE ON generation_jobs TO "aurora_app";
