# Aurora MCP — Complete Documentation

**Aurora MCP** is a Model Context Protocol (MCP) server that makes Claude your creative director for AI-generated content. Think of it as a ChatGPT Plugin for your own Aurora platform.

## What It Does

Claude can now:

✅ Generate videos (Kling, HeyGen, Wan, Hailuo, Sora)  
✅ Bulk-generate image campaigns (50 posts in one prompt)  
✅ Animate still images into videos  
✅ Train custom avatars from reference photos  
✅ Poll job status and track credits  

**Natural language interface:**

```
User: "Make 12 IG posts for Aria this week — vary outfits and lighting"

Claude: [auto-selects flux-1.1-pro + kling-kolors]
→ Running bulk image generation · 4:5 · 12 images
→ Generating 12 images for Aria · 120 credits · ~3m
```

---

## Architecture

```
┌─ Claude (Desktop or API) ──────────────────┐
│  "Make a cinematic video of Sophia"        │
└──────────────────┬────────────────────────┘
                   │
                   ↓
    ┌── Aurora MCP Server (:4200) ──┐
    │  ├─ Smart model selector      │
    │  ├─ Job orchestration         │
    │  └─ Avatar management         │
    └──────────────────┬─────────────┘
                       │
        ┌──────────────┼──────────────┐
        ↓              ↓              ↓
    Aurora API    Supabase DB     HeyGen/Sync.so
    (:3000)       (avatars,      (LoRA training)
                   jobs)
```

---

## Files Included

**Backend (production-ready)**
- `aurora-mcp/src/index.ts` — Express + SSE server
- `aurora-mcp/src/server.ts` — MCP tool registry
- `aurora-mcp/src/tools/index.ts` — 5 tools (+ 6th for avatar creation)
- `aurora-mcp/src/lib/model-selector.ts` — smart keyword→model routing
- `aurora-mcp/src/lib/supabase.ts` — database helpers
- `aurora-mcp/src/lib/aurora-client.ts` — HTTP client to your Aurora API

**Integration**
- `aurora-mcp-client.ts` — how to call Claude from your backend
- `avatar-creation.ts` — avatar training workflow
- `supabase-schema.sql` — database tables

**Guides**
- `QUICKSTART.md` — 3 paths to integrate (5 min each)
- `INTEGRATION_GUIDE.md` — detailed walkthrough
- This file — everything

---

## Quick Start (Pick One Path)

### Path 1: Claude Desktop (Zero Infra)

No backend needed. Just use Claude Desktop directly with the MCP server.

```bash
cd aurora-mcp
npm install && npm run build

# Edit ~/.claude/config.json
{
  "mcpServers": {
    "aurora": {
      "command": "node",
      "args": ["dist/index.js"],
      "cwd": "/path/to/aurora-mcp",
      "env": {
        "AURORA_API_URL": "http://localhost:3000",
        "AURORA_API_KEY": "your_key",
        "SUPABASE_URL": "...",
        "SUPABASE_SERVICE_KEY": "...",
        "PORT": "4200"
      }
    }
  }
}

# Restart Claude Desktop
# Now use: "Make a 5s video of Sophia"
```

### Path 2: Sidecar (Dev & Prod)

Run MCP as a separate service.

```bash
# Install
cd aurora-mcp
npm install

# Configure
cp .env.example .env
# Edit .env with your keys

# Boot
npm run dev  # or `npm start` for production

# Use in your app
const response = await fetch('https://api.anthropic.com/v1/messages', {
  // ... your message ...
  mcp_servers: [{
    type: 'url',
    url: 'http://localhost:4200/sse',
    name: 'aurora',
  }],
});
```

### Path 3: Embedded (Single Port)

Integrate MCP into your existing Aurora backend.

```typescript
// In your Aurora backend
import { createAuroraMcpServer } from 'aurora-mcp/src/server';
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse';

const mcpInstances = new Map();

app.get('/api/mcp/sse', async (req, res) => {
  const server = createAuroraMcpServer();
  const transport = new SSEServerTransport('/api/mcp/messages', res);
  mcpInstances.set(transport.sessionId, transport);
  res.on('close', () => mcpInstances.delete(transport.sessionId));
  await server.connect(transport);
});

app.post('/api/mcp/messages', async (req, res) => {
  const transport = mcpInstances.get(req.query.sessionId);
  if (transport) await transport.handlePostMessage(req, res, req.body);
});

// Now MCP is at http://localhost:3000/api/mcp/sse
```

---

## The 5 Core Tools

### 1. `aurora_generate_video`

Generate a single short video. Claude auto-selects the best model.

```
Prompt: "Make a 5s cinematic video of Sophia walking on a rooftop"
→ Detects: cinematic → uses kling-2.5 (premium)
→ Duration: 5s, Aspect: 9:16, Credits: ~100

Prompt: "Quick 5s video of Julia, budget-friendly"
→ Detects: budget → uses kling-2.5-turbo (fast)
→ Duration: 5s, Aspect: 9:16, Credits: ~50

Prompt: "Make Sophia say 'hello world'"
→ Detects: speech/talking → uses heygen-v2 (lipsync)
```

### 2. `aurora_bulk_generate`

Batch-generate up to 50 images for a campaign.

```
Prompt: "12 IG-ready photos of Aria for next week. Vary outfits: casual, formal, beach. Lighting: golden hour, indoor, overcast."
→ Creates 12 images with prompt variations
→ Auto-selects flux-1.1-pro or kling-kolors
→ Saves to Supabase
→ Returns 12 URLs
```

### 3. `aurora_image_to_video`

Animate a still image into a short video.

```
Input: image_url + "slow cinematic zoom"
→ Extracts motion cues → uses kling-2.5-turbo
→ Outputs: 5-10s MP4 at 9:16
```

### 4. `aurora_list_avatars`

List all available avatars and their details.

```
→ Returns:
  - Sophia (@sophia.ai) - professional
  - Aria (@aria.ai) - casual
  - Mia (@mia.ai) - athletic
  - ...
```

### 5. `aurora_get_job_status`

Poll any job's status, output, and credits used.

```
Input: job_id
→ Returns:
  - status: 'completed' | 'processing' | 'failed'
  - output_url: '...'
  - credits_used: 100
  - model: 'kling-2.5'
```

### 6. `aurora_create_avatar` (Optional Add-On)

Train a new custom avatar from reference photos.

```
Input: name, 3-5 images, trigger_word, optional lipsync
→ Submits to HeyGen for LoRA training
→ Optionally trains Sync.so for lipsync
→ Returns after ~2-4 hours
→ Avatar ready for use in generation tools
```

---

## Smart Model Selection

The MCP server intelligently routes requests to the best model based on keywords:

| Keyword                          | Model Used      | Why                      |
|----------------------------------|-----------------|--------------------------|
| cinematic, film, professional    | kling-2.5       | Highest quality          |
| quick, fast, budget, draft       | kling-2.5-turbo | Speed & cost              |
| talking, speaking, lipsync       | heygen-v2       | Lipsync quality           |
| loop, ambient, cinemagraph       | wan-2.1         | Seamless looping          |
| high-end, sora                   | sora-turbo       | Cutting-edge              |
| (default)                        | kling-2.5-turbo | Good balance              |

**You can override** by specifying the model explicitly:

```
"Make a 5s video with kling-2.5 turbo"
→ Uses kling-2.5-turbo regardless of keywords
```

---

## Avatar Creation Workflow

### 1. Submit Images

```
Claude: "Create avatar 'Luna' from these photos: [urls]. Train lipsync."
Tool: aurora_create_avatar
  - name: Luna
  - image_urls: [...]
  - lipsync: true
```

### 2. Background Training

- HeyGen trains LoRA: 2-4 hours
- Sync.so trains lipsync model (optional): 1-2 hours
- Status tracked in Supabase `avatars` table

### 3. Polling

```
Polling job runs every 30 minutes (configurable)
→ Checks HeyGen training status
→ Checks Sync.so training status
→ Updates `training_status` → 'in_progress' → 'completed'
```

### 4. Use Avatar

Once training completes:

```
Claude: "Make 5 videos of Luna"
Tool: aurora_generate_video with avatar_id=luna
→ Uses Luna's LoRA automatically
→ Outputs: 5 videos featuring Luna
```

---

## Supabase Setup

Run the schema script:

```bash
# In Supabase SQL Editor
# Paste contents of supabase-schema.sql
```

Creates:
- `avatars` table (name, lora_id, sync_lora_id, training_status, etc.)
- `generation_jobs` table (type, status, output_url, credits_used, etc.)
- `avatar_variants` table (optional multi-style versions)
- Views: `completed_videos`, `avatar_training_status`

### Sample Query

```sql
-- Recent completed videos
SELECT created_at, avatar_name, model, output_url, credits_used
FROM completed_videos
ORDER BY created_at DESC
LIMIT 10;

-- Avatar training progress
SELECT * FROM avatar_training_status;
```

---

## Deployment

### Docker

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY aurora-mcp ./
RUN npm install
EXPOSE 4200
CMD ["npm", "start"]
```

### docker-compose.yml

```yaml
version: '3'
services:
  aurora-mcp:
    build: ./aurora-mcp
    ports: ['4200:4200']
    environment:
      AURORA_API_URL: http://aurora-backend:3000
      AURORA_API_KEY: ${AURORA_API_KEY}
      SUPABASE_URL: ${SUPABASE_URL}
      SUPABASE_SERVICE_KEY: ${SUPABASE_SERVICE_KEY}
      HEYGEN_API_KEY: ${HEYGEN_API_KEY}
      SYNC_API_KEY: ${SYNC_API_KEY}
```

### Environment (Prod)

```bash
AURORA_API_URL=https://aurora.yourapp.com
AURORA_API_KEY=sk_live_...
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGc...
HEYGEN_API_KEY=your_key
SYNC_API_KEY=your_key
PORT=4200
```

---

## Example Prompts

```
"Make a 5s cinematic video of Sophia on a rooftop at golden hour"
→ kling-2.5 · 100 credits

"Generate 12 IG-ready photos of Aria this week. Vary: outfits (casual, formal, beach), lighting (golden hour, indoor, overcast)"
→ Bulk image generation · 12 images · 4:5 · 120 credits

"Animate this image with a slow zoom: [url]. Use kling-2.5-turbo"
→ img2vid · 50 credits

"Create avatar 'Zara' from these photos: [urls]. Include lipsync training"
→ Avatar submitted · ~3 hours

"What's the status of job job_abc123?"
→ [polls status, shows output if done]

"List all my avatars"
→ [shows all avatars with training status]
```

---

## Troubleshooting

### MCP Server won't start

```bash
# Check logs
npm run dev

# Common issues:
# - SUPABASE_URL or SUPABASE_SERVICE_KEY missing
# - AURORA_API_URL unreachable
# - Port 4200 already in use
```

### Claude can't reach the MCP server

```bash
# Check health
curl http://localhost:4200/health

# If using Docker:
# - Is the container running? docker ps
# - Is port 4200 exposed? docker run -p 4200:4200
```

### Generation jobs fail

```bash
# Check Supabase logs
# - Is AURORA_API_KEY valid?
# - Is Aurora backend running?

# Check job status
SELECT * FROM generation_jobs WHERE status = 'failed';
```

### Avatar training stuck

```bash
-- Check training status
SELECT * FROM avatars WHERE training_status = 'in_progress';

-- Manually check HeyGen/Sync.so API directly
-- If stuck >24h, manually update:
UPDATE avatars SET training_status = 'failed' WHERE id = 'avatar_id';
```

---

## Performance & Scaling

### Throughput

- **Concurrent requests**: Aurora backend + Supabase handle it; MCP is stateless
- **Job polling**: runs every 30 min; adjust interval in `avatar-creation.ts`
- **Large campaigns**: bulk_generate supports up to 50 images; split larger batches

### Optimization

1. **Use kling-2.5-turbo** as default (faster, cheaper)
2. **Batch jobs** — "12 posts" = 1 API call vs 12 calls
3. **Async polling** — don't block on training; let background job handle it
4. **Cache model selection** — reuse inference results

### Costs

| Model              | Cost/Job | Speed    | Quality |
|--------------------|----------|----------|---------|
| kling-2.5-turbo    | 50 cr.   | 1–3 min  | ★★★★☆  |
| kling-2.5          | 100 cr.  | 2–5 min  | ★★★★★  |
| heygen-v2          | 80 cr.   | 1–2 min  | ★★★☆☆  |
| wan-2.1            | 30 cr.   | 30s–2m   | ★★★★☆  |
| flux-1.1-pro       | 10 cr.   | 30–60s   | ★★★★★  |

---

## API Reference

### Create Avatar

```typescript
const result = await createAvatarWithTraining({
  name: 'Luna',
  imageUrls: ['https://...', ...],
  triggerWord: 'lunastyle',
  style: 'professional',
  trainLipsync: true,
});
// Returns: { id, name, status: 'training', estimatedHours: 2.5 }
```

### Generate Video

```typescript
const result = await auroraClient.generateVideo({
  prompt: 'Cinematic video',
  model: 'kling-2.5',
  aspect_ratio: '9:16',
  duration: 5,
  lora_id: 'optional_custom_lora',
});
// Returns: { job_id, status: 'processing', ... }
```

### Bulk Generate

```typescript
const result = await auroraClient.bulkGenerate({
  avatar_id: 'avatar_uuid',
  prompt_template: 'Aria posing at a café',
  count: 12,
  aspect_ratio: '4:5',
  variations: {
    locations: ['café', 'rooftop', 'beach'],
    outfits: ['casual', 'formal'],
    moods: ['confident', 'playful'],
  },
});
// Returns: { jobs: [...], total_credits: 120 }
```

---

## Support & Next Steps

1. **Get started**: Pick a path in QUICKSTART.md
2. **Test locally**: `npm run dev` in aurora-mcp/
3. **Add avatar creation**: Follow avatar-creation.ts
4. **Deploy**: docker-compose or CI/CD
5. **Monitor**: Check Supabase logs and job status

Questions? Check the code comments — they're detailed.

---

**Version**: 1.0.0  
**Last Updated**: June 2026  
**Status**: Production-Ready
