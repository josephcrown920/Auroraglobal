/**
 * avatar-creation.ts
 *
 * Complete avatar creation workflow for Aurora.
 * Trains LoRAs with HeyGen and Sync.so, stores results in Supabase.
 *
 * Usage:
 *   const avatarId = await createAvatarWithTraining({
 *     name: 'Sophia',
 *     imageUrls: ['https://...', ...],
 *     triggerWord: 'sphastyle',
 *     trainLipsync: true,
 *   });
 */

import { supabase } from './lib/supabase';

export interface AvatarCreationRequest {
  name: string;
  imageUrls: string[]; // 3-5 reference images
  triggerWord?: string; // LoRA trigger word
  style?: string; // 'professional', 'casual', 'athletic', etc.
  trainLipsync?: boolean; // Train Sync.so model for lipsync
}

export interface AvatarCreationResult {
  id: string;
  name: string;
  status: 'training' | 'ready' | 'failed';
  loraId: string;
  syncLoraId?: string;
  trainingStatus: 'pending' | 'in_progress' | 'completed' | 'failed';
  estimatedHours: number;
}

// ─── HeyGen LoRA Training ─────────────────────────────────────────────────────

async function submitHeyGenTraining(
  name: string,
  imageUrls: string[],
): Promise<{ trainingId: string; estimatedSeconds: number }> {
  const heygenKey = process.env.HEYGEN_API_KEY;
  if (!heygenKey) throw new Error('HEYGEN_API_KEY not set');

  // HeyGen expects video, but they have an image-to-video endpoint
  // For a real implementation, you'd stitch images into a short video or use their image API
  const payload = {
    avatar_name: name,
    reference_images: imageUrls,
    // These are HeyGen-specific; adjust per their actual API
  };

  const res = await fetch('https://api.heygen.com/v1/custom_avatar/create', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': heygenKey,
    },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`HeyGen API error [${res.status}]: ${err}`);
  }

  const data = (await res.json()) as {
    avatar_id?: string;
    training_id?: string;
    estimated_processing_time?: number;
  };

  return {
    trainingId: data.training_id || data.avatar_id || '',
    estimatedSeconds: data.estimated_processing_time || 7200, // default 2h
  };
}

// ─── Sync.so LoRA Training (Lipsync) ──────────────────────────────────────────

async function submitSyncTraining(
  name: string,
  imageUrls: string[],
): Promise<{ modelId: string; estimatedSeconds: number }> {
  const syncKey = process.env.SYNC_API_KEY;
  if (!syncKey) throw new Error('SYNC_API_KEY not set');

  const payload = {
    model_name: `${name.toLowerCase()}_lipsync`,
    reference_images: imageUrls,
    auto_optimize: true,
  };

  const res = await fetch('https://api.sync.so/v1/models/train', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${syncKey}`,
    },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const err = await res.text();
    console.warn(`Sync.so training failed [${res.status}]: ${err}`);
    // Don't throw — lipsync is optional, continue without it
    return { modelId: '', estimatedSeconds: 0 };
  }

  const data = (await res.json()) as {
    model_id?: string;
    id?: string;
    estimated_duration?: number;
  };

  return {
    modelId: data.model_id || data.id || '',
    estimatedSeconds: data.estimated_duration || 3600, // default 1h
  };
}

// ─── Poll HeyGen Status ───────────────────────────────────────────────────────

async function checkHeyGenStatus(
  trainingId: string,
): Promise<'processing' | 'completed' | 'failed'> {
  const heygenKey = process.env.HEYGEN_API_KEY;
  if (!heygenKey) throw new Error('HEYGEN_API_KEY not set');

  const res = await fetch(
    `https://api.heygen.com/v1/custom_avatar/${trainingId}/status`,
    {
      headers: { 'x-api-key': heygenKey },
    },
  );

  if (!res.ok) return 'failed';

  const data = (await res.json()) as { status?: string; state?: string };
  const status = data.status || data.state || '';

  if (status.toLowerCase().includes('complete')) return 'completed';
  if (status.toLowerCase().includes('fail')) return 'failed';
  return 'processing';
}

async function checkSyncStatus(
  modelId: string,
): Promise<'processing' | 'completed' | 'failed'> {
  if (!modelId) return 'completed'; // Skip if not training
  const syncKey = process.env.SYNC_API_KEY;
  if (!syncKey) return 'failed';

  const res = await fetch(`https://api.sync.so/v1/models/${modelId}/status`, {
    headers: { Authorization: `Bearer ${syncKey}` },
  });

  if (!res.ok) return 'failed';

  const data = (await res.json()) as { status?: string };
  const status = data.status || '';

  if (status.toLowerCase().includes('complete')) return 'completed';
  if (status.toLowerCase().includes('fail')) return 'failed';
  return 'processing';
}

// ─── Main Avatar Creation Flow ────────────────────────────────────────────────

export async function createAvatarWithTraining(
  req: AvatarCreationRequest,
): Promise<AvatarCreationResult> {
  const triggerWord = req.triggerWord || 'style';
  const style = req.style || 'general';

  console.log(`[avatar] Starting training for "${req.name}"...`);

  // 1. Submit HeyGen training
  let heygenTrainingId = '';
  let estimatedHours = 2;
  try {
    const hg = await submitHeyGenTraining(req.name, req.imageUrls);
    heygenTrainingId = hg.trainingId;
    estimatedHours = Math.ceil(hg.estimatedSeconds / 3600);
    console.log(`[avatar] HeyGen training submitted: ${heygenTrainingId}`);
  } catch (e) {
    console.error(`[avatar] HeyGen submission failed:`, e);
    throw e; // HeyGen is required
  }

  // 2. Optional: Submit Sync.so training
  let syncModelId = '';
  if (req.trainLipsync) {
    try {
      const sc = await submitSyncTraining(req.name, req.imageUrls);
      syncModelId = sc.modelId;
      console.log(`[avatar] Sync.so training submitted: ${syncModelId}`);
    } catch (e) {
      console.warn(`[avatar] Sync.so submission skipped:`, e);
      // Lipsync is optional; continue anyway
    }
  }

  // 3. Create avatar row in Supabase (training_status = 'pending')
  const { data: avatar, error } = await supabase
    .from('avatars')
    .insert({
      name: req.name,
      handle: `@${req.name.toLowerCase()}.ai`,
      lora_id: heygenTrainingId,
      sync_lora_id: syncModelId || null,
      trigger_word: triggerWord,
      style,
      preview_url: req.imageUrls[0],
      training_status: 'pending',
      training_submitted_at: new Date().toISOString(),
    })
    .select()
    .single();

  if (error) {
    console.error(`[avatar] Failed to insert avatar row:`, error);
    throw error;
  }

  console.log(`[avatar] Avatar created: ${avatar.id}`);

  return {
    id: avatar.id,
    name: avatar.name,
    status: 'training',
    loraId: heygenTrainingId,
    syncLoraId: syncModelId,
    trainingStatus: 'pending',
    estimatedHours,
  };
}

// ─── Background Job: Poll Training Status ─────────────────────────────────────

/**
 * Run this periodically (e.g., every 30 minutes via cron or Bull queue).
 * Checks all avatars in 'pending' or 'in_progress' state.
 */
export async function pollAvatarTrainingStatus() {
  console.log('[avatar] Polling training status...');

  // Get all avatars that are still training
  const { data: avatars, error } = await supabase
    .from('avatars')
    .select('*')
    .in('training_status', ['pending', 'in_progress']);

  if (error) {
    console.error('[avatar] Failed to fetch avatars:', error);
    return;
  }

  for (const avatar of avatars || []) {
    try {
      const hgStatus = await checkHeyGenStatus(avatar.lora_id);
      const syncStatus = avatar.sync_lora_id
        ? await checkSyncStatus(avatar.sync_lora_id)
        : 'completed';

      // All must be complete for avatar to be ready
      const allComplete = hgStatus === 'completed' && syncStatus === 'completed';
      const anyFailed = hgStatus === 'failed' || syncStatus === 'failed';

      let newStatus: 'pending' | 'in_progress' | 'completed' | 'failed';
      if (anyFailed) {
        newStatus = 'failed';
      } else if (allComplete) {
        newStatus = 'completed';
      } else {
        newStatus = 'in_progress';
      }

      // Update avatar
      const { error: updateErr } = await supabase
        .from('avatars')
        .update({ training_status: newStatus })
        .eq('id', avatar.id);

      if (updateErr) console.error(`[avatar] Update failed for ${avatar.id}:`, updateErr);
      else console.log(`[avatar] ${avatar.name}: ${newStatus}`);

      // If complete, mark as ready
      if (newStatus === 'completed') {
        console.log(`[avatar] ✓ ${avatar.name} is ready to use!`);
      }
    } catch (e) {
      console.error(`[avatar] Polling failed for ${avatar.id}:`, e);
    }
  }
}

// ─── Get Avatar Status (for UI) ───────────────────────────────────────────────

export async function getAvatarTrainingStatus(
  avatarId: string,
): Promise<AvatarCreationResult | null> {
  const { data: avatar } = await supabase
    .from('avatars')
    .select('*')
    .eq('id', avatarId)
    .single();

  if (!avatar) return null;

  return {
    id: avatar.id,
    name: avatar.name,
    status: avatar.training_status === 'completed' ? 'ready' : 'training',
    loraId: avatar.lora_id,
    syncLoraId: avatar.sync_lora_id,
    trainingStatus: avatar.training_status,
    estimatedHours: 2, // Could store per-avatar
  };
}

// ─── Export for Aurora MCP Tool ───────────────────────────────────────────────

export async function createAvatarViaTool(input: {
  name: string;
  image_urls: string[];
  trigger_word?: string;
  style?: string;
  lipsync?: boolean;
}) {
  const result = await createAvatarWithTraining({
    name: input.name,
    imageUrls: input.image_urls,
    triggerWord: input.trigger_word,
    style: input.style,
    trainLipsync: input.lipsync,
  });

  return {
    avatar_id: result.id,
    name: result.name,
    status: result.status,
    lora_id: result.loraId,
    sync_lora_id: result.syncLoraId,
    estimated_hours: result.estimatedHours,
    message: `Avatar "${result.name}" submitted for training. Check back in ~${result.estimatedHours}h.`,
  };
}
