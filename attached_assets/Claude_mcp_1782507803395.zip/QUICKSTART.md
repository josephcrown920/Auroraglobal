# Aurora MCP — Quick Start (5 min)

## Your 3 Integration Paths

Pick one based on your setup:

### Path 1: Claude Desktop (Easiest — 2 min)

You're already using Claude Desktop? Just plug in the MCP server.

```bash
# 1. Build the MCP server
cd aurora-mcp
npm install
npm run build

# 2. Edit ~/.claude/config.json (macOS/Linux) or %APPDATA%\Claude\config.json (Windows)
{
  "mcpServers": {
    "aurora": {
      "command": "node",
      "args": ["dist/index.js"],
      "cwd": "/absolute/path/to/aurora-mcp",
      "env": {
        "AURORA_API_URL": "http://localhost:3000",
        "AURORA_API_KEY": "your_api_key",
        "SUPABASE_URL": "https://your-project.supabase.co",
        "SUPABASE_SERVICE_KEY": "your_service_key",
        "PORT": "4200"
      }
    }
  }
}

# 3. Restart Claude Desktop
# 4. Try: "Make a 5s video of Sophia" in any chat
```

**Done.** No infrastructure needed. Claude Desktop connects to your local server.

---

### Path 2: Sidecar Service (Dev + Prod — 3 min)

Run MCP server as a separate process alongside Aurora.

```bash
# 1. Copy aurora-mcp into your monorepo
cp -r aurora-mcp ./services/aurora-mcp

# 2. Create .env
cd services/aurora-mcp
cat > .env << EOF
AURORA_API_URL=http://localhost:3000
AURORA_API_KEY=sk_live_xxx
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGc...
PORT=4200
HEYGEN_API_KEY=your_key
SYNC_API_KEY=your_key
EOF

# 3. Install & build
npm install
npm run build

# 4. Boot (dev)
npm run dev

# 5. Test
curl http://localhost:4200/health
# → { "status": "ok", "server": "aurora-mcp", "version": "1.0.0", "sessions": 0 }
```

**For Anthropic API calls**, point to `http://localhost:4200/sse`:

```typescript
// In your backend
const response = await fetch('https://api.anthropic.com/v1/messages', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    model: 'claude-sonnet-4-6',
    max_tokens: 4096,
    messages: [{ role: 'user', content: 'Make 12 IG posts for Aria this week' }],
    mcp_servers: [{
      type: 'url',
      url: 'http://localhost:4200/sse',  // ← Your MCP server
      name: 'aurora',
    }],
  }),
});
```

---

### Path 3: Embedded Route (Single Port — 5 min)

Add MCP as a route in your existing Aurora backend (same port, no extra service).

```typescript
// services/aurora-backend/src/routes/mcp.ts
import { Router } from 'express';
import { createAuroraMcpServer } from 'aurora-mcp/src/server';
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse';

const router = Router();
const mcpInstances = new Map<string, any>();

// SSE connection endpoint
router.get('/mcp/sse', async (req, res) => {
  const server = createAuroraMcpServer();
  const transport = new SSEServerTransport('/api/mcp/messages', res);
  mcpInstances.set(transport.sessionId, transport);

  res.on('close', () => mcpInstances.delete(transport.sessionId));
  await server.connect(transport);
});

// Message endpoint
router.post('/api/mcp/messages', async (req, res) => {
  const sessionId = req.query.sessionId as string;
  const transport = mcpInstances.get(sessionId);

  if (!transport) {
    res.status(404).json({ error: 'Session not found' });
    return;
  }

  await transport.handlePostMessage(req, res, req.body);
});

export default router;
```

Then wire it into your main server:

```typescript
// services/aurora-backend/src/index.ts
import express from 'express';
import mcpRouter from './routes/mcp';

const app = express();
app.use('/api', mcpRouter);  // ← Now your MCP is at /api/mcp/sse

app.listen(3000, () => console.log('Aurora + MCP on :3000'));
```

**Connect from API**:

```typescript
const response = await fetch('https://api.anthropic.com/v1/messages', {
  method: 'POST',
  body: JSON.stringify({
    mcp_servers: [{
      type: 'url',
      url: 'http://localhost:3000/api/mcp/sse',  // ← Same port!
      name: 'aurora',
    }],
    // ...
  }),
});
```

---

## Adding Avatar Creation

Once MCP is running, add the avatar creation tool:

### Step 1: Import avatar-creation.ts

```typescript
// src/tools/index.ts
import { createAvatarViaTool } from '../lib/avatar-creation';

export const createAvatarSchema = z.object({
  name:        z.string().describe('Avatar name'),
  image_urls:  z.array(z.string().url()).describe('3-5 reference images'),
  trigger_word: z.string().optional(),
  style:       z.string().optional(),
  lipsync:     z.boolean().optional().default(false),
});

export async function createAvatarTool(args: z.infer<typeof createAvatarSchema>) {
  return ok(await createAvatarViaTool(args));
}
```

### Step 2: Register the tool in server.ts

```typescript
// In createAuroraMcpServer()
server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    // ... existing 5 tools ...
    {
      name: 'aurora_create_avatar',
      description: 'Train a new avatar from reference images (2-4 hours)',
      inputSchema: zodToJsonSchema(createAvatarSchema),
    },
  ],
}));

server.setRequestHandler(CallToolRequestSchema, async (req) => {
  switch (req.params.name) {
    // ... existing cases ...
    case 'aurora_create_avatar':
      return createAvatarTool(createAvatarSchema.parse(req.params.arguments));
  }
});
```

### Step 3: Add polling job (background task)

```typescript
// services/aurora-backend/src/jobs/avatar-training-poller.ts
import { pollAvatarTrainingStatus } from '../lib/avatar-creation';

// Run every 30 minutes
setInterval(async () => {
  try {
    await pollAvatarTrainingStatus();
  } catch (e) {
    console.error('[polling] Failed:', e);
  }
}, 30 * 60 * 1000);
```

### Step 4: Set API keys in .env

```
HEYGEN_API_KEY=your_key_from_heygen
SYNC_API_KEY=your_key_from_sync
```

**Now you can**:

```
"Create an avatar named 'Luna' from these photos: [links]. Train lipsync too."

Claude: [calls aurora_create_avatar]
→ Avatar submitted for training. Check back in ~2 hours.
```

---

## Deployment (Docker)

### docker-compose.yml

```yaml
version: '3'
services:
  aurora-backend:
    build: ./services/aurora-backend
    ports: ['3000:3000']
    environment:
      AURORA_API_KEY: ${AURORA_API_KEY}
      SUPABASE_URL: ${SUPABASE_URL}
      SUPABASE_SERVICE_KEY: ${SUPABASE_SERVICE_KEY}

  aurora-mcp:
    build: ./services/aurora-mcp
    ports: ['4200:4200']
    environment:
      AURORA_API_URL: http://aurora-backend:3000
      AURORA_API_KEY: ${AURORA_API_KEY}
      SUPABASE_URL: ${SUPABASE_URL}
      SUPABASE_SERVICE_KEY: ${SUPABASE_SERVICE_KEY}
      HEYGEN_API_KEY: ${HEYGEN_API_KEY}
      SYNC_API_KEY: ${SYNC_API_KEY}
    depends_on:
      - aurora-backend
```

```bash
docker-compose up -d
```

---

## Testing (curl)

### Check MCP health

```bash
curl http://localhost:4200/health
```

### Call via Anthropic API

```bash
curl https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "content-type: application/json" \
  -d '{
    "model": "claude-sonnet-4-6",
    "max_tokens": 1024,
    "messages": [
      {"role": "user", "content": "Make a 5s cinematic video of Sophia"}
    ],
    "mcp_servers": [
      {
        "type": "url",
        "url": "http://localhost:4200/sse",
        "name": "aurora"
      }
    ]
  }'
```

---

## Checklist

- [ ] **Path chosen**: Claude Desktop / Sidecar / Embedded?
- [ ] **MCP server running**: `curl :4200/health` returns ok
- [ ] **Test basic generation**: "Make a 5s video of Sophia" works
- [ ] **Avatar creation added**: 6th tool registered
- [ ] **API keys set**: HEYGEN_API_KEY, SYNC_API_KEY in .env
- [ ] **Polling job running**: background task checks training status
- [ ] **Deployed**: Docker or production infra

---

## Support

**Issues?**

1. Check logs: `npm run dev` shows errors
2. Test API health: `curl http://localhost:4200/health`
3. Check Supabase connection: ensure SERVICE_KEY has admin privileges
4. Check Aurora API: ensure AURORA_API_KEY is valid
5. HeyGen/Sync.so keys: verify they're not expired or revoked
