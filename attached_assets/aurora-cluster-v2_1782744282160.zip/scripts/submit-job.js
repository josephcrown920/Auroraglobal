
#!/usr/bin/env node
/**
 * submit-job.js — submit jobs to the Aurora GPU cluster.
 *
 * Usage:
 *   node scripts/submit-job.js video   --type image2video --provider kling  --jobId <uuid> --imageUrl <url> --prompt "..."
 *   node scripts/submit-job.js lipsync --videoUrl <url> --audioUrl <url> --jobId <uuid>
 *   node scripts/submit-job.js image   --prompt "..." --jobId <uuid>
 *   node scripts/submit-job.js bulk    --count 5  (stress test)
 */

require('dotenv').config();
const { v4: uuid } = require('uuid');
const { submitVideo, submitLipsync, submitImage, getQueues } = require('../src/queue/queues');

async function parseArgs() {
  const args = process.argv.slice(2);
  const type = args[0];

  const flags = {};
  for (let i = 1; i < args.length; i += 2) {
    const key = args[i]?.replace(/^--/, '');
    flags[key] = args[i + 1];
  }

  return { type, flags };
}

async function main() {
  const { type, flags } = await parseArgs();

  switch (type) {
    // ─── Video ────────────────────────────────────────────────
    case 'video': {
      const jobId = flags.jobId || uuid();
      const job = await submitVideo({
        jobId,
        type:     flags.type     || 'image2video',
        provider: flags.provider || 'kling',
        payload: {
          imageUrl:  flags.imageUrl,
          prompt:    flags.prompt || 'A person speaking naturally',
          duration:  parseInt(flags.duration || '5', 10),
          aspectRatio: flags.aspectRatio || '9:16',
        },
        priority: parseInt(flags.priority || '100', 10),
      });
      console.log(`✅ Video job submitted: ${job.id} (jobId: ${jobId})`);
      break;
    }

    // ─── Lipsync ──────────────────────────────────────────────
    case 'lipsync': {
      const jobId = flags.jobId || uuid();
      const job = await submitLipsync({
        jobId,
        type: 'lipsync',
        payload: {
          videoUrl: flags.videoUrl,
          audioUrl: flags.audioUrl,
          model:    flags.model || 'sync-1.6.0',
        },
      });
      console.log(`✅ Lipsync job submitted: ${job.id} (jobId: ${jobId})`);
      break;
    }

    // ─── Image ────────────────────────────────────────────────
    case 'image': {
      const jobId = flags.jobId || uuid();
      const job = await submitImage({
        jobId,
        type: 'kolors',
        payload: {
          prompt:         flags.prompt || 'product photo, clean white background',
          negativePrompt: flags.negativePrompt || 'blurry, low quality',
          width:  parseInt(flags.width  || '1080', 10),
          height: parseInt(flags.height || '1920', 10),
        },
      });
      console.log(`✅ Image job submitted: ${job.id} (jobId: ${jobId})`);
      break;
    }

    // ─── Bulk stress test ─────────────────────────────────────
    case 'bulk': {
      const count = parseInt(flags.count || '10', 10);
      console.log(`Submitting ${count} test jobs...`);

      const promises = Array.from({ length: count }, (_, i) =>
        submitVideo({
          jobId: uuid(),
          type: 'text2video',
          provider: 'kling',
          payload: {
            prompt: `Test video ${i + 1}: beautiful nature scene`,
            duration: 5,
            aspectRatio: '9:16',
          },
          priority: 100 + i,
        })
      );

      await Promise.all(promises);
      console.log(`✅ Submitted ${count} jobs`);
      break;
    }

    // ─── Queue stats ──────────────────────────────────────────
    case 'stats': {
      const queues = getQueues();
      const [videoInfo, lipsyncInfo, imageInfo, dlqInfo] = await Promise.all([
        queues.video.getJobCounts(),
        queues.lipsync.getJobCounts(),
        queues.image.getJobCounts(),
        queues.dlq.getJobCounts(),
      ]);

      console.log('
═══ Queue Stats ═══');
      console.log('Video:  ', videoInfo);
      console.log('Lipsync:', lipsyncInfo);
      console.log('Image:  ', imageInfo);
      console.log('DLQ:    ', dlqInfo);
      break;
    }

    default:
      console.log(`
Usage:
  node scripts/submit-job.js video   --type image2video --provider kling --jobId <uuid> --imageUrl <url> --prompt "..."
  node scripts/submit-job.js lipsync --videoUrl <url> --audioUrl <url> --jobId <uuid>
  node scripts/submit-job.js image   --prompt "..."
  node scripts/submit-job.js bulk    --count 20
  node scripts/submit-job.js stats
      `);
  }

  process.exit(0);
}

main().catch(err => {
  console.error('Error:', err.message);
  process.exit(1);
});
