
#!/usr/bin/env node
'use strict';

const GPUWorkerSwarm = require('../src/workers/swarm');

const swarm = new GPUWorkerSwarm();
swarm.start();
