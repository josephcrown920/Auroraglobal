
require('dotenv').config();
const { smartDispatch } = require('../src/ai-orchestrator');

async function testGemini() {
  console.log('--- Testing Aurora Gemini Intelligence ---');
  
  const userPrompt = "I want to create a high-quality video of a futuristic cyberpunk city with neon lights and flying cars.";
  
  console.log(`User Input: "${userPrompt}"`);
  
  try {
    const job = await smartDispatch(userPrompt);
    console.log('✅ Gemini successfully dispatched the job.');
    console.log('Job Details:', job);
  } catch (err) {
    console.error('❌ Gemini Error:', err.message);
    console.log('Note: Ensure GEMINI_API_KEY is set in your .env file.');
  }
  
  process.exit(0);
}

testGemini();
