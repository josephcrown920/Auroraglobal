
// This script simply starts the BullMQ monitor defined in cluster/monitor.js
require('../cluster/monitor');

console.log('Monitor launch script executed. Monitor should be tracking metrics...');
