
// This script simply starts the BullMQ worker defined in cluster/worker.js
require('../cluster/worker');

console.log('Worker launch script executed. Worker should be listening for jobs...');
