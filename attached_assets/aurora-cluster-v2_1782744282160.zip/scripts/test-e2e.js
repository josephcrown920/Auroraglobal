
const { submitVideo } = require('../src/queue/queues');
const { updateJobStatus } = require('../src/supabase');
const { v4: uuid } = require('uuid');

async function testFlow() {
  console.log('--- Starting E2E Test ---');
  const jobId = uuid();
  
  console.log(`1. Submitting test job: ${jobId}`);
  try {
    await submitVideo({
      jobId,
      type: 'text2video',
      provider: 'heygen',
      payload: { prompt: 'Testing Aurora Cluster' }
    });
    console.log('✅ Job submitted to BullMQ.');

    console.log('2. Simulating Worker Update...');
    await updateJobStatus(jobId, 'processing', { notes: 'Testing link to Supabase' });
    console.log('✅ Supabase status updated.');

    console.log('--- Test Sequence Finished ---');
    console.log('Run "node scripts/submit-job.js stats" to see the queue depth.');
  } catch (err) {
    console.error('❌ Test failed:', err.message);
  }
  process.exit(0);
}

testFlow();
