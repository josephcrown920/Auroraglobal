
const config = require('../cluster/config');
const { createClient } = require('@supabase/supabase-js');
const { createJobQueue } = require('../cluster/queue');

console.log('Master process started.');
// console.log('Redis Host:', config.redis.host); // No longer directly access config.redis.host

// Initialize Supabase client
const supabase = createClient(config.SUPABASE_URL, config.SUPABASE_SERVICE_KEY);
console.log('Supabase client initialized.');

// Initialize BullMQ queue using the centralized function
const jobQueue = createJobQueue('gpu-jobs');
console.log('Job queue initialized.');

// Function to simulate job creation and dispatch
const dispatchJob = async () => {
  const jobId = `job-${Date.now()}`;
  const jobType = 'image_processing';
  const jobData = {
    jobId: jobId,
    type: jobType,
    input_data_path: `/data/${jobId}/input.jpg`,
    output_data_path: `/data/${jobId}/output.jpg`,
    model_name: 'resnet50',
    parameters: {
      brightness: 1.2,
      contrast: 1.0
    }
  };

  console.log(`Dispatching job: ${jobId} (Type: ${jobType})`);
  try {
    const job = await jobQueue.add(jobType, jobData, { jobId: jobId });
    console.log(`Job ${job.id} added to queue.`);

    // Insert initial job metadata into Supabase
    const { data, error } = await supabase
      .from('jobs') // Assuming a 'jobs' table exists in Supabase
      .insert(
        {
          job_id: jobData.jobId,
          type: jobData.type,
          status: 'queued',
          metadata: jobData, // Store all jobData as metadata
          created_at: new Date().toISOString()
        }
      );

    if (error) {
      console.error('Error inserting job metadata into Supabase:', error);
    } else {
      console.log('Job metadata inserted into Supabase:', data);
    }

  } catch (err) {
    console.error("Error dispatching job or inserting metadata:", err);
  }
};

// Dispatch a sample job after initialization
dispatchJob().catch(err => console.error("Unhandled promise rejection for dispatchJob:", err));

// Keep the process alive
setInterval(() => {
  // console.log('Master process alive...');
}, 60 * 60 * 1000); // Keep alive for a long time
