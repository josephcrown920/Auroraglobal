
const { spawn } = require("child_process");

async function testMCPDiscovery() {
  console.log("--- Testing MCP Tool Discovery ---");
  
  // Start the MCP server process in stdio mode
  const mcp = spawn("node", ["src/mcp-server.js"]);

  // Prepare the JSON-RPC request for listing tools
  const listToolsRequest = JSON.stringify({
    jsonrpc: "2.0",
    id: 1,
    method: "tools/list",
    params: {}
  }) + "\n";

  mcp.stdin.write(listToolsRequest);

  mcp.stdout.on("data", (data) => {
    const response = JSON.parse(data.toString());
    if (response.result && response.result.tools) {
      console.log("✅ MCP Server Discovery Successful!");
      console.log("Available Tools:", response.result.tools.map(t => t.name));
    }
    mcp.kill();
    process.exit(0);
  });

  mcp.stderr.on("data", (data) => {
    console.log(`[MCP Log]: ${data}`);
  });
}

testMCPDiscovery();
