
require('dotenv').config();

const required = [
  'SUPABASE_URL',
  'SUPABASE_SERVICE_KEY',
  'KLING_ACCESS_KEY',
  'KLING_SECRET_KEY',
  'HEYGEN_API_KEY',
  'SYNCS_API_KEY',
];

// Validate required vars on startup (not inside workers — master only)
function validate() {
  const missing = required.filter(k => !process.env[k]);
  if (missing.length) {
    throw new Error(`Missing required env vars: ${missing.join(', ')}`);
  }
}

const config = {
  // ─── Infrastructure ──────────────────────────────────────────
  REDIS_URL: process.env.REDIS_URL || 'redis://localhost:6379',

  // ─── Supabase ─────────────────────────────────────────────────
  SUPABASE_URL: process.env.SUPABASE_URL,
  SUPABASE_SERVICE_KEY: process.env.SUPABASE_SERVICE_KEY,

  // ─── Providers ────────────────────────────────────────────────
  KLING_ACCESS_KEY: process.env.KLING_ACCESS_KEY,
  KLING_SECRET_KEY: process.env.KLING_SECRET_KEY,
  HEYGEN_API_KEY: process.env.HEYGEN_API_KEY,
  SYNCS_API_KEY: process.env.SYNCS_API_KEY,

  // ─── Worker Swarm ─────────────────────────────────────────────
  NUM_WORKERS: parseInt(process.env.NUM_WORKERS || '8', 10),
  VIDEO_CONCURRENCY: parseInt(process.env.VIDEO_CONCURRENCY || '4', 10),
  LIPSYNC_CONCURRENCY: parseInt(process.env.LIPSYNC_CONCURRENCY || '6', 10),
  IMAGE_CONCURRENCY: parseInt(process.env.IMAGE_CONCURRENCY || '6', 10),
  MAX_WORKER_RESTARTS: parseInt(process.env.MAX_WORKER_RESTARTS || '10', 10),
  WORKER_RESTART_DELAY_MS: parseInt(process.env.WORKER_RESTART_DELAY_MS || '5000', 10),

  // ─── Circuit Breaker ──────────────────────────────────────────
  CB_FAILURE_THRESHOLD: parseInt(process.env.CB_FAILURE_THRESHOLD || '5', 10),
  CB_RECOVERY_TIMEOUT_MS: parseInt(process.env.CB_RECOVERY_TIMEOUT_MS || '120000', 10),

  // ─── Job Lifecycle ────────────────────────────────────────────
  JOB_ATTEMPTS: parseInt(process.env.JOB_ATTEMPTS || '3', 10),
  JOB_BACKOFF_MS: parseInt(process.env.JOB_BACKOFF_MS || '10000', 10),
  JOB_LOCK_DURATION_MS: parseInt(process.env.JOB_LOCK_DURATION_MS || '600000', 10),
  POLL_INTERVAL_MS: parseInt(process.env.POLL_INTERVAL_MS || '5000', 10),
  MAX_POLL_TIME_MS: parseInt(process.env.MAX_POLL_TIME_MS || '900000', 10),
};

module.exports = { config, validate };
