
const { Queue, QueueScheduler } = require('bullmq');
const { createClient } = require('@supabase/supabase-js');
const { config } = require('./config');

// Initialize Supabase client for job history
const supabase = createClient(config.SUPABASE_URL, config.SUPABASE_SERVICE_KEY);

// Initialize a Queue instance for monitoring (read-only usually)
const jobQueue = new Queue('gpu-jobs', {
  connection: {
    host: new URL(config.REDIS_URL).hostname,
    port: parseInt(new URL(config.REDIS_URL).port, 10),
    password: new URL(config.REDIS_URL).password?.substring(1) || undefined,
  },
});

// Initialize a QueueScheduler for handling delayed jobs, retries, etc.
// Note: This is usually run as a separate process.
const jobScheduler = new QueueScheduler('gpu-jobs', {
  connection: {
    host: new URL(config.REDIS_URL).hostname,
    port: parseInt(new URL(config.REDIS_URL).port, 10),
    password: new URL(config.REDIS_URL).password?.substring(1) || undefined,
  },
});

console.log('Monitor initialized.');

const getQueueMetrics = async () => {
  try {
    const metrics = await jobQueue.getJobCounts();
    console.log('Queue Metrics:', metrics);

    const waitingJobs = await jobQueue.getWaiting(0, 10);
    if (waitingJobs.length > 0) {
      console.log('Waiting Jobs (first 10):', waitingJobs.map(j => ({ id: j.id, name: j.name })));
    }

    const activeJobs = await jobQueue.getActive(0, 10);
    if (activeJobs.length > 0) {
      console.log('Active Jobs (first 10):', activeJobs.map(j => ({ id: j.id, name: j.name })));
    }

    const failedJobs = await jobQueue.getFailed(0, 10);
    if (failedJobs.length > 0) {
      console.log('Failed Jobs (first 10):', failedJobs.map(j => ({ id: j.id, name: j.name, failedReason: j.failedReason })));
    }

  } catch (err) {
    console.error('Error getting queue metrics:', err);
  }
};

const getSupabaseJobStatus = async (jobId = null) => {
  try {
    let query = supabase.from('jobs').select('*');
    if (jobId) {
      query = query.eq('job_id', jobId);
    }
    query = query.order('created_at', { ascending: false }).limit(jobId ? 1 : 10);

    const { data, error } = await query;

    if (error) {
      console.error('Error fetching jobs from Supabase:', error);
    } else if (data.length > 0) {
      console.log('Supabase Job Status:', data);
    } else {
      console.log('No jobs found in Supabase' + (jobId ? ` for jobId: ${jobId}` : '.'));
    }
  } catch (err) {
    console.error('Error in getSupabaseJobStatus:', err);
  }
};

// Periodically log metrics
setInterval(() => {
  console.log('
--- Monitor Snapshot ---');
  getQueueMetrics();
  getSupabaseJobStatus(); // Get latest jobs
  console.log('----------------------');
}, config.POLL_INTERVAL_MS || 5000);

// Keep the process alive
setInterval(() => {
  // console.log('Monitor process alive...');
}, 60 * 60 * 1000); // Keep alive for a long time

// Ensure scheduler closes cleanly on exit
process.on('SIGINT', async () => {
  console.log('Closing queue scheduler...');
  await jobScheduler.close();
  console.log('Queue scheduler closed.');
  process.exit(0);
});
