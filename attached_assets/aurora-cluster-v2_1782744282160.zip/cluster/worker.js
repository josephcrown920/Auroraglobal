
const { Worker } = require('bullmq');
const { createClient } = require('@supabase/supabase-js');
const { config } = require('./config');

// Initialize Supabase client for status updates
const supabase = createClient(config.SUPABASE_URL, config.SUPABASE_SERVICE_KEY);

// Define a processor function for the worker
const jobProcessor = async (job) => {
  const { jobId, type, ...jobData } = job.data;
  console.log(`Worker ${process.pid}: Processing job ${jobId} (Type: ${type})`);

  try {
    // Update job status to 'processing' in Supabase
    await supabase
      .from('jobs')
      .update({ status: 'processing', started_at: new Date().toISOString() })
      .eq('job_id', jobId);

    // Simulate GPU-intensive work based on job type
    let result;
    switch (type) {
      case 'image_processing':
        console.log(`Performing image processing for job ${jobId}...`);
        // Simulate a delay for processing
        await new Promise(resolve => setTimeout(resolve, 5000));
        result = { status: 'success', message: 'Image processed successfully', output_path: jobData.output_data_path };
        break;
      case 'image_rendering':
        console.log(`Performing image rendering for job ${jobId}...`);
        await new Promise(resolve => setTimeout(resolve, 8000));
        result = { status: 'success', message: 'Image rendered successfully', render_time_ms: 7500 };
        break;
      // Add more job types as needed
      default:
        throw new Error(`Unknown job type: ${type}`);
    }

    // Update job status to 'completed' and store results in Supabase
    await supabase
      .from('jobs')
      .update({ status: 'completed', completed_at: new Date().toISOString(), result: result })
      .eq('job_id', jobId);

    console.log(`Worker ${process.pid}: Job ${jobId} completed successfully.`);
    return result;

  } catch (error) {
    console.error(`Worker ${process.pid}: Error processing job ${jobId}:`, error.message);

    // Update job status to 'failed' in Supabase
    await supabase
      .from('jobs')
      .update({ status: 'failed', failed_at: new Date().toISOString(), error: error.message })
      .eq('job_id', jobId);

    throw error; // Re-throw to let BullMQ handle retries
  }
};

// Create a BullMQ worker
const worker = new Worker('gpu-jobs', jobProcessor, {
  connection: {
    host: new URL(config.REDIS_URL).hostname,
    port: parseInt(new URL(config.REDIS_URL).port, 10),
    password: new URL(config.REDIS_URL).password?.substring(1) || undefined,
  },
  concurrency: config.VIDEO_CONCURRENCY, // Example concurrency from config
});

worker.on('completed', job => {
  console.log(`Job ${job.id} has completed.`);
});

worker.on('failed', (job, err) => {
  console.error(`Job ${job.id} has failed with error ${err.message}`);
});

worker.on('error', err => {
  console.error('Worker error:', err);
});

console.log(`Worker ${process.pid} started for queue 'gpu-jobs' with concurrency ${config.VIDEO_CONCURRENCY}.`);

// Keep the process alive
setInterval(() => {
  // console.log('Worker process alive...');
}, 60 * 60 * 1000); // Keep alive for a long time
