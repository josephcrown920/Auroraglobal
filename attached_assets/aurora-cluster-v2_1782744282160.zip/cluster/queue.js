
const { Queue } = require('bullmq');
const config = require('./config');

const createJobQueue = (queueName) => {
  return new Queue(queueName, {
    connection: {
      host: new URL(config.REDIS_URL).hostname,
      port: parseInt(new URL(config.REDIS_URL).port, 10),
      password: new URL(config.REDIS_URL).password?.substring(1) || undefined,
    },
    defaultJobOptions: {
      attempts: config.JOB_ATTEMPTS,
      backoff: {
        type: 'exponential',
        delay: config.JOB_BACKOFF_MS,
      },
      removeOnComplete: 1000, // Keep 1000 completed jobs
      removeOnFail: 5000,     // Keep 5000 failed jobs
    },
  });
};

module.exports = { createJobQueue };
