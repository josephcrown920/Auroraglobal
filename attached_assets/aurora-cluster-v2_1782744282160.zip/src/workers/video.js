
const LocalGPUProvider = require('../../providers/local-gpu');
const { updateJobStatus } = require('../../supabase');

const localGPU = new LocalGPUProvider();

/**
 * Process a video generation job using LOCAL HARDWARE
 */
async function process(job) {
  const { jobId, type, payload, useLocal } = job.data;

  await updateJobStatus(jobId, 'processing', { started_at: new Date().toISOString(), mode: 'local-gpu' });
  await job.updateProgress(10);

  try {
    console.log(`[Local Worker] Running job ${jobId} on physical GPU...`);
    
    // This calls your local script instead of an API
    const result = await localGPU.generateLocal(payload);

    await job.updateProgress(100);
    await updateJobStatus(jobId, 'completed', {
      video_url: result.videoUrl,
      provider: 'local-hardware',
      completed_at: new Date().toISOString(),
    });

    return result;
  } catch (err) {
    await updateJobStatus(jobId, 'failed', { error: err.message });
    throw err;
  }
}

module.exports = { process };
