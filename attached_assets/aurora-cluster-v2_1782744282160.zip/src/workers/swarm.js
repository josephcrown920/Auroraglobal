
const { Worker } = require('bullmq');
const { createClient } = require('@supabase/supabase-js');
const { config } = require('../../cluster/config');

// Import specific job processors
const videoProcessor = require('./video');
const lipsyncProcessor = require('./lipsync');
const imageProcessor = require('./image');

// Initialize Supabase client (can be centralized if needed, but for swarm context, this is fine)
const supabase = createClient(config.SUPABASE_URL, config.SUPABASE_SERVICE_KEY);

class GPUWorkerSwarm {
  constructor() {
    this.workers = [];
    this.queueNames = {
      video: 'video-jobs',
      lipsync: 'lipsync-jobs',
      image: 'image-jobs',
    };
    console.log(`Initializing GPU Worker Swarm.`);
  }

  async jobProcessor(job) {
    const { jobId, type, provider } = job.data;
    console.log(`Worker ${process.pid} (Swarm): Processing job ${jobId} (Type: ${type}, Provider: ${provider})`);

    try {
      let result;
      switch (type) {
        case 'image2video':
        case 'text2video':
          result = await videoProcessor.process(job);
          break;
        case 'lipsync':
          result = await lipsyncProcessor.process(job);
          break;
        case 'kolors':
        case 'text2image':
          result = await imageProcessor.process(job);
          break;
        default:
          throw new Error(`Unknown job type: ${type}`);
      }
      return result;

    } catch (error) {
      console.error(`Worker ${process.pid} (Swarm): Error processing job ${jobId}:`, error.message);
      // The individual processors are responsible for updating Supabase with failed status
      // Re-throw to let BullMQ handle retries
      throw error;
    }
  }

  start() {
    const workerTypes = [
      { name: this.queueNames.video, concurrency: config.VIDEO_CONCURRENCY },
      { name: this.queueNames.lipsync, concurrency: config.LIPSYNC_CONCURRENCY },
      { name: this.queueNames.image, concurrency: config.IMAGE_CONCURRENCY },
    ];

    for (const workerType of workerTypes) {
      for (let i = 0; i < workerType.concurrency; i++) {
        const worker = new Worker(workerType.name, this.jobProcessor, {
          connection: {
            host: new URL(config.REDIS_URL).hostname,
            port: parseInt(new URL(config.REDIS_URL).port, 10),
            password: new URL(config.REDIS_URL).password?.substring(1) || undefined,
          },
          concurrency: 1, // Each individual BullMQ worker instance processes one job at a time
        });

        worker.on('completed', job => {
          console.log(`Worker ${worker.id} (${workerType.name}): Job ${job.id} has completed.`);
        });

        worker.on('failed', (job, err) => {
          console.error(`Worker ${worker.id} (${workerType.name}): Job ${job.id} has failed with error ${err.message}`);
        });

        worker.on('error', err => {
          console.error(`Worker ${worker.id} (${workerType.name}): Worker error:`, err);
        });

        this.workers.push(worker);
        console.log(`Swarm worker for queue '${workerType.name}' instance ${i + 1} started.`);
      }
    }
    console.log('GPU Worker Swarm started successfully.');

    // Keep the process alive
    setInterval(() => {
      // console.log('Swarm process alive...');
    }, 60 * 60 * 1000); // 1 hour
  }

  async stop() {
    console.log('Stopping GPU Worker Swarm...');
    await Promise.all(this.workers.map(worker => worker.close()));
    console.log('GPU Worker Swarm stopped.');
  }
}

module.exports = GPUWorkerSwarm;
