
const LocalGPUProvider = require('../../providers/local-gpu');
const { updateJobStatus } = require('../../supabase');
const localGPU = new LocalGPUProvider();

async function process(job) {
  const { jobId, payload } = job.data;
  await updateJobStatus(jobId, 'processing', { started_at: new Date().toISOString(), mode: 'local-gpu-lipsync' });
  try {
    const result = await localGPU.generateLocal(payload);
    await updateJobStatus(jobId, 'completed', {
      video_url: result.videoUrl,
      provider: 'local-hardware',
      completed_at: new Date().toISOString(),
    });
    return result;
  } catch (err) {
    await updateJobStatus(jobId, 'failed', { error: err.message });
    throw err;
  }
}
module.exports = { process };
