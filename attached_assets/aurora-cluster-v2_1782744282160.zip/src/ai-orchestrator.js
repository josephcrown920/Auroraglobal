
const { GoogleGenerativeAI } = require("@google/generative-ai");
const { submitVideo, submitImage } = require("./queue/queues");

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

async function smartDispatch(userPrompt) {
  const aiPrompt = `Analyze: "${userPrompt}". 
Return JSON: {"action": "video"|"image", "refinedPrompt": "..."}. Assume LOCAL hardware execution.`;
  const result = await model.generateContent(aiPrompt);
  const response = JSON.parse(result.response.text());

  if (response.action === "video") {
    return await submitVideo({ type: "local-video", payload: { prompt: response.refinedPrompt } });
  } else {
    return await submitImage({ type: "local-image", payload: { prompt: response.refinedPrompt } });
  }
}
module.exports = { smartDispatch };
