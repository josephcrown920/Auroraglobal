
const { Server } = require("@modelcontextprotocol/sdk/server/index.js");
const { StdioServerTransport } = require("@modelcontextprotocol/sdk/server/stdio.js");
const { CallToolRequestSchema, ListToolsRequestSchema } = require("@modelcontextprotocol/sdk/types.js");
const { submitVideo, submitImage } = require("./queue/queues");

const server = new Server({
  name: "aurora-gpu-cluster",
  version: "1.0.0",
}, {
  capabilities: { tools: {} }
});

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: "generate_video",
      description: "Submit a video generation job to the Aurora GPU cluster",
      inputSchema: {
        type: "object",
        properties: {
          prompt: { type: "string" },
          provider: { type: "string", enum: ["heygen", "kling"] },
          type: { type: "string", enum: ["text2video", "image2video"] }
        },
        required: ["prompt"]
      }
    }
  ]
}));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  if (request.params.name === "generate_video") {
    const job = await submitVideo({
      type: request.params.arguments.type || "text2video",
      provider: request.params.arguments.provider || "heygen",
      payload: { prompt: request.params.arguments.prompt }
    });
    return { content: [{ type: "text", text: `Job submitted successfully: ${job.id}` }] };
  }
  throw new Error("Tool not found");
});

async function run() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("Aurora MCP Server running on stdio");
}

run().catch(console.error);
