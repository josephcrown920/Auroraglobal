
const { createClient } = require('@supabase/supabase-js');
const { config } = require('../cluster/config');

const supabase = createClient(config.SUPABASE_URL, config.SUPABASE_SERVICE_KEY);

/**
 * Updates the status of a job in the Supabase 'jobs' table.
 * @param {string} jobId - The unique identifier of the job.
 * @param {string} status - The new status of the job (e.g., 'processing', 'completed', 'failed').
 * @param {object} metadata - Additional metadata to update (e.g., started_at, completed_at, error, result, video_url, image_urls).
 * @returns {Promise<object>} The updated job data or an error.
 */
async function updateJobStatus(jobId, status, metadata = {}) {
  console.log(`Supabase: Updating job ${jobId} to status '${status}' with metadata:`, metadata);
  const { data, error } = await supabase
    .from('jobs')
    .update({
      status: status,
      updated_at: new Date().toISOString(),
      ...metadata, // Spread additional metadata fields
    })
    .eq('job_id', jobId) // Match by job_id
    .select(); // Return the updated row

  if (error) {
    console.error(`Supabase: Error updating job ${jobId} status to '${status}':`, error);
    throw error;
  }
  console.log(`Supabase: Successfully updated job ${jobId} to status '${status}'.`);
  return data;
}

module.exports = {
  supabase,
  updateJobStatus,
};
