
const { Queue } = require('bullmq');
const { config } = require('../../cluster/config');

const defaultJobOptions = {
  attempts: config.JOB_ATTEMPTS,
  backoff: {
    type: 'exponential',
    delay: config.JOB_BACKOFF_MS,
  },
  removeOnComplete: 1000,
  removeOnFail: 5000,
};

const createNamedQueue = (name) => {
  return new Queue(name, {
    connection: {
      host: new URL(config.REDIS_URL).hostname,
      port: parseInt(new URL(config.REDIS_URL).port, 10),
      password: new URL(config.REDIS_URL).password?.substring(1) || undefined,
    },
    defaultJobOptions,
  });
};

const videoQueue = createNamedQueue('video-jobs');
const lipsyncQueue = createNamedQueue('lipsync-jobs');
const imageQueue = createNamedQueue('image-jobs');
const dlqQueue = createNamedQueue('dlq-jobs'); // Dead Letter Queue

const submitVideo = async (jobData) => {
  return videoQueue.add(jobData.type, jobData, { jobId: jobData.jobId, priority: jobData.priority });
};

const submitLipsync = async (jobData) => {
  return lipsyncQueue.add(jobData.type, jobData, { jobId: jobData.jobId });
};

const submitImage = async (jobData) => {
  return imageQueue.add(jobData.type, jobData, { jobId: jobData.jobId });
};

const getQueues = () => ({
  video: videoQueue,
  lipsync: lipsyncQueue,
  image: imageQueue,
  dlq: dlqQueue,
});

module.exports = {
  submitVideo,
  submitLipsync,
  submitImage,
  getQueues,
};
