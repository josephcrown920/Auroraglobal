
const { config } = require('../cluster/config');

class CircuitBreaker {
  constructor({ name, failureThreshold, recoveryTimeoutMs }) {
    this.name = name;
    this.failureThreshold = failureThreshold || config.CB_FAILURE_THRESHOLD;
    this.recoveryTimeoutMs = recoveryTimeoutMs || config.CB_RECOVERY_TIMEOUT_MS;
    this.state = 'CLOSED'; // CLOSED, OPEN, HALF_OPEN
    this.failureCount = 0;
    this.lastFailureTime = 0;
    console.log(`CircuitBreaker '${this.name}' initialized in ${this.state} state.`);
  }

  async execute(command) {
    if (this.state === 'OPEN') {
      // Check if it's time to transition to HALF_OPEN
      if (Date.now() - this.lastFailureTime > this.recoveryTimeoutMs) {
        this.state = 'HALF_OPEN';
        console.log(`CircuitBreaker '${this.name}' transitioned to HALF_OPEN.`);
      } else {
        throw new Error(`CircuitBreaker '${this.name}' is OPEN. Command blocked.`);
      }
    }

    try {
      const result = await command();
      // If successful, reset failure count and close the circuit if it was HALF_OPEN
      this.failureCount = 0;
      if (this.state === 'HALF_OPEN') {
        this.state = 'CLOSED';
        console.log(`CircuitBreaker '${this.name}' transitioned to CLOSED.`);
      }
      return result;
    } catch (error) {
      this.failureCount++;
      this.lastFailureTime = Date.now();
      console.warn(`CircuitBreaker '${this.name}': Command failed. Failure count: ${this.failureCount}.`);

      if (this.failureCount >= this.failureThreshold && this.state !== 'OPEN') {
        this.state = 'OPEN';
        console.error(`CircuitBreaker '${this.name}' transitioned to OPEN due to ${this.failureCount} failures.`);
      }
      throw error; // Re-throw the original error
    }
  }

  getState() {
    return this.state;
  }

  reset() {
    this.state = 'CLOSED';
    this.failureCount = 0;
    this.lastFailureTime = 0;
    console.log(`CircuitBreaker '${this.name}' reset to CLOSED.`);
  }
}

module.exports = CircuitBreaker;
