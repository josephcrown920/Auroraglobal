import React, { useState, useRef, useEffect } from 'react';
import { Paperclip, Send, Sparkles, Music, Film, Megaphone } from 'lucide-react';

/**
 * <AuroraAgent /> — glassmorphic, brand-matched chat UI for the brief→plan→render flow.
 *
 * Talks to a backend running auroraAgentRouter.js — three endpoints:
 *   POST /sessions, POST /sessions/:id/messages, POST /sessions/:id/generate
 *
 * Usage:
 *   <AuroraAgent apiBaseUrl="/api/aurora-agent" onComplete={(plan) => ...} />
 */

const BRAND = {
  blue: '#5B8DEF',
  purple: '#9B5DE5',
  pink: '#F15BB5',
};
const GRADIENT = `linear-gradient(135deg, ${BRAND.blue}, ${BRAND.purple} 55%, ${BRAND.pink})`;

const STARTERS = [
  { label: 'Plan a music video', icon: Music },
  { label: 'Build a viral two-scene hook', icon: Film },
  { label: 'Make a product commercial', icon: Megaphone },
  { label: 'Just chat', icon: Sparkles },
];

const PHASES = ['brief', 'plan', 'render'];

export default function AuroraAgent({ apiBaseUrl = '/api/aurora-agent', onComplete, className = '' }) {
  const [sessionId, setSessionId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [plan, setPlan] = useState(null);
  const [phase, setPhase] = useState('brief');
  const [busy, setBusy] = useState(false);
  const [quality, setQuality] = useState('2K');
  const [ratio, setRatio] = useState('9:16');
  const [renderLog, setRenderLog] = useState([]);
  const threadEndRef = useRef(null);

  useEffect(() => {
    threadEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, renderLog]);

  useEffect(() => {
    (async () => {
      const res = await fetch(`${apiBaseUrl}/sessions`, { method: 'POST' });
      const data = await res.json();
      setSessionId(data.sessionId);
    })();
  }, [apiBaseUrl]);

  async function send(text) {
    if (!text.trim() || !sessionId || busy) return;
    setMessages((m) => [...m, { role: 'user', text }]);
    setInput('');
    setBusy(true);
    try {
      const res = await fetch(`${apiBaseUrl}/sessions/${sessionId}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
      const data = await res.json();
      setMessages((m) => [...m, { role: 'agent', text: data.reply }]);
      if (data.plan?.scenes?.length) {
        setPlan(data.plan);
        setRatio(data.plan.ratio || ratio);
        setQuality(data.plan.quality || quality);
        setPhase('plan');
      }
    } catch (err) {
      setMessages((m) => [...m, { role: 'agent', text: 'Lost connection mid-thought — try that again?' }]);
    } finally {
      setBusy(false);
    }
  }

  async function runGeneration() {
    if (!sessionId || !plan) return;
    setPhase('render');
    setBusy(true);
    setRenderLog(plan.scenes.map((s) => ({ id: s.id, status: 'queued' })));
    try {
      const res = await fetch(`${apiBaseUrl}/sessions/${sessionId}/generate`, { method: 'POST' });
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let finalPlan = plan;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop();
        for (const line of lines) {
          if (!line.trim()) continue;
          const evt = JSON.parse(line);
          if (evt.type === 'scene') {
            setRenderLog((log) =>
              log.map((s) =>
                s.id === evt.scene.id
                  ? { id: s.id, status: evt.scene.outputUrl ? 'complete' : 'failed', url: evt.scene.outputUrl }
                  : s
              )
            );
          }
          if (evt.type === 'done') finalPlan = evt.plan;
        }
      }
      setPlan(finalPlan);
      onComplete?.(finalPlan);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className={`relative flex flex-col h-full w-full overflow-hidden bg-[#07070b] text-[#f1efea] ${className}`}>
      {/* Ambient aurora glow — decorative, behind everything */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div
          className="absolute -top-32 -left-24 w-72 h-72 rounded-full blur-[90px] opacity-30"
          style={{ background: BRAND.blue }}
        />
        <div
          className="absolute top-10 -right-20 w-80 h-80 rounded-full blur-[100px] opacity-25"
          style={{ background: BRAND.purple }}
        />
        <div
          className="absolute bottom-0 left-1/3 w-72 h-72 rounded-full blur-[110px] opacity-20"
          style={{ background: BRAND.pink }}
        />
      </div>

      {/* Header */}
      <div className="relative z-10 flex items-center gap-2.5 px-5 pt-5 pb-3.5 backdrop-blur-xl bg-white/[0.02] border-b border-white/[0.06]">
        <div
          className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
          style={{ background: GRADIENT }}
        >
          <Sparkles size={14} className="text-white" />
        </div>
        <span
          className="text-sm font-semibold tracking-tight bg-clip-text text-transparent"
          style={{ backgroundImage: GRADIENT }}
        >
          Aurora Agent
        </span>

        <div className="flex items-center gap-1.5 ml-auto">
          {PHASES.map((p, i) => (
            <React.Fragment key={p}>
              <span
                className="text-[10px] font-mono tracking-wider uppercase px-2 py-0.5 rounded-full border transition-colors"
                style={
                  phase === p
                    ? { borderColor: `${BRAND.purple}66`, color: '#fff', background: `${BRAND.purple}26` }
                    : { borderColor: 'rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.3)' }
                }
              >
                {p}
              </span>
              {i < PHASES.length - 1 && <span className="w-2 h-px bg-white/10" />}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Thread */}
      <div className="relative z-10 flex-1 overflow-y-auto px-5 py-4 space-y-3">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center gap-6 py-10">
            <p className="text-white/40 text-sm max-w-xs">
              Go back and forth with an agent to plan your video, shot by shot.
            </p>
            <div className="grid grid-cols-2 gap-2.5 w-full max-w-sm">
              {STARTERS.map(({ label, icon: Icon }, i) => (
                <button
                  key={label}
                  onClick={() => send(label)}
                  className="flex items-center gap-2 text-left text-xs text-white/75 backdrop-blur-md bg-white/[0.04] border border-white/[0.08] rounded-2xl px-3 py-3 hover:bg-white/[0.07] hover:border-white/[0.16] transition-all"
                >
                  <span
                    className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                    style={{ background: `${[BRAND.blue, BRAND.purple, BRAND.pink, BRAND.blue][i]}33` }}
                  >
                    <Icon size={13} style={{ color: [BRAND.blue, BRAND.purple, BRAND.pink, BRAND.blue][i] }} />
                  </span>
                  {label}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${
                m.role === 'user' ? 'text-white font-medium' : 'backdrop-blur-md bg-white/[0.05] border border-white/[0.06] text-white/90'
              }`}
              style={m.role === 'user' ? { background: GRADIENT } : undefined}
            >
              {m.text}
            </div>
          </div>
        ))}

        {phase === 'render' &&
          renderLog.map((s) => (
            <div key={s.id} className="flex items-center gap-2 text-xs font-mono text-white/50 px-1">
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  s.status === 'complete' ? 'bg-emerald-400' : s.status === 'failed' ? 'bg-red-400' : 'animate-pulse'
                }`}
                style={s.status === 'queued' ? { background: BRAND.purple } : undefined}
              />
              {s.id} — {s.status}
            </div>
          ))}

        <div ref={threadEndRef} />
      </div>

      {/* Generation panel */}
      {plan?.scenes?.length > 0 && phase !== 'render' && (
        <div className="relative z-10 mx-5 mb-3 rounded-2xl backdrop-blur-xl bg-white/[0.04] border border-white/[0.1] p-3 flex items-center gap-2 shadow-[0_8px_32px_rgba(0,0,0,0.4)]">
          <select
            value={quality}
            onChange={(e) => setQuality(e.target.value)}
            className="bg-white/[0.06] text-xs rounded-lg px-2 py-1.5 border border-white/[0.1] text-white/80 outline-none"
          >
            {['1K', '2K', '4K'].map((q) => (
              <option key={q} value={q} className="bg-[#0c0c10]">
                {q}
              </option>
            ))}
          </select>
          <select
            value={ratio}
            onChange={(e) => setRatio(e.target.value)}
            className="bg-white/[0.06] text-xs rounded-lg px-2 py-1.5 border border-white/[0.1] text-white/80 outline-none"
          >
            {['9:16', '16:9', '1:1'].map((r) => (
              <option key={r} value={r} className="bg-[#0c0c10]">
                {r}
              </option>
            ))}
          </select>
          <button
            onClick={runGeneration}
            disabled={busy}
            className="ml-auto flex items-center gap-1.5 text-white text-xs font-semibold rounded-xl px-4 py-1.5 disabled:opacity-50 shadow-lg"
            style={{ background: GRADIENT }}
          >
            <Sparkles size={13} /> Generate
          </button>
        </div>
      )}

      {/* Input bar */}
      {phase !== 'render' && (
        <div className="relative z-10 px-5 pb-5">
          <div className="flex items-end gap-2 backdrop-blur-xl bg-white/[0.04] border border-white/[0.1] rounded-2xl px-3 py-2.5 shadow-[0_8px_32px_rgba(0,0,0,0.4)]">
            <button className="text-white/40 hover:text-white/70 transition-colors p-1">
              <Paperclip size={16} />
            </button>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  send(input);
                }
              }}
              placeholder="Brief your agent — what do you want to make today?"
              rows={1}
              className="flex-1 bg-transparent resize-none outline-none text-sm placeholder:text-white/30 py-1 max-h-28"
            />
            <button
              onClick={() => send(input)}
              disabled={busy || !input.trim()}
              className="flex items-center gap-1.5 text-white text-xs font-semibold rounded-lg px-3 py-1.5 disabled:opacity-30 shrink-0"
              style={{ background: GRADIENT }}
            >
              <Send size={13} /> Send
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
