# Aurora Agent

A portable "brief → plan → render" agent for AI video generation. Backed by
Supabase, routed through a real inference layer with retry/fallback across
Kling and Seedance on fal.ai.

```
aurora-agent/
├── server/
│   ├── server.js                  # entry point — npm start
│   ├── auroraAgent.js             # core orchestrator + quickGenerate
│   ├── auroraAgentRouter.js       # Express routes
│   ├── inference/
│   │   ├── index.js               # provider routing, retries, fallback
│   │   └── providers/
│   │       ├── claude.js          # planning brain
│   │       ├── kling.js           # fal.ai Kling v2.6 pro
│   │       └── seedance.js        # fal.ai Seedance 2.0 fast
│   ├── store/
│   │   ├── memoryStore.js         # zero-config default
│   │   └── supabaseStore.js       # persistent sessions
│   ├── supabase/schema.sql        # run this in the Supabase SQL editor
│   └── test/test-generate.js      # generates a real video right now
├── client/AuroraAgent.jsx         # glassmorphic chat UI, Aurora-branded
├── package.json
└── .env.example
```

## 1. Install

```bash
cd aurora-agent
npm install
cp .env.example .env
```

Fill in `.env`:
- `FAL_KEY` — from fal.ai/dashboard/keys. **Required for any video.**
- `ANTHROPIC_API_KEY` — only needed for the chat/planning flow, not for the quick test below.
- `SUPABASE_URL` / `SUPABASE_SERVICE_ROLE_KEY` — optional. Without these, sessions live in memory and reset on restart.

## 2. Generate your first video right now

This is the fastest path to proving the whole pipeline works, before touching the UI or the planning conversation at all:

```bash
npm run test:generate
```

That calls fal.ai directly with a default cinematic prompt and prints back a real video URL. Pass your own prompt:

```bash
npm run test:generate -- "a neon-lit street at night, slow push-in, cinematic"
```

Only needs `FAL_KEY` — no Claude key, no Supabase, no server running. It typically takes 30 seconds to a few minutes depending on which provider picks it up.

> I can't run this from my end — this sandbox has no live network access, so I can't hit fal.ai directly. This script is built so *you* can verify generation works the moment you run it on Replit/locally.

## 3. Set up Supabase (optional but recommended)

1. Open the Supabase SQL editor for your project, run `server/supabase/schema.sql`.
2. Add `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` to `.env` (service role, not anon — this runs server-side only).
3. Restart the server. You'll see `using Supabase session store` in the logs instead of the in-memory fallback.

## 4. Run the full backend

```bash
npm start
```

Mounts everything at `/api/aurora-agent`:
- `POST /sessions` — start a planning conversation
- `POST /sessions/:id/messages` — chat turn
- `GET /sessions/:id` — current plan state
- `POST /sessions/:id/generate` — render the finalized plan (streams scene-by-scene)
- `POST /quick-generate` — same as `test:generate`, but as an HTTP endpoint

## 5. Frontend

```bash
npm install lucide-react   # if not already in your app
```

```jsx
import AuroraAgent from './aurora-agent/client/AuroraAgent';

<AuroraAgent
  apiBaseUrl="/api/aurora-agent"
  onComplete={(plan) => console.log('rendered plan', plan)}
  className="h-[640px] rounded-3xl overflow-hidden"
/>
```

Requires Tailwind in the host app. Brand gradient (blue → purple → pink) is pulled straight from the Aurora mark; ambient glow blobs behind the glass panels echo the logo's aurora motif.

## What the inference layer actually does

Each scene is routed to a provider (`server/inference/index.js`):
- Camera-movement-driven shots default to **Kling** (stronger structured camera control).
- Simple/static shots default to **Seedance** (faster, cheaper).
- Override per-scene with `scene.provider: 'kling' | 'seedance'`.
- Every call gets 2 retries with backoff; if a provider is fully down, it automatically falls back to the other one.

This is the seam to extend — add a new file in `inference/providers/`, register it in `PROVIDERS` in `inference/index.js`.

## Known landmines already fixed

- **`cameraMovement`** is sent as a structured `camera_control` field, not flattened into the prompt string.
- **`endFrameUrl`** / **`startFrameUrl`** are only sent when present.
- Generation uses the official `@fal-ai/client`, which handles queue polling internally — no hand-rolled status loop to get wrong.
- Confirmed-current model endpoints as of this build: `fal-ai/kling-video/v2.6/pro/text-to-video` and `bytedance/seedance-2.0/fast/text-to-video`. fal.ai ships new versions often — if either 404s, check fal.ai/models for the current slug and update `DEFAULT_MODEL` in the relevant provider file.
