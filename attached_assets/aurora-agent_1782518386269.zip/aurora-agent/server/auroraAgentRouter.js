/**
 * Express wiring for Aurora Agent.
 *
 * Mount with:
 *   const auroraAgentRouter = require('./auroraAgentRouter');
 *   app.use('/api/aurora-agent', auroraAgentRouter);
 */

const express = require('express');
const { createAuroraAgent } = require('./auroraAgent');
const { callModel } = require('./inference/providers/claude');
const { createMemoryStore } = require('./store/memoryStore');
const { createSupabaseStore } = require('./store/supabaseStore');

function resolveStore() {
  if (process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY) {
    console.log('[aurora-agent] using Supabase session store');
    return createSupabaseStore();
  }
  console.log(
    '[aurora-agent] SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY not set — using in-memory store (sessions reset on restart)'
  );
  return createMemoryStore();
}

const router = express.Router();
const agent = createAuroraAgent({ callModel, store: resolveStore() });

router.post('/sessions', async (req, res) => {
  try {
    res.json(await agent.createSession());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/sessions/:id/messages', async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: 'text is required' });
    res.json(await agent.sendMessage(req.params.id, text));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/sessions/:id', async (req, res) => {
  try {
    res.json(await agent.getSession(req.params.id));
  } catch (err) {
    res.status(404).json({ error: err.message });
  }
});

router.post('/sessions/:id/generate', async (req, res) => {
  try {
    res.setHeader('Content-Type', 'application/x-ndjson');
    const result = await agent.generate(req.params.id, {
      onSceneComplete: (scene) => res.write(JSON.stringify({ type: 'scene', scene }) + '\n'),
    });
    res.write(JSON.stringify({ type: 'done', plan: result.plan }) + '\n');
    res.end();
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Instant single-scene test path — no conversation, no session needed.
router.post('/quick-generate', async (req, res) => {
  try {
    const { prompt, ratio, quality, cameraMovement, durationSeconds, provider } = req.body;
    if (!prompt) return res.status(400).json({ error: 'prompt is required' });
    const result = await agent.quickGenerate({ prompt, ratio, quality, cameraMovement, durationSeconds, provider });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
