-- Aurora Agent — session storage
-- Run this in the Supabase SQL editor for your project.

create table if not exists aurora_agent_sessions (
  id uuid primary key,
  plan jsonb not null default '{}'::jsonb,
  messages jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists aurora_agent_sessions_updated_at_idx
  on aurora_agent_sessions (updated_at desc);

-- Lock the table down: the backend talks to Supabase using the service-role
-- key, which bypasses RLS entirely. Enabling RLS with zero policies means
-- no anon/public client can read or write sessions directly.
alter table aurora_agent_sessions enable row level security;
