/**
 * Aurora Agent — core orchestrator.
 *
 * Two independent capabilities live here:
 *   1. The planning conversation (createSession / sendMessage / generate) —
 *      requires a `callModel` (the LLM running the chat).
 *   2. quickGenerate — a single-scene generation call that bypasses the
 *      conversation entirely. No LLM, no session, no plan-building. Use this
 *      to verify your fal.ai/Kling/Seedance keys work before wiring up the
 *      full chat flow.
 */

const { randomUUID } = require('crypto');
const { runInference } = require('./inference');
const { createMemoryStore } = require('./store/memoryStore');

function emptyPlan() {
  return {
    title: null,
    ratio: '9:16',
    quality: '2K',
    scenes: [],
    status: 'drafting', // drafting -> ready -> generating -> complete -> failed
  };
}

const SYSTEM_PROMPT = `You are Aurora Agent, a sharp, fast-moving creative director helping someone plan a short AI-generated video (music video, viral hook, product commercial, or freeform).

Your job in conversation:
- Ask only what you need to move forward — never more than one or two questions per turn.
- Infer sensible defaults instead of interrogating (e.g. assume 9:16 for social unless told otherwise).
- Think in shots: each scene needs a concrete visual description and a camera movement (push_in, pull_out, pan_left, pan_right, orbit, static, handheld).
- Keep tone collaborative and fast — like a director thinking out loud with the user, not a chatbot reading a checklist.

Structured output rule:
Once you have enough to define at least one real scene, append a plan block at the very end of your reply, after your normal conversational text, in exactly this form:
<plan>{"title":"...","ratio":"9:16","quality":"2K","scenes":[{"id":"scene_1","prompt":"...","cameraMovement":"push_in","durationSeconds":5}],"status":"drafting"}</plan>

Rules for the plan block:
- Always emit the FULL current plan (not a diff) — it fully replaces the previous one.
- Set "status" to "ready" only when the user confirms they're happy and want to generate.
- Never mention the <plan> tag or JSON to the user — it is parsed out automatically and never shown to them.
- If there isn't yet enough to define a scene, omit the <plan> block entirely.`;

function extractPlan(rawReply) {
  const match = rawReply.match(/<plan>([\s\S]*?)<\/plan>/);
  if (!match) return { displayText: rawReply.trim(), plan: null };

  const displayText = rawReply.slice(0, match.index).trim();
  let plan = null;
  try {
    plan = JSON.parse(match[1]);
  } catch (err) {
    plan = null; // malformed JSON from the model — keep the conversation going
  }
  return { displayText, plan };
}

/**
 * @param {object} opts
 * @param {(messages: {role:string, content:string}[]) => Promise<string>} [opts.callModel]
 *   Required for createSession/sendMessage. Not needed for quickGenerate alone.
 * @param {(scene: object, plan: object) => Promise<{url:string}>} [opts.generateScene]
 *   Defaults to the bundled inference layer (Kling/Seedance via fal.ai).
 * @param {{get,set}} [opts.store] Defaults to in-memory.
 */
function createAuroraAgent({ callModel, generateScene, store } = {}) {
  const infer = generateScene || ((scene, plan) => runInference(scene, plan));
  const sessionStore = store || createMemoryStore();

  function requireCallModel() {
    if (typeof callModel !== 'function') {
      throw new Error(
        'Aurora Agent: callModel is required for the planning conversation. Pass inference/providers/claude (and set ANTHROPIC_API_KEY), or your own LLM function.'
      );
    }
  }

  async function createSession() {
    requireCallModel();
    const id = randomUUID();
    const session = {
      id,
      plan: emptyPlan(),
      messages: [{ role: 'system', content: SYSTEM_PROMPT }],
      createdAt: Date.now(),
    };
    await sessionStore.set(id, session);
    return {
      sessionId: id,
      greeting: 'Brief me — what do you want to make today?',
      starters: [
        { label: 'Plan a music video', icon: 'music' },
        { label: 'Build a viral two-scene hook', icon: 'film' },
        { label: 'Make a product commercial', icon: 'megaphone' },
        { label: 'Just chat', icon: 'sparkles' },
      ],
    };
  }

  async function sendMessage(sessionId, userText) {
    requireCallModel();
    const session = await sessionStore.get(sessionId);
    if (!session) throw new Error('Unknown session');

    session.messages.push({ role: 'user', content: userText });

    const rawReply = await callModel(session.messages);
    const { displayText, plan } = extractPlan(rawReply);

    session.messages.push({ role: 'assistant', content: rawReply });
    if (plan) session.plan = plan;
    await sessionStore.set(sessionId, session);

    return {
      reply: displayText,
      plan: session.plan,
      readyToGenerate: session.plan.status === 'ready' && session.plan.scenes.length > 0,
    };
  }

  async function generate(sessionId, { onSceneComplete } = {}) {
    const session = await sessionStore.get(sessionId);
    if (!session) throw new Error('Unknown session');
    if (!session.plan.scenes.length) throw new Error('Plan has no scenes yet');

    session.plan.status = 'generating';
    await sessionStore.set(sessionId, session);

    const results = [];
    for (const scene of session.plan.scenes) {
      try {
        const { url } = await infer(scene, session.plan);
        scene.outputUrl = url;
        results.push({ sceneId: scene.id, url, status: 'complete' });
      } catch (err) {
        scene.error = err.message;
        results.push({ sceneId: scene.id, status: 'failed', error: err.message });
      }
      if (onSceneComplete) onSceneComplete(scene);
      await sessionStore.set(sessionId, session);
    }

    session.plan.status = results.every((r) => r.status === 'complete') ? 'complete' : 'failed';
    await sessionStore.set(sessionId, session);
    return { plan: session.plan, results };
  }

  async function getSession(sessionId) {
    const session = await sessionStore.get(sessionId);
    if (!session) throw new Error('Unknown session');
    return { sessionId, plan: session.plan };
  }

  /**
   * Bypasses the planning conversation entirely — one scene, straight to a
   * provider. No ANTHROPIC_API_KEY needed. This is the fastest way to prove
   * your FAL_KEY and provider wiring actually work end to end.
   */
  async function quickGenerate({ prompt, ratio = '9:16', quality = '2K', cameraMovement, durationSeconds = 5, provider } = {}) {
    if (!prompt) throw new Error('quickGenerate: prompt is required');
    const plan = { title: 'Quick test', ratio, quality, scenes: [], status: 'ready' };
    const scene = { id: 'scene_1', prompt, cameraMovement, durationSeconds, provider };
    const result = await infer(scene, plan);
    scene.outputUrl = result.url;
    plan.scenes = [scene];
    plan.status = 'complete';
    return { ...result, scene, plan };
  }

  return { createSession, sendMessage, generate, getSession, quickGenerate };
}

module.exports = { createAuroraAgent, emptyPlan, extractPlan, SYSTEM_PROMPT };
