function createMemoryStore() {
  const sessions = new Map();
  return {
    async get(id) {
      return sessions.get(id) || null;
    },
    async set(id, session) {
      sessions.set(id, session);
      return session;
    },
  };
}

module.exports = { createMemoryStore };
