/**
 * Supabase session store — persists agent sessions (conversation + plan)
 * across restarts/instances. Uses the service-role key since this runs
 * server-side; RLS stays locked down (no policies = service role only).
 *
 * Schema: see ../supabase/schema.sql
 */

const { createClient } = require('@supabase/supabase-js');

function createSupabaseStore({
  url = process.env.SUPABASE_URL,
  serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY,
  table = 'aurora_agent_sessions',
} = {}) {
  if (!url || !serviceRoleKey) {
    throw new Error(
      'createSupabaseStore: SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are required (set them in .env, or pass a different store)'
    );
  }

  const supabase = createClient(url, serviceRoleKey);

  return {
    async get(id) {
      const { data, error } = await supabase.from(table).select('*').eq('id', id).maybeSingle();
      if (error) throw error;
      if (!data) return null;
      return { id: data.id, plan: data.plan, messages: data.messages, createdAt: data.created_at };
    },
    async set(id, session) {
      const { error } = await supabase.from(table).upsert({
        id,
        plan: session.plan,
        messages: session.messages,
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
      return session;
    },
  };
}

module.exports = { createSupabaseStore };
