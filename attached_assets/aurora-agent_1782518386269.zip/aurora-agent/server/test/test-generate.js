/**
 * Run this to generate your first real video right now, no chat UI needed:
 *
 *   npm run test:generate
 *   npm run test:generate -- "a neon-lit Port Harcourt street at night, slow push-in, cinematic"
 *
 * Only needs FAL_KEY — this bypasses the planning conversation entirely
 * (so ANTHROPIC_API_KEY isn't required just to prove generation works).
 */

require('dotenv').config();
const path = require('path');
const { createAuroraAgent } = require(path.join(__dirname, '..', 'auroraAgent'));

(async () => {
  if (!process.env.FAL_KEY) {
    console.error('Missing FAL_KEY in your .env — get one from fal.ai/dashboard/keys, then re-run.');
    process.exit(1);
  }

  const agent = createAuroraAgent({}); // no callModel needed for quickGenerate

  const prompt =
    process.argv[2] ||
    'A glowing aurora rippling over a dark mountain ridge at night, slow cinematic push-in, no people, photorealistic';

  console.log(`\nGenerating test clip:\n"${prompt}"\n`);
  console.log('(this calls the live fal.ai queue — typically 30s to a few minutes depending on provider/load)\n');

  try {
    const result = await agent.quickGenerate({
      prompt,
      ratio: '9:16',
      quality: '2K',
      cameraMovement: 'push_in',
      durationSeconds: 5,
    });
    console.log(`Done via ${result.provider}.\nVideo URL:\n${result.url}\n`);
  } catch (err) {
    console.error('Generation failed:', err.message);
    process.exit(1);
  }
})();
