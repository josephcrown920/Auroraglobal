/**
 * Inference layer — sits between the agent's plan and the actual video
 * providers. Responsibilities:
 *   - pick a provider per scene (explicit override, or a sane default rule)
 *   - retry transient failures with backoff
 *   - fall back to a different provider if one is down/erroring out
 *
 * This is the seam to extend when you add Runway, Luma, etc — just add a
 * provider module with a `generate(scene, plan)` export and register it
 * in PROVIDERS below.
 */

const kling = require('./providers/kling');
const seedance = require('./providers/seedance');

const PROVIDERS = {
  kling: kling.generate,
  seedance: seedance.generate,
};

/**
 * Default routing rule: camera-movement-driven shots lean on Kling (stronger
 * structured camera control), simple/fast shots default to Seedance.
 * Override per-scene with `scene.provider: 'kling' | 'seedance'`.
 */
function pickProvider(scene) {
  if (scene.provider && PROVIDERS[scene.provider]) return scene.provider;
  return scene.cameraMovement && scene.cameraMovement !== 'static' ? 'kling' : 'seedance';
}

async function runInference(scene, plan, { retries = 2, fallback = true, backoffMs = 1500 } = {}) {
  const primary = pickProvider(scene);
  const order = fallback ? [primary, ...Object.keys(PROVIDERS).filter((p) => p !== primary)] : [primary];

  let lastError;
  for (const providerName of order) {
    const generateFn = PROVIDERS[providerName];
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        return await generateFn(scene, plan);
      } catch (err) {
        lastError = err;
        if (attempt < retries) {
          await new Promise((r) => setTimeout(r, backoffMs * (attempt + 1)));
        }
      }
    }
    // exhausted retries on this provider — fall through to the next one
  }
  throw lastError || new Error('Inference failed with no specific error');
}

module.exports = { runInference, PROVIDERS, pickProvider };
