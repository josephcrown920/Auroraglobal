/**
 * Seedance provider — text-to-video via fal.ai using the official @fal-ai/client.
 * Endpoint confirmed current as of fal.ai docs: bytedance/seedance-2.0/fast/text-to-video
 * (the "fast" tier — swap to "bytedance/seedance-2.0/text-to-video" for the
 * standard/higher-quality tier, or override per-scene with `scene.model`).
 */

const { fal } = require('@fal-ai/client');

fal.config({ credentials: process.env.FAL_KEY });

const DEFAULT_MODEL = 'bytedance/seedance-2.0/fast/text-to-video';

async function generate(scene, plan) {
  const input = {
    prompt: scene.prompt,
    duration: String(scene.durationSeconds || 5),
    resolution: plan.quality === '4K' ? '1080p' : '720p',
    aspect_ratio: plan.ratio || '9:16',
  };

  const result = await fal.subscribe(scene.model || DEFAULT_MODEL, { input, logs: false });
  const url = result?.data?.video?.url;
  if (!url) throw new Error('Seedance returned no video url');

  return { url, provider: 'seedance', model: scene.model || DEFAULT_MODEL, raw: result.data };
}

module.exports = { generate, DEFAULT_MODEL };
