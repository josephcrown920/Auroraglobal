/**
 * Kling provider — text-to-video via fal.ai using the official @fal-ai/client.
 * Endpoint confirmed current as of fal.ai docs: fal-ai/kling-video/v2.6/pro/text-to-video
 * (override per-scene with `scene.model` if you want a different Kling version/tier).
 */

const { fal } = require('@fal-ai/client');

fal.config({ credentials: process.env.FAL_KEY });

const DEFAULT_MODEL = 'fal-ai/kling-video/v2.6/pro/text-to-video';

async function generate(scene, plan) {
  const input = {
    prompt: scene.prompt,
    duration: String(scene.durationSeconds || 5),
    aspect_ratio: plan.ratio || '9:16',
  };

  // Structured camera movement — this is the field that's bitten us before
  // when it got flattened into the prompt string instead of sent as data.
  // NOTE: confirm the exact shape against the live schema for whichever
  // Kling version you pin (`DEFAULT_MODEL` above) — it has shifted slightly
  // between v2.1 / v2.5 / v2.6 on fal.
  if (scene.cameraMovement && scene.cameraMovement !== 'static') {
    input.camera_control = { type: scene.cameraMovement };
  }

  if (scene.endFrameUrl) input.end_image_url = scene.endFrameUrl;
  if (scene.startFrameUrl) input.image_url = scene.startFrameUrl;

  const result = await fal.subscribe(scene.model || DEFAULT_MODEL, { input, logs: false });
  const url = result?.data?.video?.url;
  if (!url) throw new Error('Kling returned no video url');

  return { url, provider: 'kling', model: scene.model || DEFAULT_MODEL, raw: result.data };
}

module.exports = { generate, DEFAULT_MODEL };
