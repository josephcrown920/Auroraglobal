require('dotenv').config();
const express = require('express');
const auroraAgentRouter = require('./auroraAgentRouter');

const app = express();
app.use(express.json());
app.use('/api/aurora-agent', auroraAgentRouter);

app.get('/health', (_req, res) => res.json({ ok: true }));

const port = process.env.PORT || 8787;
app.listen(port, () => {
  console.log(`Aurora Agent backend listening on :${port}`);
  console.log(`Try it now:  npm run test:generate`);
});
