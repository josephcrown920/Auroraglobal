
# AI Media Platform (Refactored)

## Architecture
- API Layer → enqueue jobs + charge credits
- Queue Table → generation_jobs
- Worker → processes orchestrate()
- Storage → external via orchestrate result

## Flow
1. API creates job
2. credits reserved
3. worker processes job
4. result stored + DB updated

## Next Step
Run worker service separately.
