
import { enqueueJob } from "./queue";
import { chargeCredits } from "./charge";

export async function generateImage(supabase: any, supabaseAdmin: any, userId: string, payload: any) {

  const job = await enqueueJob(supabase, {
    user_id: userId,
    type: "image",
    model: payload.model,
    payload,
    status: "queued",
  });

  await chargeCredits(supabaseAdmin, userId, 1, "image_generation", job.id);

  return { jobId: job.id };
}
