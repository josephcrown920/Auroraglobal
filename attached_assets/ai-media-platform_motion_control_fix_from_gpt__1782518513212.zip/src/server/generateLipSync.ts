
import { enqueueJob } from "./queue";
import { chargeCredits } from "./charge";

export async function generateLipSync(supabase: any, supabaseAdmin: any, userId: string, payload: any) {

  const job = await enqueueJob(supabase, {
    user_id: userId,
    type: "lipsync",
    model: payload.model,
    payload,
    status: "queued",
  });

  await chargeCredits(supabaseAdmin, userId, 3, "lipsync", job.id);

  return { jobId: job.id };
}
