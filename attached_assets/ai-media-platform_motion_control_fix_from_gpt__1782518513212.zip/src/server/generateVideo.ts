
import { enqueueJob } from "./queue";
import { chargeCredits } from "./charge";

export async function generateVideo(supabase: any, supabaseAdmin: any, userId: string, payload: any) {

  const job = await enqueueJob(supabase, {
    user_id: userId,
    type: "video",
    model: payload.model,
    payload,
    status: "queued",
  });

  await chargeCredits(supabaseAdmin, userId, 5, "video_generation", job.id);

  return { jobId: job.id };
}
