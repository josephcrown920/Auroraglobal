
import { MODEL_REGISTRY } from "./modelRegistry";

export async function processJob(job: any, orchestrate: any, supabase: any) {
  try {
    await supabase.from("generation_jobs").update({ status: "processing" }).eq("id", job.id);

    const config = MODEL_REGISTRY[job.model] || { provider: "orchestrator" };

    const result = await orchestrate({
      ...job.payload,
      model: job.model,
      provider: config.provider,
    });

    await supabase.from("generation_jobs").update({
      status: "done",
      result_url: result.url,
    }).eq("id", job.id);

  } catch (e: any) {
    await supabase.from("generation_jobs").update({
      status: "failed",
      error: e.message,
    }).eq("id", job.id);
  }
}
