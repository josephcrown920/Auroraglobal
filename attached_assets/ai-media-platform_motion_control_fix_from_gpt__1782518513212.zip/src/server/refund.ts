
export async function refundCredits(supabaseAdmin: any, userId: string, amount: number, refId: string) {
  await supabaseAdmin.rpc("release_credits", {
    _user: userId,
    _amount: amount,
    _ref: refId,
  });
}
