
export async function enqueueJob(supabase: any, job: any) {
  const { data, error } = await supabase
    .from("generation_jobs")
    .insert(job)
    .select()
    .single();

  if (error) throw new Error(error.message);
  return data;
}
