
export async function listGallery(supabase: any, userId: string) {
  const { data } = await supabase
    .from("generation_jobs")
    .select("*")
    .eq("user_id", userId)
    .eq("status", "done")
    .order("created_at", { ascending: false });

  return data || [];
}
