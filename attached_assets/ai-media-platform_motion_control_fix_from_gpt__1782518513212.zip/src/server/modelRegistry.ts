
export const MODEL_REGISTRY: Record<string, { provider: string; type: string }> = {
  "gemini-2.5": { provider: "lovable", type: "image" },
  "seedance-2.0": { provider: "replicate", type: "video" },
  "wav2lip": { provider: "fal", type: "lipsync" },
};
