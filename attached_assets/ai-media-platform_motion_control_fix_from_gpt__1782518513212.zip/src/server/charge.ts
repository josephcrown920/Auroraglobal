
export async function chargeCredits(supabaseAdmin: any, userId: string, amount: number, reason: string, refId: string) {
  const { data, error } = await supabaseAdmin.rpc("reserve_credits", {
    _user: userId,
    _amount: amount,
    _reason: reason,
    _ref: refId,
  });

  if (error) throw new Error(error.message);
  if (data === false) throw new Error("Insufficient credits");
}
