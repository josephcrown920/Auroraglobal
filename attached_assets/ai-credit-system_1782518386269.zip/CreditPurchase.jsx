// ============================================
// CREDIT PURCHASE COMPONENT (React)
// Shows credit packages and payment flow
// ============================================

import React, { useState } from 'react';
import { usePaystackPayment } from 'react-paystack';

const CreditPurchase = ({ userEmail, onPurchaseSuccess }) => {
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [loading, setLoading] = useState(false);

  // Credit packages with prices
  const packages = [
    {
      id: 1,
      name: 'Starter',
      price: 5000, // ₦5,000 = 2,000 credits (40%)
      credits: 2000,
      badge: 'Popular'
    },
    {
      id: 2,
      name: 'Pro',
      price: 10000, // ₦10,000 = 4,000 credits
      credits: 4000,
      badge: 'Best Value'
    },
    {
      id: 3,
      name: 'Enterprise',
      price: 25000, // ₦25,000 = 10,000 credits
      credits: 10000,
      badge: '33% Bonus'
    }
  ];

  // Paystack configuration
  const config = {
    reference: `${new Date().getTime()}-${userEmail}`,
    email: userEmail,
    amount: selectedPackage ? selectedPackage.price * 100, // Convert to kobo
    publicKey: process.env.REACT_APP_PAYSTACK_PUBLIC_KEY,
    currency: 'NGN'
  };

  // Initialize Paystack payment
  const initializePayment = usePaystackPayment(config);

  const handlePayment = (pkg) => {
    if (!userEmail) {
      alert('Please log in first');
      return;
    }

    setSelectedPackage(pkg);
    setLoading(true);

    // This will open Paystack modal
    initializePayment(() => {
      setLoading(false);
      // Payment successful - webhook will handle credit allocation
      onPurchaseSuccess?.({
        amount: pkg.price,
        credits: pkg.credits,
        package: pkg.name
      });
      
      // Show success message
      alert(`🎉 Payment successful! ${pkg.credits.toLocaleString()} credits added to your account.`);
    });
  };

  return (
    <div className="credit-purchase-container">
      <h2>💳 Buy Credits</h2>
      <p className="subtitle">All payments are instant and automated</p>

      <div className="packages-grid">
        {packages.map((pkg) => (
          <div 
            key={pkg.id} 
            className={`package-card ${selectedPackage?.id === pkg.id ? 'selected' : ''}`}
          >
            {pkg.badge && <div className="badge">{pkg.badge}</div>}
            
            <h3>{pkg.name}</h3>
            <div className="price">₦{pkg.price.toLocaleString()}</div>
            <div className="credits">{pkg.credits.toLocaleString()} Credits</div>
            
            <button
              onClick={() => handlePayment(pkg)}
              disabled={loading && selectedPackage?.id === pkg.id}
              className="buy-button"
            >
              {loading && selectedPackage?.id === pkg.id ? (
                <>⏳ Processing...</>
              ) : (
                <>🛒 Buy Now</>
              )}
            </button>

            <small className="info">
              100% instant • Secure payment • No hidden fees
            </small>
          </div>
        ))}
      </div>

      {/* Current balance display */}
      <div className="balance-section">
        <h4>Your Balance</h4>
        <p>Check how many credits you have available</p>
        <BalanceChecker userEmail={userEmail} />
      </div>

      <style jsx>{`
        .credit-purchase-container {
          max-width: 1000px;
          margin: 0 auto;
          padding: 20px;
        }

        h2 {
          text-align: center;
          color: #333;
          margin-bottom: 10px;
        }

        .subtitle {
          text-align: center;
          color: #666;
          margin-bottom: 30px;
          font-size: 14px;
        }

        .packages-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 20px;
          margin-bottom: 40px;
        }

        .package-card {
          border: 2px solid #e0e0e0;
          border-radius: 12px;
          padding: 20px;
          text-align: center;
          transition: all 0.3s ease;
          position: relative;
          background: white;
        }

        .package-card:hover {
          border-color: #000;
          box-shadow: 0 8px 24px rgba(0,0,0,0.1);
          transform: translateY(-4px);
        }

        .package-card.selected {
          border-color: #2196f3;
          background: #f0f7ff;
        }

        .badge {
          position: absolute;
          top: -12px;
          right: 20px;
          background: #ff6b6b;
          color: white;
          padding: 4px 12px;
          border-radius: 20px;
          font-size: 12px;
          font-weight: bold;
        }

        .package-card h3 {
          margin-top: 0;
          font-size: 20px;
          color: #333;
        }

        .price {
          font-size: 28px;
          font-weight: bold;
          color: #2196f3;
          margin: 15px 0;
        }

        .credits {
          font-size: 14px;
          color: #666;
          margin-bottom: 20px;
        }

        .buy-button {
          width: 100%;
          padding: 12px;
          background: #2196f3;
          color: white;
          border: none;
          border-radius: 8px;
          font-size: 16px;
          font-weight: bold;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .buy-button:hover:not(:disabled) {
          background: #1976d2;
          transform: scale(1.02);
        }

        .buy-button:disabled {
          background: #ccc;
          cursor: not-allowed;
        }

        .info {
          display: block;
          margin-top: 12px;
          color: #999;
          font-size: 12px;
        }

        .balance-section {
          background: #f5f5f5;
          padding: 20px;
          border-radius: 8px;
          text-align: center;
        }

        .balance-section h4 {
          margin: 0 0 5px 0;
          color: #333;
        }

        .balance-section p {
          margin: 0 0 15px 0;
          color: #666;
          font-size: 14px;
        }
      `}</style>
    </div>
  );
};

// Component to display user's current balance
const BalanceChecker = ({ userEmail }) => {
  const [balance, setBalance] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const fetchBalance = async () => {
      try {
        const response = await fetch(
          `${process.env.REACT_APP_API_URL}/api/credits/${userEmail}`
        );
        const data = await response.json();
        setBalance(data.credits);
      } catch (error) {
        console.error('Error fetching balance:', error);
      } finally {
        setLoading(false);
      }
    };

    if (userEmail) {
      fetchBalance();
    }
  }, [userEmail]);

  if (loading) return <p>Loading balance...</p>;
  if (!balance && balance !== 0) return <p>Could not load balance</p>;

  return (
    <div className="balance-display">
      <h2 className="balance-amount">{(balance || 0).toLocaleString()}</h2>
      <p>Credits Available</p>
    </div>
  );
};

export default CreditPurchase;
