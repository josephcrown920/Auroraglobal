// ============================================
// PROFIT DASHBOARD (React Component)
// Monitor your earnings in real-time
// ============================================

import React, { useState, useEffect } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const ProfitDashboard = () => {
  const [dashboardData, setDashboardData] = useState(null);
  const [allUsers, setAllUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState(5000); // Auto-refresh every 5 seconds

  // Fetch dashboard data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [dashRes, usersRes] = await Promise.all([
          fetch(`${process.env.REACT_APP_API_URL}/api/profit-dashboard`),
          fetch(`${process.env.REACT_APP_API_URL}/api/users`)
        ]);

        const dashData = await dashRes.json();
        const usersData = await usersRes.json();

        setDashboardData(dashData);
        setAllUsers(usersData);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        setLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, refreshInterval);
    return () => clearInterval(interval);
  }, [refreshInterval]);

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner">⏳</div>
        <p>Loading your profit dashboard...</p>
      </div>
    );
  }

  if (!dashboardData) {
    return <div className="error">Failed to load dashboard</div>;
  }

  // Calculate per-transaction average
  const transactionCount = parseInt(dashboardData.transactionCount) || 0;
  const profitNumber = parseInt(dashboardData.yourProfit.replace(/[₦,]/g, '')) || 0;
  const avgProfit = transactionCount > 0 ? profitNumber / transactionCount : 0;

  return (
    <div className="profit-dashboard">
      {/* Header */}
      <div className="dashboard-header">
        <div className="header-content">
          <h1>💰 Your Profit Dashboard</h1>
          <p className="subtitle">Real-time earnings from your AI app</p>
        </div>
        <div className="refresh-controls">
          <button onClick={() => window.location.reload()} className="refresh-btn">
            🔄 Refresh Now
          </button>
          <select 
            value={refreshInterval} 
            onChange={(e) => setRefreshInterval(Number(e.target.value))}
            className="interval-select"
          >
            <option value={5000}>Auto-refresh: 5s</option>
            <option value={10000}>Auto-refresh: 10s</option>
            <option value={30000}>Auto-refresh: 30s</option>
            <option value={0}>No auto-refresh</option>
          </select>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="metrics-grid">
        {/* Total Profit */}
        <div className="metric-card profit-card">
          <div className="metric-icon">💵</div>
          <div className="metric-content">
            <h3>Your Total Profit</h3>
            <div className="metric-value">{dashboardData.yourProfit}</div>
            <p className="metric-subtext">
              {dashboardData.profitPercentage} of all payments
            </p>
          </div>
        </div>

        {/* Total Revenue */}
        <div className="metric-card revenue-card">
          <div className="metric-icon">📈</div>
          <div className="metric-content">
            <h3>Total Revenue</h3>
            <div className="metric-value">{dashboardData.totalRevenue}</div>
            <p className="metric-subtext">
              From {transactionCount} transactions
            </p>
          </div>
        </div>

        {/* Avg per Transaction */}
        <div className="metric-card avg-card">
          <div className="metric-icon">📊</div>
          <div className="metric-content">
            <h3>Avg Profit/Transaction</h3>
            <div className="metric-value">
              ₦{Math.floor(avgProfit).toLocaleString()}
            </div>
            <p className="metric-subtext">
              Per customer payment
            </p>
          </div>
        </div>

        {/* Credits Distributed */}
        <div className="metric-card credits-card">
          <div className="metric-icon">🎁</div>
          <div className="metric-content">
            <h3>Credits Distributed</h3>
            <div className="metric-value">{dashboardData.creditsDistributed}</div>
            <p className="metric-subtext">
              Given to users at {dashboardData.creditPercentage}
            </p>
          </div>
        </div>
      </div>

      {/* Split Breakdown */}
      <div className="split-breakdown">
        <h3>📊 Payment Split Overview</h3>
        <div className="split-visual">
          <div className="split-bar">
            <div 
              className="split-segment your-profit" 
              style={{width: dashboardData.profitPercentage}}
            >
              <span>{dashboardData.profitPercentage}</span>
            </div>
            <div 
              className="split-segment user-credits" 
              style={{width: dashboardData.creditPercentage}}
            >
              <span>{dashboardData.creditPercentage}</span>
            </div>
          </div>
        </div>
        <div className="split-legend">
          <div className="legend-item">
            <div className="legend-color your-profit"></div>
            <span>Your Profit ({dashboardData.profitPercentage})</span>
          </div>
          <div className="legend-item">
            <div className="legend-color user-credits"></div>
            <span>User Credits ({dashboardData.creditPercentage})</span>
          </div>
        </div>
      </div>

      {/* Recent Users */}
      <div className="recent-users-section">
        <h3>👥 Recent Customers</h3>
        <div className="users-table">
          <table>
            <thead>
              <tr>
                <th>Email</th>
                <th>Name</th>
                <th>Credits Available</th>
                <th>Joined</th>
              </tr>
            </thead>
            <tbody>
              {allUsers && allUsers.slice(0, 10).map((user) => (
                <tr key={user.id}>
                  <td>{user.email}</td>
                  <td>{user.name || '-'}</td>
                  <td className="credits-cell">
                    {user.total_credits.toLocaleString()}
                  </td>
                  <td className="date-cell">
                    {new Date(user.created_at).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Stats Summary */}
      <div className="stats-summary">
        <h3>📈 Quick Stats</h3>
        <div className="stats-grid">
          <div className="stat">
            <label>Total Customers:</label>
            <value>{allUsers?.length || 0}</value>
          </div>
          <div className="stat">
            <label>Total Transactions:</label>
            <value>{transactionCount}</value>
          </div>
          <div className="stat">
            <label>Active Credits:</label>
            <value>
              {allUsers?.reduce((sum, u) => sum + u.total_credits, 0).toLocaleString()}
            </value>
          </div>
          <div className="stat">
            <label>Automation Status:</label>
            <value style={{color: '#4caf50'}}>✅ LIVE</value>
          </div>
        </div>
      </div>

      <style jsx>{`
        .profit-dashboard {
          padding: 20px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto;
        }

        .loading-container {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 100vh;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          font-size: 18px;
        }

        .spinner {
          font-size: 48px;
          margin-bottom: 20px;
          animation: spin 2s linear infinite;
        }

        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }

        .error {
          background: #f44336;
          color: white;
          padding: 20px;
          border-radius: 8px;
          text-align: center;
        }

        .dashboard-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 30px;
          color: white;
        }

        .header-content h1 {
          margin: 0;
          font-size: 32px;
          font-weight: bold;
        }

        .subtitle {
          margin: 5px 0 0 0;
          opacity: 0.9;
          font-size: 14px;
        }

        .refresh-controls {
          display: flex;
          gap: 10px;
        }

        .refresh-btn, .interval-select {
          padding: 10px 15px;
          border: none;
          border-radius: 6px;
          background: white;
          cursor: pointer;
          font-weight: 600;
          font-size: 14px;
        }

        .interval-select {
          background: rgba(255,255,255,0.9);
          color: #333;
        }

        .metrics-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 20px;
          margin-bottom: 30px;
        }

        .metric-card {
          background: white;
          border-radius: 12px;
          padding: 20px;
          display: flex;
          gap: 20px;
          box-shadow: 0 10px 30px rgba(0,0,0,0.2);
          transition: transform 0.3s;
        }

        .metric-card:hover {
          transform: translateY(-5px);
        }

        .metric-icon {
          font-size: 32px;
          min-width: 40px;
        }

        .metric-content {
          flex: 1;
        }

        .metric-content h3 {
          margin: 0 0 8px 0;
          color: #666;
          font-size: 14px;
          font-weight: 600;
          text-transform: uppercase;
        }

        .metric-value {
          font-size: 24px;
          font-weight: bold;
          color: #333;
          margin: 8px 0;
        }

        .metric-subtext {
          margin: 0;
          color: #999;
          font-size: 13px;
        }

        .split-breakdown {
          background: white;
          border-radius: 12px;
          padding: 25px;
          margin-bottom: 30px;
          box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .split-breakdown h3 {
          margin: 0 0 20px 0;
          color: #333;
        }

        .split-visual {
          margin-bottom: 20px;
        }

        .split-bar {
          display: flex;
          height: 40px;
          border-radius: 8px;
          overflow: hidden;
          box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .split-segment {
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-weight: bold;
          font-size: 14px;
          transition: opacity 0.3s;
        }

        .split-segment:hover {
          opacity: 0.8;
        }

        .your-profit {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .user-credits {
          background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }

        .split-legend {
          display: flex;
          gap: 30px;
        }

        .legend-item {
          display: flex;
          align-items: center;
          gap: 10px;
          font-size: 14px;
          color: #666;
        }

        .legend-color {
          width: 20px;
          height: 20px;
          border-radius: 4px;
        }

        .legend-color.your-profit {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .legend-color.user-credits {
          background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }

        .recent-users-section {
          background: white;
          border-radius: 12px;
          padding: 25px;
          margin-bottom: 30px;
          box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .recent-users-section h3 {
          margin: 0 0 20px 0;
          color: #333;
        }

        .users-table {
          overflow-x: auto;
        }

        table {
          width: 100%;
          border-collapse: collapse;
        }

        th {
          background: #f5f5f5;
          padding: 12px;
          text-align: left;
          font-weight: 600;
          color: #666;
          border-bottom: 2px solid #e0e0e0;
          font-size: 12px;
          text-transform: uppercase;
        }

        td {
          padding: 12px;
          border-bottom: 1px solid #eee;
          color: #333;
        }

        .credits-cell {
          font-weight: bold;
          color: #667eea;
        }

        .date-cell {
          color: #999;
          font-size: 13px;
        }

        tr:hover {
          background: #f9f9f9;
        }

        .stats-summary {
          background: white;
          border-radius: 12px;
          padding: 25px;
          box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .stats-summary h3 {
          margin: 0 0 20px 0;
          color: #333;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 20px;
        }

        .stat {
          background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
          padding: 20px;
          border-radius: 8px;
          text-align: center;
        }

        .stat label {
          display: block;
          color: #666;
          font-size: 13px;
          margin-bottom: 8px;
          font-weight: 600;
        }

        .stat value {
          display: block;
          font-size: 24px;
          font-weight: bold;
          color: #333;
        }

        @media (max-width: 768px) {
          .dashboard-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 15px;
          }

          .refresh-controls {
            width: 100%;
            flex-direction: column;
          }

          .refresh-btn, .interval-select {
            width: 100%;
          }

          table {
            font-size: 12px;
          }

          th, td {
            padding: 8px;
          }
        }
      `}</style>
    </div>
  );
};

export default ProfitDashboard;
