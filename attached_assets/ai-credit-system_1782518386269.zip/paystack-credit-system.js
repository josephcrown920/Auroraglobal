// ============================================
// PAYSTACK CREDIT ALLOCATION SYSTEM
// Fully automated payment → credit distribution
// ============================================

import express from 'express';
import { createClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(express.json());

// ============================================
// SUPABASE SETUP
// ============================================
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET_KEY;
const PROFIT_PERCENTAGE = 60; // You keep 60%
const CREDIT_PERCENTAGE = 40; // User gets 40% as credits

// ============================================
// 1. INITIALIZE DATABASE TABLES
// ============================================
async function initializeDatabase() {
  try {
    // Users table
    await supabase.from('users').select('id').limit(1);
    console.log('✅ Database tables already exist');
  } catch (error) {
    console.log('📊 Setting up database tables...');
    
    // Users table
    await supabase.rpc('exec', {
      sql: `
        CREATE TABLE IF NOT EXISTS users (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          email TEXT UNIQUE NOT NULL,
          name TEXT,
          total_credits BIGINT DEFAULT 0,
          created_at TIMESTAMP DEFAULT NOW(),
          updated_at TIMESTAMP DEFAULT NOW()
        );
      `
    });

    // Purchases table (tracks every payment)
    await supabase.rpc('exec', {
      sql: `
        CREATE TABLE IF NOT EXISTS purchases (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          user_id UUID REFERENCES users(id),
          paystack_reference TEXT UNIQUE NOT NULL,
          amount_paid BIGINT NOT NULL,
          credits_allocated BIGINT NOT NULL,
          profit_kept BIGINT NOT NULL,
          status TEXT DEFAULT 'completed',
          created_at TIMESTAMP DEFAULT NOW()
        );
      `
    });

    // Credit transactions (log every credit deduction)
    await supabase.rpc('exec', {
      sql: `
        CREATE TABLE IF NOT EXISTS credit_transactions (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          user_id UUID REFERENCES users(id),
          amount BIGINT NOT NULL,
          type TEXT DEFAULT 'deduction',
          reason TEXT,
          created_at TIMESTAMP DEFAULT NOW()
        );
      `
    });

    // Profit tracking (for your accounting)
    await supabase.rpc('exec', {
      sql: `
        CREATE TABLE IF NOT EXISTS profit_tracker (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          purchase_id UUID REFERENCES purchases(id),
          profit_amount BIGINT NOT NULL,
          status TEXT DEFAULT 'pending',
          created_at TIMESTAMP DEFAULT NOW()
        );
      `
    });

    console.log('✅ Database tables created successfully');
  }
}

// ============================================
// 2. PAYSTACK WEBHOOK RECEIVER
// This is the heart of the system - fires when payment succeeds
// ============================================
app.post('/webhooks/paystack', async (req, res) => {
  try {
    // Verify webhook signature (security)
    const signature = req.headers['x-paystack-signature'];
    const hash = crypto
      .createHmac('sha512', PAYSTACK_SECRET)
      .update(JSON.stringify(req.body))
      .digest('hex');

    if (hash !== signature) {
      return res.status(400).json({ error: 'Invalid signature' });
    }

    const event = req.body;

    // Only process successful charges
    if (event.event === 'charge.success') {
      const paymentData = event.data;
      const reference = paymentData.reference;
      const amount = paymentData.amount; // Amount in kobo (÷100 for naira)
      const email = paymentData.customer.email;
      const customerName = paymentData.customer.customer_code || email;

      console.log(`💰 Payment received: ${amount/100} from ${email}`);

      // ============================================
      // 3. ALLOCATE CREDITS AUTOMATICALLY
      // ============================================
      await allocateCreditsToUser(
        reference,
        email,
        customerName,
        amount
      );

      // Track for your records
      console.log(`✅ Credits allocated for ${email}`);
    }

    // Always return 200 to acknowledge webhook
    res.json({ success: true });
  } catch (error) {
    console.error('❌ Webhook error:', error);
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// 4. CREDIT ALLOCATION LOGIC
// This is where the magic happens
// ============================================
async function allocateCreditsToUser(reference, email, name, amountInKobo) {
  const amountInNaira = Math.floor(amountInKobo / 100);

  // Calculate split: 60% profit for you, 40% credits for user
  const creditsToGive = Math.floor(amountInNaira * (CREDIT_PERCENTAGE / 100));
  const profitForYou = amountInNaira - creditsToGive;

  try {
    // Check if user exists
    let { data: user, error: userError } = await supabase
      .from('users')
      .select('*')
      .eq('email', email)
      .single();

    // Create user if doesn't exist
    if (userError || !user) {
      const { data: newUser } = await supabase
        .from('users')
        .insert([{ email, name, total_credits: creditsToGive }])
        .select()
        .single();
      user = newUser;
      console.log(`👤 New user created: ${email}`);
    } else {
      // Update existing user's credits
      await supabase
        .from('users')
        .update({ total_credits: user.total_credits + creditsToGive })
        .eq('id', user.id);
      console.log(`➕ Credits added to ${email}`);
    }

    // Record the purchase
    await supabase.from('purchases').insert([
      {
        user_id: user.id,
        paystack_reference: reference,
        amount_paid: amountInNaira,
        credits_allocated: creditsToGive,
        profit_kept: profitForYou,
        status: 'completed'
      }
    ]);

    // Track your profit
    const { data: purchase } = await supabase
      .from('purchases')
      .select('id')
      .eq('paystack_reference', reference)
      .single();

    await supabase.from('profit_tracker').insert([
      {
        purchase_id: purchase.id,
        profit_amount: profitForYou,
        status: 'pending'
      }
    ]);

    console.log(`
    ═══════════════════════════════════════
    ✅ PAYMENT PROCESSED AUTOMATICALLY
    ═══════════════════════════════════════
    Customer: ${email}
    Amount Paid: ₦${amountInNaira.toLocaleString()}
    Credits Issued: ${creditsToGive.toLocaleString()} 🎁
    Your Profit: ₦${profitForYou.toLocaleString()} 💰
    ═══════════════════════════════════════
    `);

    return { success: true, user, creditsGiven: creditsToGive };
  } catch (error) {
    console.error('❌ Error allocating credits:', error);
    throw error;
  }
}

// ============================================
// 5. API ENDPOINTS
// ============================================

// Get user's current credit balance
app.get('/api/credits/:email', async (req, res) => {
  try {
    const { data: user } = await supabase
      .from('users')
      .select('total_credits')
      .eq('email', req.params.email)
      .single();

    if (!user) return res.status(404).json({ error: 'User not found' });

    res.json({ credits: user.total_credits });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Deduct credits when user uses your AI app
app.post('/api/deduct-credits', async (req, res) => {
  try {
    const { email, creditsToDeduct, reason } = req.body;

    // Get user
    const { data: user } = await supabase
      .from('users')
      .select('*')
      .eq('email', email)
      .single();

    if (!user) return res.status(404).json({ error: 'User not found' });
    if (user.total_credits < creditsToDeduct) {
      return res.status(400).json({ error: 'Insufficient credits' });
    }

    // Deduct credits
    const newBalance = user.total_credits - creditsToDeduct;
    await supabase
      .from('users')
      .update({ total_credits: newBalance })
      .eq('id', user.id);

    // Log transaction
    await supabase.from('credit_transactions').insert([
      {
        user_id: user.id,
        amount: creditsToDeduct,
        type: 'deduction',
        reason: reason || 'AI usage'
      }
    ]);

    res.json({ 
      success: true, 
      creditsRemaining: newBalance,
      creditsDeducted: creditsToDeduct 
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get your profit dashboard
app.get('/api/profit-dashboard', async (req, res) => {
  try {
    // Total profit
    const { data: profitData } = await supabase
      .from('profit_tracker')
      .select('profit_amount');

    const totalProfit = profitData.reduce((sum, p) => sum + p.profit_amount, 0);

    // Total credits distributed
    const { data: purchaseData } = await supabase
      .from('purchases')
      .select('credits_allocated, amount_paid');

    const totalCreditsDistributed = purchaseData.reduce(
      (sum, p) => sum + p.credits_allocated,
      0
    );
    const totalRevenue = purchaseData.reduce(
      (sum, p) => sum + p.amount_paid,
      0
    );

    res.json({
      totalRevenue: `₦${totalRevenue.toLocaleString()}`,
      yourProfit: `₦${totalProfit.toLocaleString()}`,
      creditsDistributed: `${totalCreditsDistributed.toLocaleString()}`,
      transactionCount: purchaseData.length,
      profitPercentage: `${PROFIT_PERCENTAGE}%`,
      creditPercentage: `${CREDIT_PERCENTAGE}%`
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all users (for admin panel)
app.get('/api/users', async (req, res) => {
  try {
    const { data: users } = await supabase
      .from('users')
      .select('*')
      .order('created_at', { ascending: false });

    res.json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// 6. INITIALIZATION & SERVER START
// ============================================
const PORT = process.env.PORT || 5000;

async function startServer() {
  await initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`
    🚀 CREDIT SYSTEM RUNNING
    ═════════════════════════════════════════
    Server: http://localhost:${PORT}
    Webhook: http://localhost:${PORT}/webhooks/paystack
    Profit Split: ${PROFIT_PERCENTAGE}% (you) / ${CREDIT_PERCENTAGE}% (users)
    Database: Supabase/PostgreSQL ✅
    ═════════════════════════════════════════
    Ready to receive payments! 💳
    `);
  });
}

startServer();

export default app;
