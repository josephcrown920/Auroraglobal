// ============================================
// INTEGRATION EXAMPLES
// How to use the credit system with your apps
// ============================================

// ============================================
// 1. DEDUCT CREDITS FOR CLAUDE API USAGE
// ============================================

/**
 * When a user calls your Claude AI assistant,
 * deduct credits based on input/output tokens
 */

async function callClaudeAndDeductCredits(userEmail, userPrompt) {
  try {
    // Call Claude API
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.CLAUDE_API_KEY,
      },
      body: JSON.stringify({
        model: 'claude-opus-4-20250514',
        max_tokens: 1024,
        messages: [{ role: 'user', content: userPrompt }]
      })
    });

    const claudeResponse = await response.json();
    
    // Calculate credits to deduct based on token usage
    // Typically: 1 credit = 100 tokens (adjust as needed)
    const inputTokens = claudeResponse.usage.input_tokens;
    const outputTokens = claudeResponse.usage.output_tokens;
    const totalTokens = inputTokens + outputTokens;
    const creditsToDeduct = Math.ceil(totalTokens / 100);

    // Deduct credits from user
    const deductResponse = await fetch(
      `${process.env.API_URL}/api/deduct-credits`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: userEmail,
          creditsToDeduct,
          reason: `Claude API: ${inputTokens} input + ${outputTokens} output tokens`
        })
      }
    );

    const deductData = await deductResponse.json();

    if (!deductData.success) {
      return { error: 'Insufficient credits', required: creditsToDeduct };
    }

    return {
      success: true,
      response: claudeResponse.content[0].text,
      creditsDeducted: creditsToDeduct,
      creditsRemaining: deductData.creditsRemaining
    };
  } catch (error) {
    console.error('Error:', error);
    return { error: error.message };
  }
}

// Usage in your app:
// const result = await callClaudeAndDeductCredits('user@example.com', 'Write a poem');
// console.log(`Used ${result.creditsDeducted} credits, ${result.creditsRemaining} remaining`);


// ============================================
// 2. IMAGE GENERATION (Use in Creator Factory)
// ============================================

/**
 * Generate images and deduct credits
 * Works with Replicate/HeyGen/Kling
 */

async function generateImageAndDeductCredits(userEmail, prompt) {
  try {
    // Call image generation API (example: Replicate)
    const response = await fetch('https://api.replicate.com/v1/predictions', {
      method: 'POST',
      headers: {
        'Authorization': `Token ${process.env.REPLICATE_API_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        version: 'stable-diffusion-model-id',
        input: { prompt }
      })
    });

    // Cost per image generation: 50 credits (adjust to your pricing)
    const creditsToDeduct = 50;

    // Deduct from user
    const deductResponse = await fetch(
      `${process.env.API_URL}/api/deduct-credits`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: userEmail,
          creditsToDeduct,
          reason: 'Image generation'
        })
      }
    );

    const deductData = await deductResponse.json();

    if (!deductData.success) {
      return { error: 'Insufficient credits' };
    }

    return {
      success: true,
      imageUrl: (await response.json()).output,
      creditsDeducted,
      creditsRemaining: deductData.creditsRemaining
    };
  } catch (error) {
    console.error('Error:', error);
    return { error: error.message };
  }
}


// ============================================
// 3. VIDEO GENERATION (For UGC/Kling)
// ============================================

async function generateVideoAndDeductCredits(userEmail, scriptData) {
  try {
    // Call Kling or Sync.so for video generation
    const response = await fetch('https://api.kling.ai/v1/generate', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.KLING_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        prompt: scriptData.script,
        duration: scriptData.duration || 30
      })
    });

    // Video generation is expensive: 500 credits per 30-second video
    const creditsToDeduct = 500;

    const deductResponse = await fetch(
      `${process.env.API_URL}/api/deduct-credits`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: userEmail,
          creditsToDeduct,
          reason: 'Video generation (30 sec)'
        })
      }
    );

    const deductData = await deductResponse.json();

    if (!deductData.success) {
      return { error: 'Insufficient credits', required: creditsToDeduct };
    }

    return {
      success: true,
      videoUrl: (await response.json()).videoUrl,
      creditsDeducted,
      creditsRemaining: deductData.creditsRemaining
    };
  } catch (error) {
    console.error('Error:', error);
    return { error: error.message };
  }
}


// ============================================
// 4. MIDDLEWARE - Protect routes with credit check
// ============================================

/**
 * Express middleware to check if user has enough credits
 * Add to any protected route
 */

const checkCredits = (requiredCredits) => {
  return async (req, res, next) => {
    try {
      const { email } = req.user; // Assuming you have auth middleware

      // Get user's current credits
      const response = await fetch(
        `${process.env.API_URL}/api/credits/${email}`
      );
      const data = await response.json();

      if (data.credits < requiredCredits) {
        return res.status(402).json({
          error: 'Insufficient credits',
          required: requiredCredits,
          available: data.credits,
          shortBy: requiredCredits - data.credits
        });
      }

      // Add credit info to request
      req.creditsAvailable = data.credits;
      next();
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };
};

// Usage:
// app.post('/api/generate-content', checkCredits(100), async (req, res) => {
//   // User has at least 100 credits
//   // Process request...
// });


// ============================================
// 5. FRONTEND - Check balance before action
// ============================================

/**
 * React hook to manage user credits
 */

import { useState, useEffect } from 'react';

function useUserCredits(userEmail) {
  const [credits, setCredits] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCredits = async () => {
      try {
        const response = await fetch(
          `${process.env.REACT_APP_API_URL}/api/credits/${userEmail}`
        );
        const data = await response.json();
        setCredits(data.credits);
      } catch (error) {
        console.error('Error fetching credits:', error);
      } finally {
        setLoading(false);
      }
    };

    if (userEmail) {
      fetchCredits();
      // Refresh every 10 seconds
      const interval = setInterval(fetchCredits, 10000);
      return () => clearInterval(interval);
    }
  }, [userEmail]);

  const hasEnoughCredits = (required) => credits && credits >= required;

  return { credits, loading, hasEnoughCredits };
}

// Usage in component:
// function GenerateAI() {
//   const { credits, hasEnoughCredits } = useUserCredits(userEmail);
//   
//   return (
//     <button 
//       disabled={!hasEnoughCredits(50)}
//       onClick={generateContent}
//     >
//       Generate (50 credits)
//     </button>
//   );
// }


// ============================================
// 6. CREDIT PRICING TIERS
// ============================================

/**
 * Define credit costs for different operations
 * Reference this when deducting credits
 */

const CREDIT_COSTS = {
  // Claude API (per 1000 tokens)
  claude: {
    input: 0.5,      // 0.5 credits per 1000 input tokens
    output: 1.5      // 1.5 credits per 1000 output tokens
  },

  // Image Generation
  imageGeneration: {
    standard: 25,    // 25 credits for standard image
    hd: 50,          // 50 credits for HD image
    batch: 100       // 100 credits for 5 images
  },

  // Video Generation
  videoGeneration: {
    short: 300,      // 300 credits for 15-30 sec
    medium: 500,     // 500 credits for 30-60 sec
    long: 1000       // 1000 credits for 60+ sec
  },

  // Transcription
  transcription: {
    perMinute: 5     // 5 credits per minute of audio
  },

  // TTS (Text to Speech)
  textToSpeech: {
    perCharacter: 0.01 // 0.01 credits per character
  }
};

// Usage:
// const cost = CREDIT_COSTS.imageGeneration.standard;


// ============================================
// 7. BULK OPERATIONS WITH CREDITS
// ============================================

/**
 * For batch processing (e.g., YouTube Shorts generation)
 * Deduct credits only after successful completion
 */

async function generateMultipleShorts(userEmail, scripts) {
  try {
    // Calculate total cost upfront
    const totalCost = scripts.length * CREDIT_COSTS.videoGeneration.short;

    // Check if user has enough
    const creditsResponse = await fetch(
      `${process.env.API_URL}/api/credits/${userEmail}`
    );
    const { credits } = await creditsResponse.json();

    if (credits < totalCost) {
      return {
        error: 'Insufficient credits',
        required: totalCost,
        available: credits
      };
    }

    // Process each script
    const results = [];
    let successCount = 0;

    for (const script of scripts) {
      try {
        const video = await generateVideoAndDeductCredits(userEmail, script);
        results.push(video);
        if (video.success) successCount++;
      } catch (error) {
        results.push({ error: error.message });
      }
    }

    return {
      success: true,
      processed: successCount,
      total: scripts.length,
      results,
      totalCreditsCost: totalCost
    };
  } catch (error) {
    return { error: error.message };
  }
}


// ============================================
// 8. CREATOR FACTORY INTEGRATION
// ============================================

/**
 * Example: Integrate with Creator Factory YouTube Shorts automation
 * User clicks "Generate Shorts" → Deduct credits → Create videos
 */

async function createYouTubeShortsWithCredits(userEmail, config) {
  const {
    numberOfShorts = 5,
    duration = 30,
    topic,
    style
  } = config;

  try {
    // Step 1: Generate scripts using Claude
    const scriptPrompt = `
      Create ${numberOfShorts} YouTube Shorts scripts about ${topic}.
      Each script should be ${duration} seconds max.
      Style: ${style}
      Return as JSON array with "script" field for each.
    `;

    const scriptResult = await callClaudeAndDeductCredits(userEmail, scriptPrompt);
    
    if (scriptResult.error) {
      return { error: scriptResult.error };
    }

    const scripts = JSON.parse(scriptResult.response);

    // Step 2: Generate videos for each script
    const videoResults = [];
    for (const scriptObj of scripts) {
      const videoResult = await generateVideoAndDeductCredits(userEmail, {
        script: scriptObj.script,
        duration
      });
      videoResults.push(videoResult);
    }

    // Step 3: Return dashboard
    return {
      success: true,
      scriptsGenerated: scripts.length,
      videosGenerated: videoResults.filter(v => v.success).length,
      results: videoResults,
      totalCreditsUsed: scriptResult.creditsDeducted + 
                        videoResults.reduce((sum, v) => sum + (v.creditsDeducted || 0), 0)
    };
  } catch (error) {
    return { error: error.message };
  }
}


// ============================================
// 9. MONITORING & ANALYTICS
// ============================================

/**
 * Track credit usage patterns
 */

async function getUserCreditAnalytics(userEmail) {
  try {
    // Fetch user's transaction history
    const response = await fetch(
      `${process.env.API_URL}/api/credit-transactions/${userEmail}`
    );
    const transactions = await response.json();

    // Calculate analytics
    const totalUsed = transactions.reduce((sum, t) => sum + t.amount, 0);
    const averagePerDay = totalUsed / (Math.ceil(
      (new Date() - new Date(transactions[0].created_at)) / (1000 * 60 * 60 * 24)
    ));

    return {
      totalUsed,
      averagePerDay,
      transactions,
      projectedMonthlyUsage: averagePerDay * 30
    };
  } catch (error) {
    console.error('Error fetching analytics:', error);
    return null;
  }
}


module.exports = {
  callClaudeAndDeductCredits,
  generateImageAndDeductCredits,
  generateVideoAndDeductCredits,
  checkCredits,
  useUserCredits,
  CREDIT_COSTS,
  generateMultipleShorts,
  createYouTubeShortsWithCredits,
  getUserCreditAnalytics
};
