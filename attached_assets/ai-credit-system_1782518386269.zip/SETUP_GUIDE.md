# 🚀 AI APP CREDIT SYSTEM - SETUP GUIDE

## Complete Hands-Off Automated Payment → Credit System

**What this does:**
- User pays ₦5,000 (or any amount) → System automatically splits it 60/40
- User gets 40% as credits instantly
- You keep 60% as profit
- No manual intervention needed ever again
- Everything tracked in your dashboard

---

## 📋 STEP 1: SET UP SUPABASE (Database)

### 1.1 Create Supabase Account
1. Go to https://supabase.com
2. Sign up with email
3. Create a new project (choose your region)
4. Wait for database to initialize

### 1.2 Get Your Credentials
1. Go to Settings → API
2. Copy: **Project URL** and **Anon Key**
3. Paste them in your `.env` file

---

## 💳 STEP 2: SET UP PAYSTACK

### 2.1 Create Paystack Account
1. Go to https://paystack.com
2. Sign up (Nigerian business account)
3. Complete KYC verification (⚠️ Required)
4. Dashboard → Settings → Developers

### 2.2 Get Paystack Keys
1. Find: **Live Public Key** (starts with `pk_live_`)
2. Find: **Live Secret Key** (starts with `sk_live_`)
3. Copy both to `.env` file

### 2.3 Configure Webhook
**This is CRITICAL - this is what triggers credit allocation**

1. Paystack Dashboard → Settings → Developers → Webhook
2. Add webhook URL: `https://yourdomain.com/webhooks/paystack`
3. Copy webhook secret (add to `.env` as `PAYSTACK_SECRET_KEY`)
4. ✅ Webhook will POST payment data here automatically

---

## 🔧 STEP 3: DEPLOY THE BACKEND

### Option A: Deploy on Glitch (Recommended - Free & Easy)

1. Go to https://glitch.com
2. Create new project → Select "Node.js"
3. Delete all files in the editor
4. Create new file: `paystack-credit-system.js`
5. Copy-paste the entire code from `paystack-credit-system.js`
6. Create file: `.env` with your credentials:
```
PAYSTACK_PUBLIC_KEY=pk_live_xxxxx
PAYSTACK_SECRET_KEY=sk_live_xxxxx
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_KEY=your-anon-key
```
7. Create file: `package.json` from the provided one
8. Glitch auto-restarts → Your server is LIVE
9. Your webhook URL: `https://your-glitch-project-name.glitch.me/webhooks/paystack`

### Option B: Deploy on Railway (Also Free)

1. Go to https://railway.app
2. Connect GitHub repo
3. Add env variables (paste from `.env`)
4. Deploy
5. Get domain from Railway dashboard

### Option C: Deploy on Replit (Your familiar setup)

1. Create new Replit project
2. Paste code into `index.js`
3. Create `.env` with credentials
4. Run `npm install`
5. Start server
6. Copy Replit URL as webhook

---

## 🎯 STEP 4: INTEGRATE INTO YOUR FRONTEND

### 4.1 Install Paystack React Library
```bash
npm install react-paystack
```

### 4.2 Add Environment Variables (Frontend)
Create `.env` in your React project:
```
REACT_APP_PAYSTACK_PUBLIC_KEY=pk_live_xxxxx
REACT_APP_API_URL=https://your-backend-domain.com
```

### 4.3 Use the Credit Purchase Component
```jsx
import CreditPurchase from './components/CreditPurchase';

function App() {
  return (
    <CreditPurchase 
      userEmail={currentUserEmail} 
      onPurchaseSuccess={(data) => {
        console.log(`Purchased ${data.credits} credits`);
        // Refresh user balance
      }}
    />
  );
}
```

---

## 📊 STEP 5: TRACK YOUR PROFITS

### Get Your Dashboard Data
Call this endpoint to see everything:
```bash
GET https://your-domain.com/api/profit-dashboard
```

Response:
```json
{
  "totalRevenue": "₦150,000",
  "yourProfit": "₦90,000",
  "creditsDistributed": "60,000",
  "transactionCount": 3,
  "profitPercentage": "60%",
  "creditPercentage": "40%"
}
```

### Build a Dashboard
```jsx
import { useEffect, useState } from 'react';

function ProfitDashboard() {
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch('https://your-domain.com/api/profit-dashboard')
      .then(res => res.json())
      .then(data => setData(data));
  }, []);

  if (!data) return <p>Loading...</p>;

  return (
    <div>
      <h2>💰 Your Profit: {data.yourProfit}</h2>
      <p>Total Revenue: {data.totalRevenue}</p>
      <p>Credits Distributed: {data.creditsDistributed}</p>
      <p>Transactions: {data.transactionCount}</p>
    </div>
  );
}
```

---

## 🎮 STEP 6: DEDUCT CREDITS WHEN USER USES YOUR AI

When a user calls your AI (ChatGPT integration, image gen, etc.):

```javascript
// After user successfully uses your AI
const response = await fetch('https://your-domain.com/api/deduct-credits', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: userEmail,
    creditsToDeduct: 10, // How many credits the AI call costs
    reason: 'ChatGPT API call'
  })
});

const data = await response.json();
console.log(`Credits remaining: ${data.creditsRemaining}`);
```

---

## ✅ TESTING (BEFORE GOING LIVE)

### Test Payment Flow
1. Use Paystack test card:
   - Card: `4111 1111 1111 1111`
   - Expiry: `12/25`
   - CVV: `123`
2. Complete payment
3. Check Supabase → `purchases` table
4. Verify credits were added to user
5. Check profit was tracked

### Verify Webhook
1. Paystack Dashboard → Logs
2. You should see successful webhook deliveries
3. Status: `200` (success)

---

## 🔐 SECURITY CHECKLIST

- [ ] Webhook signature verified (code does this)
- [ ] Environment variables in `.env` (NOT in code)
- [ ] Paystack keys in production secrets (Glitch/Railway)
- [ ] HTTPS only for webhook (all platforms provide this)
- [ ] Database permissions set to minimum (Supabase)
- [ ] API endpoints protected (optional: add API key auth)

---

## 🚨 TROUBLESHOOTING

### Webhook not firing?
- Check Paystack Dashboard → Developers → Logs
- Verify webhook URL is correct
- Make sure backend is running and accessible
- Test with Paystack test payment

### Credits not being added?
- Check Supabase → `purchases` table
- Check backend console for errors
- Verify Paystack reference is being sent
- Check user email matches exactly

### Profit not tracked?
- Check `profit_tracker` table in Supabase
- Verify `purchase` record was created first
- Check for database connection errors

---

## 📈 SCALE YOUR SYSTEM

### Add More Credit Packages
Edit packages array in `CreditPurchase.jsx`:
```jsx
const packages = [
  { name: 'Starter', price: 5000, credits: 2000 },
  { name: 'Pro', price: 10000, credits: 4000 },
  // Add more...
];
```

### Change Profit Split
Edit in `paystack-credit-system.js`:
```javascript
const PROFIT_PERCENTAGE = 60; // Change this
const CREDIT_PERCENTAGE = 40; // This auto-adjusts
```

### Add Usage Limits
Modify `/api/deduct-credits` to check daily/monthly caps:
```javascript
const dailyUsed = await getCreditsUsedToday(email);
if (dailyUsed + creditsToDeduct > DAILY_LIMIT) {
  return res.status(400).json({ error: 'Daily limit exceeded' });
}
```

---

## 📞 SUPPORT RESOURCES

- Paystack Docs: https://paystack.com/docs/
- Supabase Docs: https://supabase.com/docs
- React Paystack: https://github.com/ifeoluwajuwon/react-paystack

---

## 💡 NEXT STEPS

1. ✅ Set up Supabase
2. ✅ Set up Paystack
3. ✅ Deploy backend (Glitch/Railway)
4. ✅ Integrate frontend component
5. ✅ Test with real payment
6. ✅ Monitor dashboard
7. ✅ Watch profits come in automatically

**Your system is now 100% hands-off.** No manual work. Pure automation. 💰
