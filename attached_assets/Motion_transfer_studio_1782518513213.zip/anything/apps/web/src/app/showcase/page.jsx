import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Film,
  Heart,
  Trash2,
  Sparkles,
  Grid,
  Filter,
  ExternalLink,
  X,
  Plus,
  Clock,
  Cpu,
} from "lucide-react";
import { Link } from "react-router-dom";

const STYLE_FILTERS = [
  { id: "all", label: "All Styles" },
  { id: "music-video", label: "Music Video" },
  { id: "movie-trailer", label: "Movie Trailer" },
  { id: "anime", label: "Anime" },
  { id: "documentary", label: "Documentary" },
  { id: "gta-action", label: "GTA Action" },
];

const STYLE_LABELS = {
  "music-video": "Music Video",
  "movie-trailer": "Movie Trailer",
  anime: "Anime",
  documentary: "Documentary",
  "gta-action": "GTA Action",
};

const STYLE_COLORS = {
  "music-video": "bg-purple-50 text-purple-700 border-purple-200",
  "movie-trailer": "bg-amber-50 text-amber-700 border-amber-200",
  anime: "bg-pink-50 text-pink-700 border-pink-200",
  documentary: "bg-gray-50 text-gray-700 border-gray-200",
  "gta-action": "bg-green-50 text-green-700 border-green-200",
};

function timeAgo(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  if (mins < 60) return `${mins}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}

function ShowcaseCard({ item, onDelete, onLike }) {
  const [expanded, setExpanded] = useState(false);
  const styleClass =
    STYLE_COLORS[item.visual_style] ||
    "bg-gray-50 text-gray-700 border-gray-200";

  return (
    <>
      <div
        className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:border-gray-300 hover:shadow-md transition-all cursor-pointer group"
        onClick={() => setExpanded(true)}
      >
        <div className="relative aspect-video overflow-hidden bg-gray-100">
          <img
            src={item.image_url}
            alt={item.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          <div className="absolute top-3 left-3">
            <span
              className={`text-[10px] font-semibold uppercase px-2 py-1 rounded-full border ${styleClass}`}
            >
              {STYLE_LABELS[item.visual_style] || item.visual_style}
            </span>
          </div>
          <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
            <ExternalLink className="w-4 h-4 text-white" />
          </div>
        </div>

        <div className="p-4">
          <h3 className="text-sm font-semibold text-gray-900 mb-1 truncate">
            {item.title}
          </h3>
          <p className="text-[11px] text-gray-400 line-clamp-2 mb-3">
            {item.scene_value || item.outfit_value || "Cinematic scene"}
          </p>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1 text-[10px] text-gray-400">
              <Clock className="w-3 h-3" />
              {timeAgo(item.created_at)}
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onLike(item.id);
                }}
                className="flex items-center gap-1 text-[11px] text-gray-400 hover:text-red-500 transition-colors"
              >
                <Heart className="w-3.5 h-3.5" />
                {item.likes || 0}
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(item.id);
                }}
                className="p-1 text-gray-300 hover:text-red-500 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Expanded Modal */}
      {expanded && (
        <div
          className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
          onClick={() => setExpanded(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-auto shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative">
              <img
                src={item.image_url}
                alt={item.title}
                className="w-full rounded-t-2xl"
              />
              <button
                onClick={() => setExpanded(false)}
                className="absolute top-4 right-4 bg-black/50 text-white rounded-full p-1.5 hover:bg-black/70"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-1">
                    {item.title}
                  </h2>
                  <span
                    className={`text-xs font-medium px-2 py-1 rounded-full border ${styleClass}`}
                  >
                    {STYLE_LABELS[item.visual_style] || item.visual_style}
                  </span>
                </div>
                <div className="flex items-center gap-1 text-[11px] text-gray-400 mt-1">
                  <Clock className="w-3 h-3" /> {timeAgo(item.created_at)}
                </div>
              </div>

              {item.artist_profile && (
                <div className="mb-4">
                  <div className="text-[10px] uppercase font-bold text-gray-400 mb-1">
                    Artist Profile
                  </div>
                  <p className="text-sm text-gray-700">{item.artist_profile}</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4 mb-4">
                {item.outfit_value && (
                  <div className="bg-gray-50 rounded-lg p-3 border border-gray-100">
                    <div className="text-[10px] uppercase font-bold text-gray-400 mb-1">
                      Outfit
                    </div>
                    <div className="text-sm text-gray-900">
                      {item.outfit_value}
                    </div>
                  </div>
                )}
                {item.scene_value && (
                  <div className="bg-gray-50 rounded-lg p-3 border border-gray-100">
                    <div className="text-[10px] uppercase font-bold text-gray-400 mb-1">
                      Scene
                    </div>
                    <div className="text-sm text-gray-900">
                      {item.scene_value}
                    </div>
                  </div>
                )}
              </div>

              {item.model_used && (
                <div className="flex items-center gap-2 text-[11px] text-gray-400 bg-gray-50 rounded-lg p-3 border border-gray-100">
                  <Cpu className="w-3.5 h-3.5 text-blue-500" />
                  <span>
                    Generated with{" "}
                    <strong className="text-gray-700">{item.model_used}</strong>
                  </span>
                </div>
              )}

              {item.prompt && (
                <details className="mt-4">
                  <summary className="text-[11px] font-medium text-gray-400 cursor-pointer hover:text-gray-600">
                    View generation prompt
                  </summary>
                  <p className="mt-2 text-[11px] text-gray-500 bg-gray-50 rounded-lg p-3 border border-gray-100 font-mono leading-relaxed">
                    {item.prompt}
                  </p>
                </details>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default function ShowcasePage() {
  const [activeFilter, setActiveFilter] = useState("all");
  const queryClient = useQueryClient();

  const { data, isLoading, error } = useQuery({
    queryKey: ["showcase", activeFilter],
    queryFn: async () => {
      const url =
        activeFilter === "all"
          ? "/api/showcase"
          : `/api/showcase?style=${activeFilter}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to load showcase");
      return res.json();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id) => {
      const res = await fetch(`/api/showcase/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Delete failed");
    },
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: ["showcase", activeFilter] });
      const prev = queryClient.getQueryData(["showcase", activeFilter]);
      queryClient.setQueryData(["showcase", activeFilter], (old) => ({
        ...old,
        items: old?.items?.filter((i) => i.id !== id),
      }));
      return { prev };
    },
    onError: (err, id, ctx) => {
      queryClient.setQueryData(["showcase", activeFilter], ctx.prev);
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["showcase"] }),
  });

  const likeMutation = useMutation({
    mutationFn: async (id) => {
      const res = await fetch(`/api/showcase/${id}`, { method: "PATCH" });
      if (!res.ok) throw new Error("Like failed");
      return res.json();
    },
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: ["showcase", activeFilter] });
      const prev = queryClient.getQueryData(["showcase", activeFilter]);
      queryClient.setQueryData(["showcase", activeFilter], (old) => ({
        ...old,
        items: old?.items?.map((i) =>
          i.id === id ? { ...i, likes: (i.likes || 0) + 1 } : i,
        ),
      }));
      return { prev };
    },
    onError: (err, id, ctx) => {
      queryClient.setQueryData(["showcase", activeFilter], ctx.prev);
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["showcase"] }),
  });

  const items = data?.items || [];

  return (
    <div className="min-h-screen bg-[#F9FAFB] font-inter">
      <style jsx global>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        .cia-pulse { animation: pulse 2s cubic-bezier(0.4,0,0.6,1) infinite; }
      `}</style>

      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-600 rounded-sm flex items-center justify-center">
                <Film className="text-white w-5 h-5" />
              </div>
              <span className="text-lg font-semibold text-gray-900 tracking-tight">
                CinematicAI
              </span>
            </Link>
            <span className="text-gray-300">/</span>
            <span className="text-sm font-medium text-gray-500">Showcase</span>
          </div>
          <Link
            to="/create"
            className="bg-blue-600 text-white text-sm font-semibold px-4 py-2 rounded-sm hover:bg-blue-700 transition-colors flex items-center gap-2"
          >
            <Plus className="w-4 h-4" /> New Performance
          </Link>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-12">
        {/* Page Title */}
        <div className="mb-10">
          <div className="inline-flex items-center gap-1.5 bg-blue-50 text-blue-600 rounded-full px-3 py-1 text-xs font-medium mb-3">
            <Sparkles className="w-3.5 h-3.5" /> Community Showcase
          </div>
          <h1 className="text-3xl font-semibold text-gray-900 tracking-tight mb-2">
            Cinematic Performances
          </h1>
          <p className="text-gray-500 text-sm">
            AI-generated cinematic frames from the production pipeline.
          </p>
        </div>

        {/* Filter Bar */}
        <div className="flex items-center gap-3 mb-8 overflow-x-auto pb-2">
          <Filter className="w-4 h-4 text-gray-400 shrink-0" />
          {STYLE_FILTERS.map((f) => (
            <button
              key={f.id}
              onClick={() => setActiveFilter(f.id)}
              className={`px-4 py-1.5 rounded-full border text-sm font-medium whitespace-nowrap transition-all shrink-0 ${
                activeFilter === f.id
                  ? "bg-blue-600 text-white border-blue-600"
                  : "bg-white text-gray-600 border-gray-200 hover:border-gray-300"
              }`}
            >
              {f.label}
            </button>
          ))}
          <div className="ml-auto shrink-0 flex items-center gap-1 text-xs text-gray-400">
            <Grid className="w-3.5 h-3.5" />
            {items.length} results
          </div>
        </div>

        {/* Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="cia-pulse bg-white rounded-xl border border-gray-200 overflow-hidden"
              >
                <div className="aspect-video bg-gray-100" />
                <div className="p-4 space-y-2">
                  <div className="h-4 bg-gray-100 rounded w-3/4" />
                  <div className="h-3 bg-gray-100 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-20 text-red-500 text-sm">
            {error.message}
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-32">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Sparkles className="w-8 h-8 text-gray-300" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              No performances yet
            </h3>
            <p className="text-gray-500 text-sm mb-6">
              Generate your first cinematic performance to see it here.
            </p>
            <Link
              to="/create"
              className="bg-blue-600 text-white text-sm font-semibold px-6 py-2.5 rounded-sm hover:bg-blue-700 transition-colors inline-flex items-center gap-2"
            >
              <Plus className="w-4 h-4" /> Create Performance
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {items.map((item) => (
              <ShowcaseCard
                key={item.id}
                item={item}
                onDelete={(id) => deleteMutation.mutate(id)}
                onLike={(id) => likeMutation.mutate(id)}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
