import React from "react";
import {
  ArrowRight,
  Video,
  Cpu,
  UserCheck,
  Layers,
  Shirt,
  Sparkles,
  Film,
  Activity,
  Zap,
  Check,
} from "lucide-react";
import { Link } from "react-router-dom";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white font-inter text-[#111827]">
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-sm flex items-center justify-center">
              <Film className="text-white w-5 h-5" />
            </div>
            <span className="text-lg font-semibold text-gray-900 tracking-tight">
              CinematicAI
            </span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a
              href="#"
              className="text-sm font-medium text-gray-900 border-b-2 border-blue-600 pb-5 -mb-[1px]"
            >
              Pipeline
            </a>
            <a
              href="#"
              className="text-sm font-normal text-gray-500 hover:text-gray-700 pb-5"
            >
              Technology
            </a>
            <Link
              to="/showcase"
              className="text-sm font-normal text-gray-500 hover:text-gray-700 pb-5"
            >
              Showcase
            </Link>
            <a
              href="#"
              className="text-sm font-normal text-gray-500 hover:text-gray-700 pb-5"
            >
              Pricing
            </a>
          </div>
          <div className="flex items-center gap-3">
            <button className="text-sm font-medium text-gray-600 px-4 py-2">
              Sign in
            </button>
            <Link
              to="/create"
              className="bg-blue-600 text-white text-sm font-semibold px-4 py-2 rounded-sm hover:bg-blue-700 transition-colors"
            >
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-20 pb-32 px-4 overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-10">
          <img
            src="https://raw.createusercontent.com/9bb485b4-6c9c-4a5b-85b3-5018bd67473c/"
            className="w-full h-full object-cover grayscale"
            alt="Technical wireframe background"
          />
        </div>
        <div className="relative z-10 max-auto max-w-4xl text-center">
          <div className="inline-flex items-center gap-1.5 bg-blue-50 text-blue-600 rounded-full px-3 py-1.5 text-sm font-medium mb-6">
            <Zap className="w-4 h-4" />
            <span>New: v2.0 Motion Extraction Engine</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-semibold tracking-tight mb-6 leading-[1.1]">
            From Raw Video to <br />
            <span className="text-blue-600">Cinematic Performance</span>
          </h1>
          <p className="text-lg text-gray-500 max-w-2xl mx-auto mb-10">
            Professional-grade performance transfer powered by our proprietary
            Motion Extraction AI. Automate rotoscoping, identity preservation,
            and scene generation in a single pipeline.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/create"
              className="w-full sm:w-auto bg-blue-600 text-white font-semibold px-8 py-3 rounded-sm flex items-center justify-center gap-2 hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
            >
              Start Your Project <ArrowRight className="w-4 h-4" />
            </Link>
            <button className="w-full sm:w-auto bg-white border border-gray-200 text-gray-900 font-semibold px-8 py-3 rounded-sm hover:bg-gray-50 transition-colors">
              Watch Demo
            </button>
          </div>
        </div>
      </section>

      {/* Feature Highlight with Generated Image */}
      <section className="py-24 border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="bg-blue-50 text-blue-600 rounded-full px-3 py-1 text-xs font-medium inline-flex items-center gap-1.5 mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              Identity Lock AI
            </div>
            <h2 className="text-3xl font-semibold tracking-tight mb-4">
              Recognizable in every frame.
            </h2>
            <p className="text-gray-500 mb-6">
              Our Identity Preservation Engine uses advanced embeddings to
              ensure your talent remains perfectly recognizable, regardless of
              the environment or style transfer applied.
            </p>
            <div className="space-y-3">
              <div className="text-sm text-gray-600 py-1 flex items-center">
                <span className="text-gray-400 mr-3 font-mono">-</span>{" "}
                Sub-pixel facial feature alignment
              </div>
              <div className="text-sm text-gray-600 py-1 flex items-center">
                <span className="text-gray-400 mr-3 font-mono">-</span>{" "}
                High-frequency detail preservation
              </div>
              <div className="text-sm text-gray-600 py-1 flex items-center">
                <span className="text-gray-400 mr-3 font-mono">-</span> Dynamic
                lighting adaptation
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="rounded-xl border border-gray-200 overflow-hidden shadow-2xl">
              <img
                src="https://raw.createusercontent.com/9bb485b4-6c9c-4a5b-85b3-5018bd67473c/"
                className="w-full h-auto"
                alt="Identity Lock AI Visualization"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-white rounded-lg border border-gray-200 p-4 hidden md:block">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-50 rounded-full flex items-center justify-center">
                  <Check className="text-green-600 w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-gray-900 uppercase">
                    Identity Match
                  </div>
                  <div className="text-lg font-semibold text-gray-900 leading-none">
                    99.8%
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pipeline Visualization Section */}
      <section className="bg-gray-50 py-24 border-y border-gray-200">
        <div className="max-w-7xl mx-auto px-4">
          <div className="mb-16">
            <h2 className="text-2xl font-semibold text-gray-900 tracking-tight">
              The Production Pipeline
            </h2>
            <p className="text-gray-500 text-sm mt-1">
              Our end-to-end architecture for cinematic synthesis.
            </p>
          </div>

          <div className="relative">
            {/* Connecting Line (Vertical for mobile, horizontal for desktop would be complex, sticking to a clear vertical flow for technical clarity) */}
            <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px bg-gray-200 -translate-x-1/2 hidden md:block" />

            <div className="space-y-12 relative">
              {/* Step 1: Input */}
              <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                <div className="w-full md:w-[45%]">
                  <div className="bg-white rounded-xl border border-gray-200 p-6 hover:border-gray-300 transition-colors">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-2 bg-gray-50 rounded-md border border-gray-100">
                        <Video className="w-5 h-5 text-gray-900" />
                      </div>
                      <div className="bg-white border border-gray-200 rounded-full px-3 py-1 text-xs text-gray-700 inline-flex items-center gap-1.5">
                        <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                        Ready for Input
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">
                      Raw Performance Video
                    </h3>
                    <p className="text-sm text-gray-500 mb-4">
                      Single-camera reference footage with variable lighting.
                    </p>
                    <div className="space-y-1">
                      <div className="text-sm text-gray-600 py-1">
                        <span className="text-gray-400 mr-2">-</span> 4K 60fps
                        Support
                      </div>
                      <div className="text-sm text-gray-600 py-1">
                        <span className="text-gray-400 mr-2">-</span> Depth Map
                        Extraction
                      </div>
                    </div>
                  </div>
                </div>
                <div className="hidden md:flex w-10 h-10 bg-white border border-gray-200 rounded-full items-center justify-center z-10 shadow-sm">
                  <span className="text-xs font-semibold text-gray-400">
                    01
                  </span>
                </div>
                <div className="hidden md:block w-[45%]" />
              </div>

              {/* Step 2: Extraction AI */}
              <div className="flex flex-col md:flex-row-reverse items-center justify-between gap-8">
                <div className="w-full md:w-[45%]">
                  <div className="bg-white rounded-xl border border-gray-200 p-6 hover:border-gray-300 transition-colors">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-2 bg-blue-50 rounded-md border border-blue-100">
                        <Cpu className="w-5 h-5 text-blue-600" />
                      </div>
                      <div className="bg-white border border-gray-200 rounded-full px-3 py-1 text-xs text-gray-700 inline-flex items-center gap-1.5">
                        <Activity className="w-3.5 h-3.5" />
                        Active Analysis
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">
                      Motion Extraction AI
                    </h3>
                    <p className="text-sm text-gray-500 mb-4">
                      Proprietary vision models decimate complex motion into
                      mathematical vectors.
                    </p>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-gray-50 border border-gray-200 rounded-md p-3">
                        <div className="text-[10px] uppercase font-bold text-gray-400 mb-1">
                          Skeleton
                        </div>
                        <div className="text-sm font-semibold text-gray-900">
                          Body Pose
                        </div>
                      </div>
                      <div className="bg-gray-50 border border-gray-200 rounded-md p-3">
                        <div className="text-[10px] uppercase font-bold text-gray-400 mb-1">
                          Geometry
                        </div>
                        <div className="text-sm font-semibold text-gray-900">
                          Facial Motion
                        </div>
                      </div>
                      <div className="bg-gray-50 border border-gray-200 rounded-md p-3">
                        <div className="text-[10px] uppercase font-bold text-gray-400 mb-1">
                          Optics
                        </div>
                        <div className="text-sm font-semibold text-gray-900">
                          Camera Path
                        </div>
                      </div>
                      <div className="bg-gray-50 border border-gray-200 rounded-md p-3">
                        <div className="text-[10px] uppercase font-bold text-gray-400 mb-1">
                          Temporal
                        </div>
                        <div className="text-sm font-semibold text-gray-900">
                          Timing Map
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="hidden md:flex w-10 h-10 bg-white border border-gray-200 rounded-full items-center justify-center z-10 shadow-sm">
                  <span className="text-xs font-semibold text-gray-400">
                    02
                  </span>
                </div>
                <div className="hidden md:block w-[45%]" />
              </div>

              {/* Step 3: Identity & Scene */}
              <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                <div className="w-full md:w-[45%]">
                  <div className="bg-white rounded-xl border border-gray-200 p-6 hover:border-gray-300 transition-colors">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-2 bg-gray-50 rounded-md border border-gray-100">
                        <UserCheck className="w-5 h-5 text-gray-900" />
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">
                      Identity Preservation
                    </h3>
                    <p className="text-sm text-gray-500 mb-4">
                      Ensures actor features remain consistent across varying
                      lighting and environments.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <span className="bg-white border border-gray-200 rounded-full px-3 py-1 text-xs text-gray-700">
                        Sub-pixel Alignment
                      </span>
                      <span className="bg-white border border-gray-200 rounded-full px-3 py-1 text-xs text-gray-700">
                        Feature Locking
                      </span>
                    </div>
                  </div>
                </div>
                <div className="hidden md:flex w-10 h-10 bg-white border border-gray-200 rounded-full items-center justify-center z-10 shadow-sm">
                  <span className="text-xs font-semibold text-gray-400">
                    03
                  </span>
                </div>
                <div className="hidden md:block w-[45%]" />
              </div>

              {/* Step 4: Scene & Outfit */}
              <div className="flex flex-col md:flex-row-reverse items-center justify-between gap-8">
                <div className="w-full md:w-[45%]">
                  <div className="bg-white rounded-xl border border-gray-200 p-6 hover:border-gray-300 transition-colors">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex gap-2">
                        <div className="p-2 bg-gray-50 rounded-md border border-gray-100">
                          <Layers className="w-5 h-5 text-gray-900" />
                        </div>
                        <div className="p-2 bg-gray-50 rounded-md border border-gray-100">
                          <Shirt className="w-5 h-5 text-gray-900" />
                        </div>
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">
                      Scene & Outfit Transfer
                    </h3>
                    <p className="text-sm text-gray-500 mb-4">
                      Dynamic environment generation with physics-based clothing
                      simulation.
                    </p>
                    <div className="space-y-1">
                      <div className="text-sm text-gray-600 py-1">
                        <span className="text-gray-400 mr-2">-</span> Procedural
                        Textures
                      </div>
                      <div className="text-sm text-gray-600 py-1">
                        <span className="text-gray-400 mr-2">-</span> Cloth
                        Deformation AI
                      </div>
                    </div>
                  </div>
                </div>
                <div className="hidden md:flex w-10 h-10 bg-white border border-gray-200 rounded-full items-center justify-center z-10 shadow-sm">
                  <span className="text-xs font-semibold text-gray-400">
                    04
                  </span>
                </div>
                <div className="hidden md:block w-[45%]" />
              </div>

              {/* Step 5: Final Output */}
              <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                <div className="w-full md:w-[45%]">
                  <div className="bg-white rounded-xl border border-gray-200 p-6 border-blue-200 bg-blue-50/30">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-2 bg-blue-600 rounded-md">
                        <Sparkles className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex items-center gap-1.5">
                        <svg className="w-10 h-10 -rotate-90">
                          <circle
                            cx="20"
                            cy="20"
                            r="16"
                            stroke="currentColor"
                            strokeWidth="3"
                            fill="transparent"
                            className="text-gray-100"
                          />
                          <circle
                            cx="20"
                            cy="20"
                            r="16"
                            stroke="currentColor"
                            strokeWidth="3"
                            fill="transparent"
                            strokeDasharray="100"
                            strokeDashoffset="28"
                            className="text-blue-600"
                          />
                        </svg>
                        <span className="text-xs font-semibold text-gray-900">
                          72% Rendered
                        </span>
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">
                      Final Cinematic Performance
                    </h3>
                    <p className="text-sm text-gray-600 mb-4">
                      High-resolution diffusion and temporal enhancement for
                      production-ready results.
                    </p>
                    <button className="w-full bg-blue-600 text-white font-semibold py-2 rounded-sm text-sm hover:bg-blue-700 transition-colors">
                      Export Master
                    </button>
                  </div>
                </div>
                <div className="hidden md:flex w-10 h-10 bg-blue-600 border border-blue-700 rounded-full items-center justify-center z-10 shadow-md">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
                <div className="hidden md:block w-[45%]" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Markers */}
      <section className="py-16 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-10">
            <span className="text-[10px] uppercase font-bold text-gray-400 tracking-widest">
              Trusted by leading studios
            </span>
          </div>
          <div className="flex flex-wrap justify-center items-center gap-12 opacity-50 grayscale">
            {/* Mock logos */}
            <div className="text-xl font-bold text-gray-900">NOVA STUDIOS</div>
            <div className="text-xl font-bold text-gray-900">PIXEL FORGE</div>
            <div className="text-xl font-bold text-gray-900">
              VIRTUAL CINEMA
            </div>
            <div className="text-xl font-bold text-gray-900">MOTION LABS</div>
          </div>
        </div>
      </section>

      {/* CTA Footer */}
      <footer className="py-20 px-4 text-center">
        <h2 className="text-3xl font-semibold text-gray-900 tracking-tight mb-4">
          Ready to transform your production?
        </h2>
        <p className="text-gray-500 mb-8 max-w-lg mx-auto">
          Join the next generation of filmmakers using AI to push the boundaries
          of cinematic storytelling.
        </p>
        <Link
          to="/create"
          className="inline-block bg-blue-600 text-white font-semibold px-8 py-4 rounded-sm hover:bg-blue-700 transition-colors"
        >
          Get Started for Free
        </Link>
        <div className="mt-12 text-xs text-gray-400">
          © 2026 CinematicAI Systems. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
