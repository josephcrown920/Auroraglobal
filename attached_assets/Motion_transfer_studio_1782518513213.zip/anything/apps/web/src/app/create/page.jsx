import React, { useState, useCallback, useRef } from "react";
import {
  Video,
  UserCheck,
  Palette,
  ArrowRight,
  ArrowLeft,
  Upload,
  X,
  Plus,
  Check,
  Zap,
  Sparkles,
  Shirt,
  Map,
  Film,
  Cpu,
  Download,
  Share2,
  RotateCcw,
  BookMarked,
} from "lucide-react";
import useCreateStore from "@/store/useCreateStore";
import useUpload from "@/utils/useUpload";
import { Link } from "react-router-dom";

const PIPELINE_STAGES = [
  { label: "Motion Extraction", weight: 25 },
  { label: "Identity Lock", weight: 20 },
  { label: "Scene Diffusion", weight: 25 },
  { label: "Outfit Transfer", weight: 15 },
  { label: "Video Enhancement", weight: 15 },
];

export default function CreateDashboard() {
  const {
    step,
    setStep,
    performanceVideo,
    setPerformanceVideo,
    identityPhotos,
    setIdentityPhotos,
    removeIdentityPhoto,
    artistProfile,
    setArtistProfile,
    outfit,
    setOutfit,
    scene,
    setScene,
    visualStyle,
    setVisualStyle,
    isProcessing,
    setProcessing,
    progress,
    setProgress,
    generatedResult,
    setGeneratedResult,
    generateError,
    setGenerateError,
    reset,
  } = useCreateStore();

  const [upload] = useUpload();
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [saving, setSaving] = useState(false);
  const [titleInput, setTitleInput] = useState("");
  const intervalRef = useRef(null);

  const steps = [
    {
      id: 1,
      title: "Upload Performance",
      icon: Video,
      description: "Extract motion and expressions",
    },
    {
      id: 2,
      title: "Identity Lock",
      icon: UserCheck,
      description: "Lock actor features",
    },
    {
      id: 3,
      title: "Style Studio",
      icon: Palette,
      description: "Outfit, Scene & Style",
    },
  ];

  const handleVideoUpload = (e) => {
    const file = e.target.files?.[0];
    if (file) setPerformanceVideo(URL.createObjectURL(file));
  };

  const handlePhotoUpload = (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) {
      const newPhotos = files.map((file) => URL.createObjectURL(file));
      setIdentityPhotos(newPhotos);
    }
  };

  const animateProgress = (targetPct, durationMs) => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    let current = 0;
    const inc = targetPct / (durationMs / 120);
    intervalRef.current = setInterval(() => {
      current = Math.min(current + inc, targetPct);
      setProgress(Math.floor(current));
      if (current >= targetPct) clearInterval(intervalRef.current);
    }, 120);
  };

  const startProcessing = async () => {
    setProcessing(true);
    setGeneratedResult(null);
    setGenerateError(null);
    setProgress(0);
    animateProgress(85, 20000);

    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ outfit, scene, visualStyle, artistProfile }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || `Generation failed (${res.status})`);
      }

      const data = await res.json();
      if (intervalRef.current) clearInterval(intervalRef.current);
      animateProgress(100, 1500);
      setTimeout(() => {
        setGeneratedResult(data);
        setProcessing(false);
      }, 1600);
    } catch (err) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      console.error("[Generate]", err);
      setGenerateError(err.message);
      setProcessing(false);
      setProgress(0);
    }
  };

  const saveToShowcase = async () => {
    if (!generatedResult) return;
    setSaving(true);
    try {
      const res = await fetch("/api/showcase", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: titleInput || "Cinematic Performance",
          imageUrl: generatedResult.imageUrl,
          prompt: generatedResult.prompt,
          modelUsed: generatedResult.modelUsed,
          visualStyle,
          sceneValue: scene?.value,
          outfitValue: outfit?.value,
          artistProfile,
        }),
      });
      if (!res.ok) throw new Error("Save failed");
      setSaveSuccess(true);
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const stageProgress = PIPELINE_STAGES.map((stage, i) => {
    const stageStart = PIPELINE_STAGES.slice(0, i).reduce(
      (a, s) => a + s.weight,
      0,
    );
    const p = Math.max(
      0,
      Math.min(100, ((progress - stageStart) / stage.weight) * 100),
    );
    return { ...stage, p };
  });

  const savingSpinner = (
    <span className="flex items-center gap-2">
      <span
        className="w-4 h-4 border-2 border-white border-t-transparent rounded-full"
        style={{ animation: "spin 0.8s linear infinite" }}
      />
      Saving...
    </span>
  );

  const activeStageSpinner = (
    <div
      className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full shrink-0"
      style={{ animation: "spin 0.8s linear infinite" }}
    />
  );

  return (
    <div className="min-h-screen bg-[#F9FAFB] font-inter pb-20">
      <style jsx global>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>

      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-600 rounded-sm flex items-center justify-center">
                <Film className="text-white w-5 h-5" />
              </div>
            </Link>
            <h1 className="text-lg font-semibold text-gray-900 tracking-tight">
              Create Performance
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <Link
              to="/showcase"
              className="text-sm font-medium text-gray-500 hover:text-gray-700"
            >
              Showcase
            </Link>
            <button
              onClick={reset}
              className="text-sm font-medium text-gray-500 hover:text-gray-700"
            >
              Cancel
            </button>
          </div>
        </div>

        {!generatedResult && (
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex items-center gap-8">
              {steps.map((s) => (
                <button
                  key={s.id}
                  onClick={() => !isProcessing && setStep(s.id)}
                  className={`flex items-center gap-2 pb-3 pt-4 border-b-2 transition-colors ${
                    step === s.id
                      ? "text-gray-900 font-medium border-blue-600 -mb-[1px]"
                      : "text-gray-500 font-normal border-transparent hover:text-gray-700"
                  }`}
                >
                  <s.icon
                    className={`w-4 h-4 ${step === s.id ? "text-blue-600" : "text-gray-400"}`}
                  />
                  <span className="text-sm hidden sm:inline">{s.title}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      <main className="max-w-4xl mx-auto px-4 pt-12">
        {/* RESULT SCREEN */}
        {generatedResult && !isProcessing && (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <div className="inline-flex items-center gap-1.5 bg-green-50 text-green-700 rounded-full px-3 py-1 text-sm font-medium mb-3">
                <Check className="w-4 h-4" /> Generation Complete
              </div>
              <h2 className="text-2xl font-semibold text-gray-900">
                Your Cinematic Performance
              </h2>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-lg">
              <img
                src={generatedResult.imageUrl}
                alt="Generated cinematic frame"
                className="w-full object-cover"
              />
            </div>

            <div className="flex items-center gap-2 bg-blue-50 border border-blue-100 rounded-lg px-4 py-3 text-sm">
              <Cpu className="w-4 h-4 text-blue-500 shrink-0" />
              <span className="text-blue-800">
                Generated with <strong>{generatedResult.modelUsed}</strong>
              </span>
            </div>

            {!saveSuccess ? (
              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <h3 className="text-base font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <BookMarked className="w-4 h-4 text-blue-600" /> Save to
                  Showcase
                </h3>
                <input
                  type="text"
                  placeholder="Give your performance a title..."
                  value={titleInput}
                  onChange={(e) => setTitleInput(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg p-3 text-sm mb-4 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <div className="flex gap-3">
                  <button
                    onClick={saveToShowcase}
                    disabled={saving}
                    className="flex-1 bg-blue-600 text-white font-semibold py-2.5 rounded-sm text-sm hover:bg-blue-700 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
                  >
                    {saving ? (
                      savingSpinner
                    ) : (
                      <>
                        <BookMarked className="w-4 h-4" /> Save to Showcase
                      </>
                    )}
                  </button>
                  <a
                    href={generatedResult.imageUrl}
                    download="cinematic-performance.jpg"
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2.5 border border-gray-200 rounded-sm text-sm font-medium text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" /> Download
                  </a>
                </div>
              </div>
            ) : (
              <div className="bg-green-50 border border-green-200 rounded-xl p-6 text-center">
                <Check className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <h3 className="font-semibold text-green-900 mb-1">
                  Saved to Showcase!
                </h3>
                <p className="text-sm text-green-700 mb-4">
                  Your cinematic performance is live in the gallery.
                </p>
                <Link
                  to="/showcase"
                  className="inline-flex items-center gap-2 bg-green-700 text-white text-sm font-semibold px-4 py-2 rounded-sm hover:bg-green-800 transition-colors"
                >
                  <Share2 className="w-4 h-4" /> View Showcase
                </Link>
              </div>
            )}

            <details className="bg-white rounded-xl border border-gray-200 p-4">
              <summary className="text-xs font-medium text-gray-500 cursor-pointer hover:text-gray-700">
                View generation prompt
              </summary>
              <p className="mt-3 text-[11px] text-gray-500 font-mono leading-relaxed bg-gray-50 rounded-lg p-3 border border-gray-100">
                {generatedResult.prompt}
              </p>
            </details>

            <div className="flex justify-center pt-4">
              <button
                onClick={() => reset()}
                className="flex items-center gap-2 text-sm font-medium text-gray-500 hover:text-gray-800 transition-colors"
              >
                <RotateCcw className="w-4 h-4" /> Create Another Performance
              </button>
            </div>
          </div>
        )}

        {/* ERROR STATE */}
        {generateError && !isProcessing && !generatedResult && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-6 mb-6">
            <h3 className="font-semibold text-red-900 mb-1">
              Generation Failed
            </h3>
            <p className="text-sm text-red-700 mb-4">{generateError}</p>
            <button
              onClick={() => setGenerateError(null)}
              className="text-sm font-medium text-red-700 hover:text-red-900 underline"
            >
              Try again
            </button>
          </div>
        )}

        {/* PROCESSING SCREEN */}
        {isProcessing && (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="relative mb-8">
              <svg className="w-32 h-32 -rotate-90">
                <circle
                  cx="64"
                  cy="64"
                  r="60"
                  stroke="currentColor"
                  strokeWidth="4"
                  fill="transparent"
                  className="text-gray-100"
                />
                <circle
                  cx="64"
                  cy="64"
                  r="60"
                  stroke="currentColor"
                  strokeWidth="4"
                  fill="transparent"
                  strokeDasharray={376.8}
                  strokeDashoffset={376.8 - (376.8 * progress) / 100}
                  className="text-blue-600 transition-all duration-300"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-xl font-semibold text-gray-900">
                  {progress}%
                </span>
              </div>
            </div>
            <h2 className="text-2xl font-semibold text-gray-900 mb-2">
              Generating Cinematic Performance
            </h2>
            <p className="text-gray-500 text-sm text-center max-w-sm mb-3">
              Running multi-model inference pipeline with fallback routing...
            </p>
            <div className="flex items-center gap-1.5 text-xs text-blue-600 bg-blue-50 px-3 py-1.5 rounded-full mb-10">
              <Cpu className="w-3.5 h-3.5" /> AI Inference Layer Active
            </div>
            <div className="w-full max-w-md space-y-3">
              {stageProgress.map((stage, i) => (
                <div
                  key={i}
                  className="bg-white border border-gray-200 rounded-lg p-4 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    {stage.p >= 100 ? (
                      <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center shrink-0">
                        <Check className="text-white w-3 h-3" />
                      </div>
                    ) : stage.p > 0 ? (
                      activeStageSpinner
                    ) : (
                      <div className="w-5 h-5 border-2 border-gray-200 rounded-full shrink-0" />
                    )}
                    <span className="text-sm font-medium text-gray-900">
                      {stage.label}
                    </span>
                  </div>
                  <span className="text-xs font-semibold text-gray-400">
                    {Math.floor(stage.p)}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* WIZARD STEPS */}
        {!isProcessing && !generatedResult && (
          <div className="space-y-8">
            {step === 1 && (
              <div className="space-y-6">
                <div className="bg-white rounded-xl border border-gray-200 p-8 text-center">
                  <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Video className="w-8 h-8 text-blue-600" />
                  </div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">
                    Upload Raw Performance
                  </h2>
                  <p className="text-gray-500 text-sm mb-8 max-w-md mx-auto">
                    Upload a 10–60 second video of dancing, rapping, or acting.
                    Our AI will extract all skeletal and facial motion.
                  </p>
                  {performanceVideo ? (
                    <div className="relative aspect-video rounded-lg overflow-hidden border border-gray-200 bg-black max-w-md mx-auto">
                      <video
                        src={performanceVideo}
                        className="w-full h-full object-contain"
                        controls
                      />
                      <button
                        onClick={() => setPerformanceVideo(null)}
                        className="absolute top-2 right-2 p-1.5 bg-black/50 text-white rounded-full hover:bg-black/70"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <label className="border-2 border-dashed border-gray-200 rounded-xl p-12 flex flex-col items-center justify-center hover:border-blue-300 transition-colors cursor-pointer group">
                      <input
                        type="file"
                        accept="video/*"
                        className="hidden"
                        onChange={handleVideoUpload}
                      />
                      <Upload className="w-10 h-10 text-gray-300 group-hover:text-blue-400 mb-4" />
                      <span className="text-sm font-medium text-gray-900">
                        Drag and drop or click to upload
                      </span>
                      <span className="text-xs text-gray-400 mt-1">
                        MP4, MOV, or WEBM up to 200MB
                      </span>
                    </label>
                  )}
                </div>

                <div className="bg-white rounded-xl border border-gray-200 p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <Zap className="w-4 h-4 text-blue-600" />
                    <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wider">
                      Extraction Preview
                    </h3>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {[
                      "Body Pose",
                      "Hand Gestures",
                      "Lip Sync",
                      "Camera Path",
                      "Timing Map",
                    ].map((feat) => (
                      <div
                        key={feat}
                        className="bg-gray-50 border border-gray-100 rounded-lg p-3 flex items-center justify-between"
                      >
                        <span className="text-xs font-medium text-gray-600">
                          {feat}
                        </span>
                        <div className="bg-white border border-gray-200 rounded-full px-2 py-0.5 text-[10px] text-gray-400">
                          Waiting
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <div className="bg-white rounded-xl border border-gray-200 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-1">
                    Face Reference Photos
                  </h2>
                  <p className="text-sm text-gray-500 mb-6">
                    Upload at least 3 photos from different angles to lock
                    identity.
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {identityPhotos.map((photo, i) => (
                      <div
                        key={i}
                        className="relative aspect-square rounded-lg overflow-hidden border border-gray-200 group"
                      >
                        <img
                          src={photo}
                          className="w-full h-full object-cover"
                        />
                        <button
                          onClick={() => removeIdentityPhoto(i)}
                          className="absolute top-1 right-1 p-1 bg-black/50 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                    <label className="aspect-square border-2 border-dashed border-gray-200 rounded-lg flex flex-col items-center justify-center hover:border-blue-300 transition-colors cursor-pointer group">
                      <input
                        type="file"
                        multiple
                        accept="image/*"
                        className="hidden"
                        onChange={handlePhotoUpload}
                      />
                      <Plus className="w-6 h-6 text-gray-300 group-hover:text-blue-400" />
                      <span className="text-[10px] font-medium text-gray-400 mt-2">
                        Add Photo
                      </span>
                    </label>
                  </div>
                </div>

                <div className="bg-white rounded-xl border border-gray-200 p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-1">
                    Artist Profile
                  </h2>
                  <p className="text-sm text-gray-500 mb-4">
                    Describe the artist or character for consistent synthesis.
                  </p>
                  <textarea
                    value={artistProfile}
                    onChange={(e) => setArtistProfile(e.target.value)}
                    placeholder="e.g. A futuristic pop artist with sharp features and neon highlights..."
                    className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg p-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:ring-offset-2 transition-all"
                  />
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <div className="bg-white rounded-xl border border-gray-200 p-6">
                  <div className="flex items-center gap-2 mb-6">
                    <Shirt className="w-5 h-5 text-blue-600" />
                    <h2 className="text-lg font-semibold text-gray-900">
                      Outfit Customization
                    </h2>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
                    {[
                      { id: "luxury-streetwear", label: "Luxury Streetwear" },
                      { id: "futuristic-armor", label: "Futuristic Armor" },
                      { id: "vintage-hip-hop", label: "Vintage Hip-Hop" },
                      { id: "afrofuturism", label: "Afrofuturism" },
                    ].map((p) => (
                      <button
                        key={p.id}
                        onClick={() =>
                          setOutfit({ value: p.id, type: "preset" })
                        }
                        className={`p-3 rounded-lg border text-sm font-medium transition-all ${
                          outfit.value === p.id && outfit.type === "preset"
                            ? "bg-blue-50 border-blue-600 text-blue-600"
                            : "bg-white border-gray-200 text-gray-600 hover:border-gray-300"
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                  <div>
                    <label className="text-xs font-medium text-gray-500 mb-1 block">
                      Custom Outfit Prompt
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Chrome jacket with embedded LED strips..."
                      className="w-full bg-gray-50 border border-gray-200 rounded-lg p-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:ring-offset-2"
                      onChange={(e) =>
                        setOutfit({ value: e.target.value, type: "prompt" })
                      }
                    />
                  </div>
                </div>

                <div className="bg-white rounded-xl border border-gray-200 p-6">
                  <div className="flex items-center gap-2 mb-6">
                    <Map className="w-5 h-5 text-blue-600" />
                    <h2 className="text-lg font-semibold text-gray-900">
                      Environment & Scene
                    </h2>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
                    {[
                      "Lagos night streets",
                      "Mars Outpost",
                      "Cyberpunk Alley",
                      "Desert Concert",
                      "Underground Vault",
                    ].map((s) => (
                      <button
                        key={s}
                        onClick={() => setScene({ value: s, type: "preset" })}
                        className={`p-3 rounded-lg border text-xs font-medium transition-all ${
                          scene.value === s
                            ? "bg-blue-50 border-blue-600 text-blue-600"
                            : "bg-white border-gray-200 text-gray-600 hover:border-gray-300"
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                  <label className="text-xs font-medium text-gray-500 mb-1 block">
                    Scene Description
                  </label>
                  <textarea
                    placeholder="Describe the cinematic backdrop..."
                    className="w-full h-24 bg-gray-50 border border-gray-200 rounded-lg p-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:ring-offset-2"
                    onChange={(e) =>
                      setScene({ value: e.target.value, type: "prompt" })
                    }
                  />
                </div>

                <div className="bg-white rounded-xl border border-gray-200 p-6">
                  <div className="flex items-center gap-2 mb-6">
                    <Film className="w-5 h-5 text-blue-600" />
                    <h2 className="text-lg font-semibold text-gray-900">
                      Visual Style
                    </h2>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {[
                      {
                        id: "music-video",
                        label: "Music Video",
                        desc: "Fast cuts, high contrast",
                      },
                      {
                        id: "movie-trailer",
                        label: "Movie Trailer",
                        desc: "Cinematic grading",
                      },
                      {
                        id: "anime",
                        label: "Anime Style",
                        desc: "Hand-drawn aesthetics",
                      },
                      {
                        id: "documentary",
                        label: "Documentary",
                        desc: "Raw, gritty feel",
                      },
                      {
                        id: "gta-action",
                        label: "GTA Action",
                        desc: "Hyper-real gaming",
                      },
                    ].map((v) => (
                      <button
                        key={v.id}
                        onClick={() => setVisualStyle(v.id)}
                        className={`p-4 rounded-xl border text-left transition-all ${
                          visualStyle === v.id
                            ? "bg-blue-50 border-blue-600 ring-1 ring-blue-600"
                            : "bg-white border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <div
                          className={`text-sm font-semibold mb-1 ${visualStyle === v.id ? "text-blue-600" : "text-gray-900"}`}
                        >
                          {v.label}
                        </div>
                        <div className="text-[10px] text-gray-500">
                          {v.desc}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Inference Layer Panel */}
                <div className="bg-gray-900 rounded-xl p-5 text-white">
                  <div className="flex items-center gap-2 mb-3">
                    <Cpu className="w-4 h-4 text-blue-400" />
                    <span className="text-sm font-semibold">
                      Inference Layer
                    </span>
                    <span className="ml-auto text-[10px] bg-green-500/20 text-green-400 border border-green-500/30 rounded-full px-2 py-0.5">
                      Active
                    </span>
                  </div>
                  <div className="space-y-2">
                    {[
                      {
                        name: "FLUX.1-schnell",
                        provider: "Hugging Face",
                        status: "primary",
                      },
                      {
                        name: "FLUX.1-schnell-Free",
                        provider: "Together AI",
                        status: "fallback",
                      },
                      {
                        name: "FLUX.1-schnell",
                        provider: "Fal.ai",
                        status: "fallback",
                      },
                      {
                        name: "FLUX (OSS)",
                        provider: "Pollinations.ai",
                        status: "always-free",
                      },
                    ].map((m, i) => {
                      const statusClass =
                        m.status === "primary"
                          ? "text-blue-400 border-blue-500/30 bg-blue-500/10"
                          : m.status === "always-free"
                            ? "text-green-400 border-green-500/30 bg-green-500/10"
                            : "text-gray-400 border-gray-600 bg-gray-800";
                      return (
                        <div
                          key={i}
                          className="flex items-center justify-between text-[11px]"
                        >
                          <span className="text-gray-300">
                            {m.name}{" "}
                            <span className="text-gray-500">
                              · {m.provider}
                            </span>
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded-full border ${statusClass}`}
                          >
                            {m.status}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            <div className="flex items-center justify-between pt-8 border-t border-gray-200">
              <button
                onClick={() => setStep(Math.max(1, step - 1))}
                disabled={step === 1}
                className="flex items-center gap-2 text-sm font-medium text-gray-500 hover:text-gray-700 disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ArrowLeft className="w-4 h-4" /> Back
              </button>

              {step < 3 ? (
                <button
                  onClick={() => setStep(step + 1)}
                  className="bg-blue-600 text-white font-semibold px-6 py-2.5 rounded-sm flex items-center gap-2 hover:bg-blue-700 transition-colors"
                >
                  Continue <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  onClick={startProcessing}
                  className="bg-blue-600 text-white font-semibold px-8 py-3 rounded-sm flex items-center gap-2 hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200"
                >
                  Generate Cinematic Performance{" "}
                  <Sparkles className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
