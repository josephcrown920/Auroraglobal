import { upload } from "@/app/api/utils/upload";

// Build a rich cinematic prompt from user's selections
function buildPrompt({ outfit, scene, visualStyle, artistProfile }) {
  const outfitDesc = outfit?.value || "luxury streetwear";
  const sceneDesc = scene?.value || "cinematic stage";

  const styleMap = {
    "music-video":
      "high-contrast music video aesthetic, fast dynamic lighting, vivid saturated colors",
    "movie-trailer":
      "dramatic cinematic grade, anamorphic lens flare, epic depth of field, teal and orange color grading",
    anime:
      "anime art style, cel-shaded, bold outlines, stylized lighting, vibrant illustration",
    documentary:
      "raw gritty realism, natural lighting, film grain, documentary handheld feel",
    "gta-action":
      "hyper-realistic game engine render, neon city lights, action composition, cinematic GTA VI style",
  };

  const styleDesc = styleMap[visualStyle] || styleMap["music-video"];
  const artistDesc = artistProfile
    ? `Subject: ${artistProfile.substring(0, 150)}.`
    : "a charismatic performer";

  return `Cinematic performance art, ${artistDesc} wearing ${outfitDesc}, ${sceneDesc} environment, ${styleDesc}, 8K ultra detailed, professional photography, dramatic composition, cinematic framing, award-winning visual production, hyper-realistic textures, volumetric lighting`;
}

// Model 1: Hugging Face FLUX.1-schnell (free tier with API key)
async function tryHuggingFace(prompt) {
  const apiKey = process.env.HUGGINGFACE_API_KEY;
  if (!apiKey) throw new Error("No HuggingFace API key");

  const response = await fetch(
    "https://api-inference.huggingface.co/models/black-forest-labs/FLUX.1-schnell",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "x-wait-for-model": "true",
      },
      body: JSON.stringify({
        inputs: prompt,
        parameters: { num_inference_steps: 4, width: 1024, height: 576 },
      }),
      signal: AbortSignal.timeout(45000),
    },
  );

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`HuggingFace error ${response.status}: ${err}`);
  }

  const blob = await response.blob();
  const arrayBuffer = await blob.arrayBuffer();
  const base64 = `data:image/jpeg;base64,${Buffer.from(arrayBuffer).toString("base64")}`;
  const { url, error } = await upload({ base64 });
  if (error) throw new Error(`Upload failed: ${error}`);
  return { url, model: "FLUX.1-schnell (Hugging Face)" };
}

// Model 2: Together AI FLUX.1-schnell-Free (free credits)
async function tryTogetherAI(prompt) {
  const apiKey = process.env.TOGETHER_API_KEY;
  if (!apiKey) throw new Error("No Together AI API key");

  const response = await fetch(
    "https://api.together.xyz/v1/images/generations",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "black-forest-labs/FLUX.1-schnell-Free",
        prompt,
        n: 1,
        width: 1024,
        height: 576,
        steps: 4,
      }),
      signal: AbortSignal.timeout(45000),
    },
  );

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Together AI error ${response.status}: ${err}`);
  }

  const data = await response.json();
  const imageUrl = data?.data?.[0]?.url;
  if (!imageUrl) throw new Error("Together AI returned no image URL");

  const { url, error } = await upload({ url: imageUrl });
  if (error) throw new Error(`Upload failed: ${error}`);
  return { url, model: "FLUX.1-schnell-Free (Together AI)" };
}

// Model 3: Fal.ai FLUX.1-schnell (free tier)
async function tryFalAI(prompt) {
  const apiKey = process.env.FAL_API_KEY;
  if (!apiKey) throw new Error("No Fal.ai API key");

  const response = await fetch("https://fal.run/fal-ai/flux/schnell", {
    method: "POST",
    headers: {
      Authorization: `Key ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      prompt,
      image_size: "landscape_16_9",
      num_inference_steps: 4,
      num_images: 1,
      enable_safety_checker: false,
    }),
    signal: AbortSignal.timeout(45000),
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Fal.ai error ${response.status}: ${err}`);
  }

  const data = await response.json();
  const imageUrl = data?.images?.[0]?.url;
  if (!imageUrl) throw new Error("Fal.ai returned no image URL");

  const { url, error } = await upload({ url: imageUrl });
  if (error) throw new Error(`Upload failed: ${error}`);
  return { url, model: "FLUX.1-schnell (Fal.ai)" };
}

// Fallback Model: Pollinations.ai (completely free, no API key needed)
async function tryPollinations(prompt) {
  const encoded = encodeURIComponent(prompt);
  const seed = Math.floor(Math.random() * 999999);
  const pollinationsUrl = `https://image.pollinations.ai/prompt/${encoded}?width=1024&height=576&model=flux&nologo=true&seed=${seed}`;

  // Pollinations returns image directly — fetch and re-upload to our CDN
  const imageResp = await fetch(pollinationsUrl, {
    signal: AbortSignal.timeout(60000),
  });
  if (!imageResp.ok) throw new Error(`Pollinations error ${imageResp.status}`);

  const blob = await imageResp.blob();
  const arrayBuffer = await blob.arrayBuffer();
  const base64 = `data:image/jpeg;base64,${Buffer.from(arrayBuffer).toString("base64")}`;
  const { url, error } = await upload({ base64 });
  if (error) throw new Error(`Upload failed: ${error}`);
  return { url, model: "FLUX (Pollinations.ai — Free Fallback)" };
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { outfit, scene, visualStyle, artistProfile } = body;

    const prompt = buildPrompt({ outfit, scene, visualStyle, artistProfile });

    const modelPipeline = [
      { name: "HuggingFace", fn: () => tryHuggingFace(prompt) },
      { name: "TogetherAI", fn: () => tryTogetherAI(prompt) },
      { name: "FalAI", fn: () => tryFalAI(prompt) },
      { name: "Pollinations", fn: () => tryPollinations(prompt) },
    ];

    const attemptLog = [];
    let result = null;

    for (const model of modelPipeline) {
      try {
        console.log(`[Generate] Trying ${model.name}...`);
        result = await model.fn();
        console.log(`[Generate] Success with ${model.name}`);
        break;
      } catch (err) {
        console.error(`[Generate] ${model.name} failed:`, err.message);
        attemptLog.push({ model: model.name, error: err.message });
      }
    }

    if (!result) {
      return Response.json(
        {
          error: "All inference models failed",
          details: attemptLog,
        },
        { status: 503 },
      );
    }

    return Response.json({
      imageUrl: result.url,
      modelUsed: result.model,
      prompt,
      attemptLog,
    });
  } catch (err) {
    console.error("[Generate] Fatal error:", err);
    return Response.json({ error: err.message }, { status: 500 });
  }
}
