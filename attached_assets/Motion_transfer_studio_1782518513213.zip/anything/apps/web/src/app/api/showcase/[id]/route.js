import sql from "@/app/api/utils/sql";

export async function DELETE(request, { params }) {
  try {
    const { id } = params;
    await sql("DELETE FROM showcase WHERE id = $1", [id]);
    return Response.json({ success: true });
  } catch (err) {
    console.error("[Showcase DELETE]", err);
    return Response.json({ error: err.message }, { status: 500 });
  }
}

export async function PATCH(request, { params }) {
  try {
    const { id } = params;
    const rows = await sql(
      "UPDATE showcase SET likes = likes + 1 WHERE id = $1 RETURNING likes",
      [id],
    );
    return Response.json({ likes: rows[0]?.likes });
  } catch (err) {
    console.error("[Showcase PATCH]", err);
    return Response.json({ error: err.message }, { status: 500 });
  }
}
