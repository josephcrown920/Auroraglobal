import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const style = searchParams.get("style");
    const limit = parseInt(searchParams.get("limit") || "50");

    let rows;
    if (style && style !== "all") {
      rows = await sql(
        "SELECT * FROM showcase WHERE visual_style = $1 ORDER BY created_at DESC LIMIT $2",
        [style, limit],
      );
    } else {
      rows = await sql(
        "SELECT * FROM showcase ORDER BY created_at DESC LIMIT $1",
        [limit],
      );
    }

    return Response.json({ items: rows });
  } catch (err) {
    console.error("[Showcase GET]", err);
    return Response.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      title,
      imageUrl,
      prompt,
      modelUsed,
      visualStyle,
      sceneValue,
      outfitValue,
      artistProfile,
    } = body;

    if (!imageUrl) {
      return Response.json({ error: "imageUrl is required" }, { status: 400 });
    }

    const rows = await sql(
      `INSERT INTO showcase 
        (title, image_url, prompt, model_used, visual_style, scene_value, outfit_value, artist_profile)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [
        title || "Cinematic Performance",
        imageUrl,
        prompt || null,
        modelUsed || null,
        visualStyle || null,
        sceneValue || null,
        outfitValue || null,
        artistProfile || null,
      ],
    );

    return Response.json({ item: rows[0] }, { status: 201 });
  } catch (err) {
    console.error("[Showcase POST]", err);
    return Response.json({ error: err.message }, { status: 500 });
  }
}
