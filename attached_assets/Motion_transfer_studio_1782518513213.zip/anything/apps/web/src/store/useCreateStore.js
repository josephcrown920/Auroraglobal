import { create } from "zustand";

const useCreateStore = create((set) => ({
  step: 1,
  performanceVideo: null,
  identityPhotos: [],
  artistProfile: "",
  outfit: { type: "preset", value: "luxury-streetwear", reference: null },
  scene: { type: "prompt", value: "", reference: null },
  visualStyle: "music-video",
  isProcessing: false,
  progress: 0,
  generatedResult: null, // { imageUrl, modelUsed, prompt }
  generateError: null,

  setStep: (step) => set({ step }),
  setPerformanceVideo: (video) => set({ performanceVideo: video }),
  setIdentityPhotos: (photos) =>
    set((state) => ({ identityPhotos: [...state.identityPhotos, ...photos] })),
  removeIdentityPhoto: (index) =>
    set((state) => ({
      identityPhotos: state.identityPhotos.filter((_, i) => i !== index),
    })),
  setArtistProfile: (profile) => set({ artistProfile: profile }),
  setOutfit: (outfit) =>
    set((state) => ({ outfit: { ...state.outfit, ...outfit } })),
  setScene: (scene) =>
    set((state) => ({ scene: { ...state.scene, ...scene } })),
  setVisualStyle: (style) => set({ visualStyle: style }),
  setProcessing: (isProcessing) => set({ isProcessing }),
  setProgress: (progress) => set({ progress }),
  setGeneratedResult: (result) => set({ generatedResult: result }),
  setGenerateError: (err) => set({ generateError: err }),

  reset: () =>
    set({
      step: 1,
      performanceVideo: null,
      identityPhotos: [],
      artistProfile: "",
      outfit: { type: "preset", value: "luxury-streetwear", reference: null },
      scene: { type: "prompt", value: "", reference: null },
      visualStyle: "music-video",
      isProcessing: false,
      progress: 0,
      generatedResult: null,
      generateError: null,
    }),
}));

export default useCreateStore;
