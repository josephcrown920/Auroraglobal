create table profiles (
 id uuid primary key,
 credits integer default 50,
 created_at timestamp default now()
);

create table projects (
 id uuid primary key default gen_random_uuid(),
 user_id uuid references profiles(id),
 title text,
 prompt text,
 storyboard jsonb,
 status text default 'queued',
 video_url text,
 created_at timestamp default now()
);

create table generation_jobs (
 id uuid primary key default gen_random_uuid(),
 project_id uuid references projects(id),
 agent_state jsonb,
 provider text,
 status text default 'pending',
 created_at timestamp default now()
);