# Aurora Agent Production Build

Architecture:
- Glassmorphism AI studio UI
- Multi-agent orchestration layer
- Supabase database layer
- Inference routing layer
- Generation jobs
- Storage-ready media pipeline

Environment:
SUPABASE_URL=
SUPABASE_SERVICE_KEY=
VIDEO_PROVIDER_KEY=