export async function directorAgent(input){
 return {
  concept: input,
  scenes:[
   {id:1,type:"opening",camera:"cinematic"},
   {id:2,type:"hero shot",camera:"tracking"},
   {id:3,type:"ending",camera:"drone"}
  ]
 };
}