export async function criticAgent(video){
 return {
  score: 90,
  suggestions:["Improve pacing","Add stronger opening hook"]
 };
}