export async function inferenceRouter(job){
 const provider = process.env.VIDEO_PROVIDER || "adapter";
 return {
   provider,
   prompt: job.prompt,
   status:"submitted"
 };
}