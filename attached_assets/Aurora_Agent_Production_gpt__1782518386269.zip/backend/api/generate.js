import {directorAgent} from '../../agents/director.js';
import {inferenceRouter} from '../inference/router.js';

export async function generateVideo(prompt){
 const plan = await directorAgent(prompt);
 return inferenceRouter({
   prompt: JSON.stringify(plan)
 });
}