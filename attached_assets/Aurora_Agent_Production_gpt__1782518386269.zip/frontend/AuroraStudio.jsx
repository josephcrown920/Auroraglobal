export default function AuroraStudio(){
 return <div className="studio">
   <div className="glass">
    <h1>Aurora Agent</h1>
    <p>AI Film Director</p>
    <textarea placeholder="Describe your video..." />
    <button>Generate</button>
   </div>
 </div>
}