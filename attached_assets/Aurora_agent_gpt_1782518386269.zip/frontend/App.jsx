export default function App(){
 return (
  <main className="aurora">
   <div className="glass">
    <h1>Aurora Agent</h1>
    <p>Your AI video director.</p>
    <textarea placeholder="Describe your video..." />
    <button>Generate Video</button>
   </div>
  </main>
 )
}