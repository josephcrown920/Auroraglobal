# Aurora Agent

AI video agent starter architecture.

Included:
- Glassmorphism UI foundation
- Agent planning workflow
- Supabase schema
- Backend inference layer abstraction
- Video generation test endpoint

## Run

Frontend:
npm install
npm run dev

Backend:
npm install
npm run server

Configure:
SUPABASE_URL
SUPABASE_ANON_KEY
VIDEO_MODEL_API_KEY