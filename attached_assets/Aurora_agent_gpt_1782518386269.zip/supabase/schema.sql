create table projects (
 id uuid primary key default gen_random_uuid(),
 user_id uuid,
 prompt text not null,
 storyboard jsonb,
 status text default 'draft',
 output_url text,
 created_at timestamp default now()
);

create table generations (
 id uuid primary key default gen_random_uuid(),
 project_id uuid references projects(id),
 provider text,
 request jsonb,
 response jsonb,
 created_at timestamp default now()
);