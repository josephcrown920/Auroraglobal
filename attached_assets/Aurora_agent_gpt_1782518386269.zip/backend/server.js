import express from 'express';
import {generateVideo} from './inference-layer.js';

const app = express();
app.use(express.json());

app.post('/api/generate', async(req,res)=>{
 try{
   const result = await generateVideo(req.body);
   res.json(result);
 }catch(e){
   res.status(500).json({error:e.message});
 }
});

app.listen(4000,()=>console.log('Aurora Agent API running'));