# Deployment Guide

Recommended services:

API:
- Vercel
- Railway
- Render

Worker:
- Railway
- Fly.io
- AWS ECS
- DigitalOcean

Environment variables:

SUPABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=
LOVABLE_API_KEY=
REPLICATE_API_KEY=
FAL_KEY=

Before production:
- test failed generations
- test refunds
- test duplicate requests
- monitor provider costs
