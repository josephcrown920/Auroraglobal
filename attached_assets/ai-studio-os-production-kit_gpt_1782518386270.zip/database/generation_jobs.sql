create table generation_jobs (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null,
 type text not null,
 model text not null,
 payload jsonb not null,
 status text default 'queued',
 attempts int default 0,
 result_url text,
 error text,
 created_at timestamp default now(),
 updated_at timestamp default now()
);

create index generation_jobs_status_idx
on generation_jobs(status, created_at);
