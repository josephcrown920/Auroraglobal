# Master AI Media Workflow

User Request
|
v
API Validation
|
v
Credit Reservation
|
v
Generation Job Created
|
v
Queue
|
v
Worker Claims Job
|
v
AI Orchestrator
|
+--> Image Provider
+--> Video Provider
+--> Lip Sync Provider
|
v
Storage Upload
|
v
Database Update
|
v
Realtime UI Update

The system is designed so every layer can be upgraded independently.
