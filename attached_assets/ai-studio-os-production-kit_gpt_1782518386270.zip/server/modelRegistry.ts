export const MODEL_REGISTRY = {
  image: {
    provider: 'lovable'
  },
  video: {
    provider: 'replicate'
  },
  lipsync: {
    provider: 'fal'
  }
};
