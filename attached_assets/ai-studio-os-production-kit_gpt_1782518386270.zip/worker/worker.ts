// Production worker scaffold
// Responsibilities:
// - claim queued jobs
// - run orchestration
// - retry failures
// - update status
// - finalize billing

async function processJobs() {
  while (true) {
    // fetch job
    // lock job
    // execute workflow
    // save result
  }
}

processJobs();
