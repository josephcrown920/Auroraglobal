import type {
  VideoGenerationRequest,
  BulkGenerationRequest,
  ImageToVideoRequest,
  GenerationResult,
} from '../types.js';

const BASE_URL = process.env.AURORA_API_URL ?? 'http://localhost:3000';
const API_KEY  = process.env.AURORA_API_KEY  ?? '';

async function post<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${API_KEY}`,
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Aurora API [${res.status}] ${path}: ${text}`);
  }

  return res.json() as Promise<T>;
}

async function get<T>(path: string): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { Authorization: `Bearer ${API_KEY}` },
  });
  if (!res.ok) throw new Error(`Aurora API [${res.status}] GET ${path}`);
  return res.json() as Promise<T>;
}

// ─── Aurora API methods ───────────────────────────────────────────────────────

export const auroraClient = {
  /** Generate a single video (routes to Kling → HeyGen via orchestrator) */
  generateVideo: (req: VideoGenerationRequest) =>
    post<GenerationResult>('/api/generate/video', req),

  /** Bulk generate images for a campaign */
  bulkGenerate: (req: BulkGenerationRequest) =>
    post<{ jobs: GenerationResult[]; total_credits: number }>('/api/generate/bulk', req),

  /** Animate a still image into a short video */
  imageToVideo: (req: ImageToVideoRequest) =>
    post<GenerationResult>('/api/generate/image-to-video', req),

  /** Poll job status */
  getJobStatus: (jobId: string) =>
    get<GenerationResult>(`/api/jobs/${jobId}`),

  /** List all jobs for a given avatar */
  getAvatarJobs: (avatarId: string, limit = 20) =>
    get<GenerationResult[]>(`/api/avatars/${avatarId}/jobs?limit=${limit}`),
};
