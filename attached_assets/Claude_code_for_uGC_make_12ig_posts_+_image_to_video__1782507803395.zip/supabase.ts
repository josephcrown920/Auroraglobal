import { createClient } from '@supabase/supabase-js';
import type { Avatar, GenerationJob } from '../types.js';

const url = process.env.SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_KEY;

if (!url || !key) {
  throw new Error('SUPABASE_URL and SUPABASE_SERVICE_KEY must be set');
}

export const supabase = createClient(url, key);

// ─── Avatars ──────────────────────────────────────────────────────────────────

export async function getAvatars(): Promise<Avatar[]> {
  const { data, error } = await supabase
    .from('avatars')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw new Error(`avatars fetch failed: ${error.message}`);
  return data ?? [];
}

export async function getAvatarByName(name: string): Promise<Avatar | null> {
  const { data } = await supabase
    .from('avatars')
    .select('*')
    .ilike('name', `%${name}%`)
    .limit(1)
    .single();
  return data ?? null;
}

export async function getAvatarById(id: string): Promise<Avatar | null> {
  const { data } = await supabase
    .from('avatars')
    .select('*')
    .eq('id', id)
    .single();
  return data ?? null;
}

// ─── Jobs ─────────────────────────────────────────────────────────────────────

export async function createJob(
  job: Omit<GenerationJob, 'id' | 'created_at' | 'updated_at'>,
): Promise<GenerationJob> {
  const { data, error } = await supabase
    .from('generation_jobs')
    .insert(job)
    .select()
    .single();
  if (error) throw new Error(`job create failed: ${error.message}`);
  return data as GenerationJob;
}

export async function updateJob(
  id: string,
  updates: Partial<GenerationJob>,
): Promise<void> {
  const { error } = await supabase
    .from('generation_jobs')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id);
  if (error) throw new Error(`job update failed: ${error.message}`);
}

export async function getJob(id: string): Promise<GenerationJob | null> {
  const { data } = await supabase
    .from('generation_jobs')
    .select('*')
    .eq('id', id)
    .single();
  return (data as GenerationJob) ?? null;
}

export async function getJobsByAvatar(
  avatarId: string,
  limit = 20,
): Promise<GenerationJob[]> {
  const { data, error } = await supabase
    .from('generation_jobs')
    .select('*')
    .eq('avatar_id', avatarId)
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw new Error(`jobs fetch failed: ${error.message}`);
  return (data as GenerationJob[]) ?? [];
}
