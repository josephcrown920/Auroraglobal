import { Server }           from '@modelcontextprotocol/sdk/server/index.js';
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';
import { z } from 'zod';

import {
  generateVideoSchema,   generateVideoTool,
  bulkGenerateSchema,    bulkGenerateTool,
  imageToVideoSchema,    imageToVideoTool,
  listAvatarsSchema,     listAvatarsTool,
  getJobStatusSchema,    getJobStatusTool,
} from './tools/index.js';

// ─── Build the MCP Server ─────────────────────────────────────────────────────

export function createAuroraMcpServer(): Server {
  const server = new Server(
    { name: 'aurora-mcp', version: '1.0.0' },
    { capabilities: { tools: {} } },
  );

  // ── Tool manifest ──────────────────────────────────────────────────────────

  server.setRequestHandler(ListToolsRequestSchema, async () => ({
    tools: [
      {
        name:        'aurora_generate_video',
        description: 'Generate a short video with Aurora. Claude auto-selects the best model (Kling, HeyGen, Wan, Hailuo) based on your prompt unless you specify one. Returns a job_id to track progress.',
        inputSchema: zodToJsonSchema(generateVideoSchema),
      },
      {
        name:        'aurora_bulk_generate',
        description: 'Batch-generate up to 50 images for a named Aurora avatar in one call. Vary locations, outfits, moods, and lighting automatically. Ideal for social media campaigns.',
        inputSchema: zodToJsonSchema(bulkGenerateSchema),
      },
      {
        name:        'aurora_image_to_video',
        description: 'Animate a still image into a 5–10 s video. Provide an image URL and a motion prompt. Claude picks the video model unless you specify one.',
        inputSchema: zodToJsonSchema(imageToVideoSchema),
      },
      {
        name:        'aurora_list_avatars',
        description: 'List all Aurora avatars / personas in your account. Use this to discover available names before generating.',
        inputSchema: zodToJsonSchema(listAvatarsSchema),
      },
      {
        name:        'aurora_get_job_status',
        description: 'Check the status of any Aurora generation job. Returns status, output URL(s), and credits used.',
        inputSchema: zodToJsonSchema(getJobStatusSchema),
      },
    ],
  }));

  // ── Tool dispatcher ────────────────────────────────────────────────────────

  server.setRequestHandler(CallToolRequestSchema, async (req) => {
    const { name, arguments: args } = req.params;

    switch (name) {
      case 'aurora_generate_video':
        return generateVideoTool(generateVideoSchema.parse(args));
      case 'aurora_bulk_generate':
        return bulkGenerateTool(bulkGenerateSchema.parse(args));
      case 'aurora_image_to_video':
        return imageToVideoTool(imageToVideoSchema.parse(args));
      case 'aurora_list_avatars':
        return listAvatarsTool(listAvatarsSchema.parse(args));
      case 'aurora_get_job_status':
        return getJobStatusTool(getJobStatusSchema.parse(args));
      default:
        return { content: [{ type: 'text', text: JSON.stringify({ error: `Unknown tool: ${name}` }) }] };
    }
  });

  return server;
}

// ─── Minimal Zod → JSON Schema converter ──────────────────────────────────────

function zodToJsonSchema(schema: z.ZodObject<any>): object {
  const shape = schema.shape as Record<string, z.ZodTypeAny>;
  const properties: Record<string, object> = {};
  const required: string[] = [];

  for (const [key, field] of Object.entries(shape)) {
    const isOptional = field instanceof z.ZodOptional || field instanceof z.ZodDefault;
    const inner      = isOptional ? (field as any)._def.innerType ?? (field as any)._def.schema : field;
    const description = (field as any)._def?.description ?? (inner as any)._def?.description;

    properties[key] = {
      type:        getJsonType(inner),
      description: description ?? key,
      ...(inner instanceof z.ZodEnum ? { enum: inner.options } : {}),
    };

    if (!isOptional) required.push(key);
  }

  return { type: 'object', properties, required };
}

function getJsonType(field: z.ZodTypeAny): string {
  if (field instanceof z.ZodString)  return 'string';
  if (field instanceof z.ZodNumber)  return 'number';
  if (field instanceof z.ZodBoolean) return 'boolean';
  if (field instanceof z.ZodArray)   return 'array';
  if (field instanceof z.ZodEnum)    return 'string';
  return 'string';
}
