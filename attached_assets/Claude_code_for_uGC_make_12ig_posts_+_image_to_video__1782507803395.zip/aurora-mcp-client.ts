/**
 * aurora-mcp-client.ts
 *
 * Shows how to use the Aurora MCP connector from the Anthropic API.
 * Drop this into any Node.js project — no extra SDKs needed.
 *
 * Usage:
 *   npx tsx aurora-mcp-client.ts
 */

const ANTHROPIC_API = 'https://api.anthropic.com/v1/messages';
const AURORA_MCP_URL = process.env.AURORA_MCP_URL ?? 'http://localhost:4200/sse';

// ─── Types ────────────────────────────────────────────────────────────────────

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

interface AuroraResponse {
  model: string;
  stop_reason: string;
  content: Array<{ type: string; text?: string }>;
}

// ─── Core: call Claude with Aurora MCP attached ───────────────────────────────

async function callAuroraConnector(
  messages: Message[],
  systemPrompt?: string,
): Promise<AuroraResponse> {
  const res = await fetch(ANTHROPIC_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 4096,
      system: systemPrompt ?? AURORA_SYSTEM_PROMPT,
      messages,
      mcp_servers: [
        {
          type: 'url',
          url:  AURORA_MCP_URL,
          name: 'aurora',
        },
      ],
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Anthropic API error [${res.status}]: ${text}`);
  }

  return res.json() as Promise<AuroraResponse>;
}

// ─── System prompt ────────────────────────────────────────────────────────────

const AURORA_SYSTEM_PROMPT = `
You are the Aurora AI assistant — a creative director for AI-generated content.

You have access to the Aurora platform through MCP tools:
- aurora_generate_video   – generate videos (auto-selects best model)
- aurora_bulk_generate    – batch image campaigns for an avatar
- aurora_image_to_video   – animate a still into a short video
- aurora_list_avatars     – list available personas
- aurora_get_job_status   – poll any generation job

Workflow rules:
1. If the user mentions an avatar by name, call aurora_list_avatars first to confirm it exists.
2. Always confirm the model you chose and why (e.g. "Using kling-2.5-turbo for speed").
3. After starting a job, show the job_id and remind the user to poll aurora_get_job_status.
4. Default aspect ratio: 9:16 for videos, 4:5 for photos.
5. Be concise — show the running status line like: "Running kling-2.5-turbo · 5s · 9:16".
`.trim();

// ─── Example usage ────────────────────────────────────────────────────────────

async function main() {
  console.log('🎬 Aurora Connector — example calls\n');

  // ── Example 1: Simple video ──────────────────────────────────────────────
  console.log('Example 1: Generate a video');
  const r1 = await callAuroraConnector([
    { role: 'user', content: 'Make a cinematic 5s video of Sophia walking on a rooftop at golden hour' },
  ]);
  console.log(r1.content.map(c => c.text).join('\n'), '\n');

  // ── Example 2: Bulk campaign ─────────────────────────────────────────────
  console.log('Example 2: Bulk generate');
  const r2 = await callAuroraConnector([
    {
      role: 'user',
      content: 'Generate 12 IG-ready 4:5 photos of Aria for next week — vary outfits (casual, formal, beach) and locations (café, rooftop, poolside)',
    },
  ]);
  console.log(r2.content.map(c => c.text).join('\n'), '\n');

  // ── Example 3: Image to video ────────────────────────────────────────────
  console.log('Example 3: Image to video');
  const r3 = await callAuroraConnector([
    {
      role: 'user',
      content: 'Take https://example.com/sophia.jpg and make a 5s slow-zoom cinematic video of it',
    },
  ]);
  console.log(r3.content.map(c => c.text).join('\n'), '\n');

  // ── Example 4: Check job ─────────────────────────────────────────────────
  console.log('Example 4: Job status');
  const r4 = await callAuroraConnector([
    { role: 'user', content: 'Check status of job job_abc123' },
  ]);
  console.log(r4.content.map(c => c.text).join('\n'), '\n');
}

main().catch(console.error);

// ─── Export for use in other modules ─────────────────────────────────────────

export { callAuroraConnector, AURORA_SYSTEM_PROMPT };
