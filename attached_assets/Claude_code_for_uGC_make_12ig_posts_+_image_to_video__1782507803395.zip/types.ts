// ─── Video / Image Models ────────────────────────────────────────────────────

export type VideoModel =
  | 'kling-2.5'
  | 'kling-2.5-turbo'
  | 'kling-2.0'
  | 'heygen-v2'
  | 'wan-2.1'
  | 'hailuo-v2'
  | 'sora-turbo';

export type ImageModel =
  | 'flux-1.1-pro'
  | 'kling-kolors'
  | 'huggingface-sdxl'
  | 'ideogram-v3';

export type AspectRatio = '9:16' | '16:9' | '1:1' | '4:5';

// ─── Supabase Row Types ───────────────────────────────────────────────────────

export interface Avatar {
  id: string;
  name: string;
  handle: string;
  lora_id: string;
  preview_url: string;
  style: string;
  trigger_word: string;
  created_at: string;
}

export interface GenerationJob {
  id: string;
  type: 'image' | 'video' | 'lipsync' | 'bulk';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  provider: string;
  model: string;
  prompt: string;
  output_url?: string;
  output_urls?: string[];   // bulk jobs
  error?: string;
  credits_used: number;
  avatar_id?: string;
  duration_seconds?: number;
  aspect_ratio?: AspectRatio;
  created_at: string;
  updated_at: string;
}

// ─── Aurora API Request / Response ───────────────────────────────────────────

export interface VideoGenerationRequest {
  prompt: string;
  model: VideoModel;
  aspect_ratio?: AspectRatio;
  duration?: 5 | 10;
  image_url?: string;
  avatar_id?: string;
  lora_id?: string;
  negative_prompt?: string;
}

export interface BulkGenerationRequest {
  avatar_id: string;
  prompt_template: string;
  count: number;
  aspect_ratio?: AspectRatio;
  variations?: {
    locations?: string[];
    outfits?: string[];
    moods?: string[];
    lighting?: string[];
  };
}

export interface ImageToVideoRequest {
  image_url: string;
  prompt: string;
  model: VideoModel;
  duration?: 5 | 10;
  aspect_ratio?: AspectRatio;
}

export interface GenerationResult {
  job_id: string;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  output_url?: string;
  output_urls?: string[];
  credits_used: number;
  provider: string;
  model: VideoModel | ImageModel;
  estimated_seconds?: number;
}

// ─── Model Selection ──────────────────────────────────────────────────────────

export interface ModelSelection {
  model: VideoModel | ImageModel;
  reason: string;
  estimatedCredits: number;
}

// ─── MCP Tool Results ─────────────────────────────────────────────────────────

export interface ToolContent {
  type: 'text';
  text: string;
}

export type ToolResult = { content: ToolContent[] };
