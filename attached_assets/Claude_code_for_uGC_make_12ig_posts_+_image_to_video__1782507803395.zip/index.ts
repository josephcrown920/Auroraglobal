#!/usr/bin/env node
import 'dotenv/config';
import express from 'express';
import cors    from 'cors';
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse.js';
import { createAuroraMcpServer }  from './server.js';

const PORT = Number(process.env.PORT ?? 4200);

// ─── Active session map (sessionId → transport) ───────────────────────────────
const transports = new Map<string, SSEServerTransport>();

// ─── Express ──────────────────────────────────────────────────────────────────
const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json());

// ─── Health check ─────────────────────────────────────────────────────────────
app.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    server: 'aurora-mcp',
    version: '1.0.0',
    sessions: transports.size,
  });
});

// ─── SSE endpoint — Claude connects here ─────────────────────────────────────
app.get('/sse', async (req, res) => {
  console.log('[aurora-mcp] New SSE connection');

  const mcpServer = createAuroraMcpServer();          // fresh instance per session
  const transport = new SSEServerTransport('/messages', res);

  transports.set(transport.sessionId, transport);

  res.on('close', () => {
    console.log(`[aurora-mcp] Session closed: ${transport.sessionId}`);
    transports.delete(transport.sessionId);
  });

  await mcpServer.connect(transport);
});

// ─── Message endpoint — Claude posts tool calls here ─────────────────────────
app.post('/messages', async (req, res) => {
  const sessionId = req.query.sessionId as string;
  const transport = transports.get(sessionId);

  if (!transport) {
    res.status(404).json({ error: 'Session not found' });
    return;
  }

  await transport.handlePostMessage(req, res, req.body);
});

// ─── Boot ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════╗
║  🎬  Aurora MCP Server  v1.0.0           ║
║                                          ║
║  SSE endpoint:  http://localhost:${PORT}/sse ║
║  Health:        http://localhost:${PORT}/health ║
╚══════════════════════════════════════════╝

Connect Claude by adding this to your MCP config:
  {
    "type": "url",
    "url": "http://localhost:${PORT}/sse",
    "name": "aurora"
  }
`);
});
