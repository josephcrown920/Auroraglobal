import { z } from 'zod';
import { auroraClient } from '../lib/aurora-client.js';
import { getAvatars, getAvatarByName, getJob } from '../lib/supabase.js';
import {
  selectVideoModel,
  selectImageModel,
  inferAspectRatio,
} from '../lib/model-selector.js';
import type { ToolResult } from '../types.js';

// ─── Helper ───────────────────────────────────────────────────────────────────

function ok(data: unknown): ToolResult {
  return { content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] };
}
function err(msg: string): ToolResult {
  return { content: [{ type: 'text', text: JSON.stringify({ error: msg }) }] };
}

// ─── 1. generate_video ────────────────────────────────────────────────────────

export const generateVideoSchema = z.object({
  prompt:        z.string().describe('What the video should show'),
  model:         z.string().optional().describe('kling-2.5 | kling-2.5-turbo | heygen-v2 | wan-2.1 | hailuo-v2 | sora-turbo. Auto-selected if omitted.'),
  aspect_ratio:  z.enum(['9:16','16:9','1:1','4:5']).optional().describe('Default: 9:16'),
  duration:      z.number().int().optional().describe('5 or 10 seconds. Default: 5'),
  avatar_name:   z.string().optional().describe('Aurora persona name (e.g. "Sophia")'),
});

export async function generateVideoTool(
  args: z.infer<typeof generateVideoSchema>,
): Promise<ToolResult> {
  try {
    const selection   = selectVideoModel(args.prompt, args.model);
    const aspectRatio = args.aspect_ratio ?? inferAspectRatio(args.prompt);
    const duration    = (args.duration ?? 5) as 5 | 10;

    let loraId: string | undefined;
    if (args.avatar_name) {
      const avatar = await getAvatarByName(args.avatar_name);
      if (!avatar) return err(`Avatar "${args.avatar_name}" not found`);
      loraId = avatar.lora_id;
    }

    const result = await auroraClient.generateVideo({
      prompt:       args.prompt,
      model:        selection.model as any,
      aspect_ratio: aspectRatio,
      duration,
      lora_id:      loraId,
    });

    return ok({
      job_id:           result.job_id,
      status:           result.status,
      model:            selection.model,
      model_reason:     selection.reason,
      aspect_ratio:     aspectRatio,
      duration:         `${duration}s`,
      estimated_credits: selection.estimatedCredits,
      message:          `Running ${selection.model} · ${duration}s · ${aspectRatio}`,
    });
  } catch (e) {
    return err(String(e));
  }
}

// ─── 2. bulk_generate ─────────────────────────────────────────────────────────

export const bulkGenerateSchema = z.object({
  avatar_name:      z.string().describe('Avatar/persona name to generate for'),
  prompt_template:  z.string().describe('Base prompt. Claude will create variations automatically.'),
  count:            z.number().int().min(1).max(50).describe('Number of posts to generate'),
  aspect_ratio:     z.enum(['9:16','16:9','1:1','4:5']).optional().describe('Default: 4:5 for IG'),
  vary_locations:   z.array(z.string()).optional().describe('Locations to cycle through'),
  vary_outfits:     z.array(z.string()).optional().describe('Outfits to cycle through'),
  vary_moods:       z.array(z.string()).optional().describe('Moods/expressions to cycle through'),
  vary_lighting:    z.array(z.string()).optional().describe('Lighting styles to cycle through'),
});

export async function bulkGenerateTool(
  args: z.infer<typeof bulkGenerateSchema>,
): Promise<ToolResult> {
  try {
    const avatar = await getAvatarByName(args.avatar_name);
    if (!avatar) return err(`Avatar "${args.avatar_name}" not found`);

    const result = await auroraClient.bulkGenerate({
      avatar_id:       avatar.id,
      prompt_template: args.prompt_template,
      count:           args.count,
      aspect_ratio:    args.aspect_ratio ?? '4:5',
      variations: {
        locations: args.vary_locations,
        outfits:   args.vary_outfits,
        moods:     args.vary_moods,
        lighting:  args.vary_lighting,
      },
    });

    const sel = selectImageModel(args.prompt_template);
    return ok({
      jobs:            result.jobs.map(j => j.job_id),
      total_jobs:      result.jobs.length,
      total_credits:   result.total_credits,
      model:           sel.model,
      avatar:          { id: avatar.id, name: avatar.name },
      aspect_ratio:    args.aspect_ratio ?? '4:5',
      message:         `Generating ${args.count} images for ${avatar.name} — ${result.jobs.length} queued`,
    });
  } catch (e) {
    return err(String(e));
  }
}

// ─── 3. image_to_video ────────────────────────────────────────────────────────

export const imageToVideoSchema = z.object({
  image_url:    z.string().url().describe('URL of the source image'),
  prompt:       z.string().describe('Motion / animation prompt'),
  model:        z.string().optional().describe('Video model. Auto-selected if omitted.'),
  duration:     z.number().int().optional().describe('5 or 10 seconds. Default: 5'),
  aspect_ratio: z.enum(['9:16','16:9','1:1','4:5']).optional(),
});

export async function imageToVideoTool(
  args: z.infer<typeof imageToVideoSchema>,
): Promise<ToolResult> {
  try {
    const selection   = selectVideoModel(args.prompt, args.model);
    const aspectRatio = args.aspect_ratio ?? inferAspectRatio(args.prompt);
    const duration    = (args.duration ?? 5) as 5 | 10;

    const result = await auroraClient.imageToVideo({
      image_url:    args.image_url,
      prompt:       args.prompt,
      model:        selection.model as any,
      duration,
      aspect_ratio: aspectRatio,
    });

    return ok({
      job_id:           result.job_id,
      status:           result.status,
      model:            selection.model,
      model_reason:     selection.reason,
      aspect_ratio:     aspectRatio,
      duration:         `${duration}s`,
      estimated_credits: selection.estimatedCredits,
      message:          `Running ${selection.model} · ${duration}s · ${aspectRatio}`,
    });
  } catch (e) {
    return err(String(e));
  }
}

// ─── 4. list_avatars ──────────────────────────────────────────────────────────

export const listAvatarsSchema = z.object({
  limit: z.number().int().optional().default(20).describe('Max avatars to return'),
});

export async function listAvatarsTool(
  args: z.infer<typeof listAvatarsSchema>,
): Promise<ToolResult> {
  try {
    const avatars = await getAvatars();
    const slice   = avatars.slice(0, args.limit);
    return ok({
      avatars: slice.map(a => ({
        id:          a.id,
        name:        a.name,
        handle:      a.handle,
        style:       a.style,
        preview_url: a.preview_url,
      })),
      total: slice.length,
    });
  } catch (e) {
    return err(String(e));
  }
}

// ─── 5. get_job_status ────────────────────────────────────────────────────────

export const getJobStatusSchema = z.object({
  job_id: z.string().describe('Job ID returned by a generation tool'),
});

export async function getJobStatusTool(
  args: z.infer<typeof getJobStatusSchema>,
): Promise<ToolResult> {
  try {
    // Check Supabase first (fastest), then fall back to live API
    const dbJob = await getJob(args.job_id);

    if (dbJob?.status === 'completed' || dbJob?.status === 'failed') {
      return ok({
        job_id:      dbJob.id,
        status:      dbJob.status,
        output_url:  dbJob.output_url,
        output_urls: dbJob.output_urls,
        credits_used: dbJob.credits_used,
        model:       dbJob.model,
        type:        dbJob.type,
      });
    }

    // Still in-flight — poll the live API
    const live = await auroraClient.getJobStatus(args.job_id);
    return ok(live);
  } catch (e) {
    return err(String(e));
  }
}
